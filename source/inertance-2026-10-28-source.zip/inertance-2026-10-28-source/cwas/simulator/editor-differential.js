/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Two-winding transformer: each winding is a water wheel in the drawing plane. A crown
   bevel gear on its hub drives a pinion on a horizontal shaft into an open bevel
   differential; the carrier is the shared flywheel in the middle.
   Both wheels have equal displacement: wheel turn ρj follows the integrated winding
   current qj. The differential's side gears must be equal, so the turns ratio sits in
   each end's bevel pair: crown:pinion = 2·|nj| (nj = relative turns), giving shaft
   angle θj = −2·nj·qj·scale. Pinions mesh on the inner side of each crown, so wheel 1
   turns clockwise and wheel 2 counter-clockwise for the same shaft direction. Carrier
   (θ1+θ2)/2 follows Σ nj ij, the magnetizing current; spiders spin at (θ1−θ2)/2.
   Gear sizes are to scale for nj in [½, 2]; beyond that they change only slightly,
   while all motion keeps the exact ratio.
   The differential is projected obliquely: screen x = X·S + Z·K, y = Y; angle θ about
   the shaft places a point at Y = −r cos θ, Z = r sin θ. */
(function(g){
const D=g.CircuitDocument||(typeof require!=='undefined'?require('./editor-document.js'):null),{K,S}=D.differential,TAU=2*Math.PI,R1=22,R2=11,HEEL=5,TEETH=8,RING=[46,56,6],LIGHT=norm([-.45,-.6,.66]),VIEW=[-K,0,S],MARK='#555555';
function norm(v){const l=Math.hypot(...v);return v.map(x=>x/l);}
const add=(a,b)=>a.map((x,j)=>x+b[j]),mul=(a,s)=>a.map(x=>x*s),dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],sub=(a,b)=>a.map((x,j)=>x-b[j]),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const project=p=>[p[0]*S+p[2]*K,p[1]],depth=p=>-p[0]*K+p[2]*S;
const rgb=hex=>[1,3,5].map(j=>parseInt(hex.slice(j,j+2),16)),shade=(hex,f)=>`rgb(${rgb(hex).map(v=>Math.round(Math.min(255,v*f))).join(',')})`;
// Faces carry an interior point so normals face outward; hidden faces are culled.
function face(list,points,inside,color,opacity=1,outline=true){
 let n=cross(sub(points[1],points[0]),sub(points[2],points[0]));if(Math.hypot(...n)<1e-9)n=cross(sub(points[2],points[0]),sub(points.at(-1),points[0]));
 const c=mul(points.reduce(add,[0,0,0]),1/points.length);n=norm(n);if(dot(n,sub(c,inside))<0)n=mul(n,-1);
 if(dot(n,VIEW)<=1e-6)return false;list.push({points,color,opacity,outline,light:.8+.25*Math.max(0,dot(n,LIGHT)),z:depth(c)});return true;
}
// An outline-only edge, drawn just above the face it belongs to.
const edge=(list,a,b)=>list.push({points:[a,b],open:true,z:depth(mul(add(a,b),.5))+.01});
// Drawn size of a bevel pair: exact for |n| in [½, 2], then compressed so it stays legible.
function bevelSize(n){
 const a=Math.abs(n),shown=a>2?2*Math.pow(a/2,.15):a<.5?.5*Math.pow(a/.5,.15):a,ratio=Math.min(5,Math.max(.8,2*shown)),crown=Math.sqrt(200*ratio),pinion=Math.sqrt(200/ratio);
 return {exact:2*a,ratio,crown,pinion,teeth:Math.max(8,Math.round(crown*.6)),pinionTeeth:Math.max(4,Math.round(Math.max(8,Math.round(crown*.6))/ratio))};
}
// Rough mitre bevel gear: axis a (outward from the apex), basis u×v=a, cone r = t. Tooth 0 is blue.
function bevel(list,a,u,v,angle){
 const at=(t,r,p)=>add(mul(a,t),mul(add(mul(u,Math.cos(p)),mul(v,Math.sin(p))),r)),n=2*TEETH;
 for(let k=0;k<n;k++){
  const p=angle+k*TAU/n,q=p+TAU/n,color=k===0?MARK:k%2?'#b9b9b9':'#e2e2e2',tip=k%2?1:1.12;
  face(list,[at(R2,R2*tip,p),at(R1,R1*tip,p),at(R1,R1*tip,q),at(R2,R2*tip,q)],mul(a,R1+2),color);
  face(list,[at(R1,R1*tip,p),at(R1+HEEL,R1,p),at(R1+HEEL,R1,q),at(R1,R1*tip,q)],mul(a,R1+HEEL/2),color);
 }
 face(list,Array.from({length:n},(_,k)=>at(R1+HEEL,R1,angle+k*TAU/n)),mul(a,R1),'#d6d6d6');
}
function cylinder(list,from,to,radius,u,v,angle,colors,segments,interior){
 for(let k=0;k<segments;k++){
  const p=angle+k*TAU/segments,q=p+TAU/segments,o=add(mul(u,radius*Math.cos(p)),mul(v,radius*Math.sin(p))),w=add(mul(u,radius*Math.cos(q)),mul(v,radius*Math.sin(q)));
  face(list,[add(from,o),add(to,o),add(to,w),add(from,w)],interior,colors[k%colors.length]);
 }
}
function scene(t1,t2){
 const list=[],tc=(t1+t2)/2,spin=(t1-t2)/2,X=[1,0,0],Y=[0,-1,0],Z=[0,0,1];
 bevel(list,[-1,0,0],Y,Z,t1);bevel(list,X,Y,Z,t2+Math.PI/TEETH);
 // Carrier flywheel: a smooth heavy ring, outlined only at its rims; four thin blue
 // stripes show it turning.
 const [ri,ro,w]=RING,n=48;
 for(let k=0;k<n;k++){
  const p=tc+k*TAU/n,q=p+TAU/n,color=k%12===0?MARK:'#cfcfcf',at=(x,r,a)=>[x,-r*Math.cos(a),r*Math.sin(a)],mid=[0,-(ri+ro)/2*Math.cos(p+Math.PI/n),(ri+ro)/2*Math.sin(p+Math.PI/n)];
  if(face(list,[at(-w,ro,p),at(w,ro,p),at(w,ro,q),at(-w,ro,q)],mid,color,1,false)){edge(list,at(-w,ro,p),at(-w,ro,q));edge(list,at(w,ro,p),at(w,ro,q));}
  if(face(list,[at(-w,ri,p),at(w,ri,p),at(w,ri,q),at(-w,ri,q)],mid,color,1,false)){edge(list,at(-w,ri,p),at(-w,ri,q));edge(list,at(w,ri,p),at(w,ri,q));}
  for(const x of [-w,w])if(face(list,[at(x,ri,p),at(x,ro,p),at(x,ro,q),at(x,ri,q)],mid,color,1,false)){edge(list,at(x,ro,p),at(x,ro,q));edge(list,at(x,ri,p),at(x,ri,q));}
 }
 // Spider pin spans the flywheel; two spider gears orbit on it and spin on it.
 const er=[0,-Math.cos(tc),Math.sin(tc)];
 for(const side of [-1,1]){
  const a=mul(er,side),v=cross(a,X);
  cylinder(list,mul(a,1),mul(a,ri),3,X,v,tc,['#a8a8a8','#8c8c8c'],4,mul(a,(ri+1)/2));
  bevel(list,a,X,v,-spin+Math.PI/TEETH);
 }
 list.sort((a,b)=>a.z-b.z);
 return {list,tc,spin};
}
// Angles use integrated native currents, never elapsed wall-clock time. Speeds are
// provided separately so a stationary angle does not get mistaken for zero energy.
function motion(c,s,travel=1.8){
 const scale=640000/12*travel/40,n=[0,1].map(j=>(c.turns?.[j]??1)/(c.turns?.[0]??1));
 const q=n.map((_,j)=>s.volumes[c.id+'.w'+(j+1)]||0),i=n.map((_,j)=>s.currents[c.id+'.w'+(j+1)]||0);
 const wheel=q.map((v,j)=>(j?-1:1)*Math.sign(n[j])*v*scale),shaft=q.map((v,j)=>-2*n[j]*v*scale),speed=i.map((v,j)=>-2*n[j]*v*scale);
 return {wheel,shaft,speed,carrier:(shaft[0]+shaft[1])/2,spider:(shaft[0]-shaft[1])/2,carrierSpeed:(speed[0]+speed[1])/2,spiderSpeed:(speed[0]-speed[1])/2};
}
function draw(c,{g,el,text,updates,pressure,color,pressureColor,magneticMode,doc,zoom,idPrefix='scene'}){
 const geometry=D.windingGeometry(c),shafts=[],wheels=[],heel=(R1+HEEL)*S;
 // Wheel turn: winding 1 clockwise, winding 2 counter-clockwise for positive nj·qj.
 const bevels=geometry.map(w=>bevelSize(w.ratio));
 // Winding wheels in the drawing plane, same water loop as the coupled windings.
 geometry.forEach((w,j)=>{
  const r=w.r,entryY=-Math.sqrt(r*r-15*15),ps='p'+(j+1),ns='n'+(j+1),side=j?-1:1;
  const wg=el('g',{'data-winding':j+1,'data-loop-direction':-w.flip,'data-pipe-radius':r,transform:`translate(${w.x} ${w.y}) rotate(${w.angle}) scale(${w.flip} 1)`},g),d=`M-15 ${-w.reach} V${entryY} A${r} ${r} 0 1 0 15 ${entryY} V${-w.reach}`;
  el('path',{d,fill:'none',stroke:'black','stroke-width':12},wg);const water=el('path',{d,fill:'none','stroke-width':9},wg),len=water.getTotalLength(),segments=[];
  for(let k=0;k<24;k++)segments.push(el('path',{d,fill:'none','stroke-width':9.2,'stroke-dasharray':`${len/24+.02} ${len+1}`,'stroke-dashoffset':-len*k/24},wg));
  const dots=Array.from({length:Math.ceil(len/17)},()=>el('circle',{r:1.5,fill:'white',visibility:'visible','data-winding-particle':j+1},wg));
  el('circle',{cx:-22,cy:-w.reach+6,r:2.5,fill:'black'},wg);
  // Paddles and the crown bevel gear turn together on the wheel hub.
  const bv=bevels[j],rc=bv.crown;wg.setAttribute('data-bevel-ratio',bv.exact);wg.setAttribute('data-bevel-drawn',bv.ratio);
  const mount=el('g',{transform:`translate(${w.x} ${w.y})`},g),rotor=el('g',{'data-winding-paddles':j+1},mount);
  for(let k=0;k<4;k++){const a=k*Math.PI/2;el('line',{x1:(rc+1)*Math.cos(a),y1:(rc+1)*Math.sin(a),x2:(r-4)*Math.cos(a),y2:(r-4)*Math.sin(a),stroke:k?'#444':'#075e9d','stroke-width':k?2:3},rotor);}
  const crown=[];for(let k=0;k<bv.teeth*4;k++){const a=k/(bv.teeth*4)*TAU,rr=k%4<2?rc:rc-4;crown.push(`${(rr*Math.cos(a)).toFixed(2)},${(rr*Math.sin(a)).toFixed(2)}`);}
  el('polygon',{points:crown.join(' '),fill:'#e2e2e2',stroke:'black','stroke-width':1.5,'stroke-linejoin':'round'},rotor);
  for(let k=0;k<bv.teeth;k++){const a=(k+.5)/bv.teeth*TAU;el('line',{x1:11*Math.cos(a),y1:11*Math.sin(a),x2:(rc-3)*Math.cos(a),y2:(rc-3)*Math.sin(a),stroke:k?'#777':MARK,'stroke-width':k?1:2},rotor);}
  el('circle',{r:11,fill:'#ccc',stroke:'black','stroke-width':1.5},mount);
  // Pinion: a rough cone on the shaft, apex toward the hub; tooth lines show its turning.
  const p=el('g',{transform:`translate(${w.x} 0) scale(${side} 1)`},g),far=rc+2,near=far*.45,rf=bv.pinion,rn=rf*.45;
  el('path',{d:`M${near} ${-rn} L${far} ${-rf} H${far+4} V${rf} H${far} L${near} ${rn} Z`,fill:'#e2e2e2',stroke:'black','stroke-width':1.5,'stroke-linejoin':'round'},p);
  const teeth=Array.from({length:bv.pinionTeeth},(_,k)=>el('line',{stroke:k?'#555':MARK,'stroke-width':k?1.2:2},p));
  el('line',{x1:far,y1:-rf,x2:far,y2:rf,stroke:'black','stroke-width':1.2},p);
  text(g,w.x,4,String(j+1),{'text-anchor':'middle','font-size':11/zoom,'data-device-symbol':'',transform:`rotate(${-c.rotation} ${w.x} 0)`});
  wheels.push((s,turn,shaft)=>{
   const pa=pressure(s,ps),pb=pressure(s,ns),dv=pa-pb,fillAt=u=>magneticMode==='circuit'?color(pa+(pb-pa)*u):pressureColor(dv*(.5-(magneticMode==='split'?(u<.5?0:1):u)));
   wg.setAttribute('data-pressure-view',magneticMode);wg.setAttribute('data-winding-voltage',dv);water.setAttribute('stroke',fillAt(0));segments.forEach((n,k)=>n.setAttribute('stroke',fillAt((k+.5)/24)));
   rotor.setAttribute('transform',`rotate(${turn*180/Math.PI})`);rotor.setAttribute('data-angle-rad',turn);
   // Water advances one pipe radius per radian of wheel turn, along p → n.
   const travel=r*turn*-w.flip;dots.forEach((dot,k)=>{const q=water.getPointAtLength(((k*17+travel)%len+len)%len);dot.setAttribute('cx',q.x);dot.setAttribute('cy',q.y);});
   teeth.forEach((n,k)=>{const a=side*shaft+k*TAU/teeth.length;n.setAttribute('visibility',Math.sin(a)>0?'visible':'hidden');n.setAttribute('x1',near);n.setAttribute('y1',-rn*Math.cos(a));n.setAttribute('x2',far);n.setAttribute('y2',-rf*Math.cos(a));});
  });
 });
 const layer=el('g',{'data-differential':''},g),pool=[];
 // The same flat striped shafts run from each pinion to the centre of its side gear. The left one
 // is in front of its gear's back disc; the right one joins its gear from behind.
 geometry.forEach((w,j)=>{
  const side=j?-1:1,from=w.x+side*(bevels[j].crown+6),to=-side*heel,x0=Math.min(from,to),length=Math.abs(to-from),group=el('g',{'data-shaft':j+1},g),behind=j&&g.insertBefore(group,layer),id=`ed-shaft-${idPrefix}-${c.id}-${j}`;
  el('rect',{x:x0,y:-4,width:length,height:8,fill:'#cfcfcf'},group);
  const clip=el('clipPath',{id},el('defs',{},group));el('rect',{x:x0,y:-4,width:length,height:8},clip);
  const stripes=el('g',{'clip-path':`url(#${id})`},group),lines=Array.from({length:Math.ceil(length/10)+2},(_,k)=>el('line',{y1:-4,y2:4,stroke:k===0?MARK:'#555','stroke-width':1.6},stripes));
  el('rect',{x:x0,y:-4,width:length,height:8,fill:'none',stroke:'black','stroke-width':1.5},group);
  shafts.push(theta=>{const shift=((theta/TAU*10)%10+10)%10;lines.forEach((n,k)=>{const x=x0-10+k*10+shift;n.setAttribute('x1',x-3);n.setAttribute('x2',x+3);});group.setAttribute('data-angle-rad',theta);});
 });
 updates.push((v,s)=>{
  const m=motion(c,s,doc.settings.travel),turn=m.wheel,[t1,t2]=m.shaft,{list,tc,spin}=scene(t1,t2);
  shafts[0](t1);shafts[1](t2);wheels[0](s,turn[0],t1);wheels[1](s,turn[1],t2);
  while(pool.length<list.length)pool.push(el('path',{'stroke-linejoin':'round','stroke-linecap':'round'},layer));
  list.forEach((f,k)=>{
   const n=pool[k],d='M'+f.points.map(p=>project(p).map(x=>x.toFixed(2)).join(' ')).join(' L')+(f.open?'':' Z');n.setAttribute('d',d);n.removeAttribute('display');
   if(f.open){n.setAttribute('fill','none');n.setAttribute('stroke','black');n.setAttribute('stroke-width',1.4);return;}
   const fill=shade(f.color,f.light);n.setAttribute('fill',fill);n.setAttribute('fill-opacity',f.opacity);n.setAttribute('stroke',f.outline?'black':fill);n.setAttribute('stroke-width',f.outline?1:.8);
  });
  for(let k=list.length;k<pool.length;k++)pool[k].setAttribute('display','none');
  Object.assign(layer.dataset,{primary:t1,secondary:t2,carrier:tc,spider:spin,carrierSpeed:m.carrierSpeed,spiderSpeed:m.spiderSpeed});
 });
}
const api={draw,scene,motion,bevelSize};if(typeof module!=='undefined')module.exports=api;else g.EditorDifferential=api;
})(globalThis);
