#!/usr/bin/env python3
"""Build the Inertance web app (compact hybrid shell + real circuit editor).

Reads  ./app-src/{shell.html, app.css, host.js, assets/, analytics/} (this repo)
       ../cwas/simulator/editor-modules.json + the modules it lists (private source)
Writes ./app/index.html, ./app/assets/ and ./assets/analytics/   (generated; do not edit)

The editor modules are inlined unchanged and in the order editor-modules.json
gives. host.js runs after them and talks to the editor only through its DOM ids
and the window.circuitEditor API. Before writing, the build checks both contracts
and stamps the page with the simulator commit it came from. See docs/APP.md and
../cwas/docs/WEBSITE-WORKFLOW.md.
"""
from datetime import date
import os
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).parent
SRC = HERE / "app-src"
SIM = HERE.parent / "cwas" / "simulator"
OUT = HERE / "app"

D3 = "../assets/vendor/d3.v7.9.0.min.js"

if not (SIM / "editor-modules.json").exists():
    sys.exit(f"simulator source not found: {SIM / 'editor-modules.json'}")
EDITOR_MODULES = json.loads((SIM / "editor-modules.json").read_text())["modules"]
if EDITOR_MODULES[-1] != "editor-ui.js":
    sys.exit("editor-modules.json: editor-ui.js must be the last module")

missing = [m for m in EDITOR_MODULES if not (SIM / m).exists()]
if missing:
    sys.exit(f"simulator source not found in {SIM}: {', '.join(missing)}")

shell = (SRC / "shell.html").read_text()
css = (SRC / "app.css").read_text() + "\n" + (SRC / "community.css").read_text()
host = (SRC / "host.js").read_text() + "\n" + (SRC / "community.js").read_text()
analytics = json.loads((SRC / "analytics" / "config.json").read_text())
website = analytics.get("website", "")
if not isinstance(website, str) or (website and not re.fullmatch(r"[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}", website)):
    sys.exit("analytics/config.json: website must be an Umami website UUID or empty to disable collection")
posthog = analytics.get("posthog", {})
if not isinstance(posthog, dict) or set(posthog) - {"token", "host"}:
    sys.exit("analytics/config.json: posthog accepts only public token and host fields")
token = posthog.get("token", "")
collector = posthog.get("host", "https://eu.i.posthog.com")
if not isinstance(token, str) or (token and not re.fullmatch(r"phc_[A-Za-z0-9]{20,128}", token)):
    sys.exit("analytics/config.json: PostHog token must be a public phc_ project token or empty; never use a private API key")
if collector not in ("https://eu.i.posthog.com", "https://us.i.posthog.com"):
    sys.exit("analytics/config.json: PostHog host must be an official EU or US ingestion host")
public_analytics = {"website": website, "posthog": {"token": token, "host": collector}}
modules = "\n".join(f"/* ---- {m} ---- */\n" + (SIM / m).read_text() for m in EDITOR_MODULES)

# Contract check: every id the editor looks up must exist in the shell exactly once.
editor_ids = set(re.findall(r"\$\('#(ed-[a-z0-9-]+)'\)", (SIM / "editor-ui.js").read_text()))
# The shared importer UI binds fixed ids through get(), in its own module.
editor_ids |= set(re.findall(r"get\('((?:ed-)[a-z0-9-]+)'\)", (SIM / "editor-import-ui.js").read_text()))
shell_ids = re.findall(r'\bid="(ed-[a-z0-9-]+)"', shell)
absent = sorted(editor_ids - set(shell_ids))
dupes = sorted({i for i in shell_ids if shell_ids.count(i) > 1})
created_by_editor = {"ed-magnetic", "ed-mem-live"}  # built inside #ed-fields at run time, looked up defensively
absent = [i for i in absent if i not in created_by_editor]
if absent or dupes:
    sys.exit(f"shell/editor id contract broken. missing: {absent} duplicated: {dupes}")
if 'class="work' not in shell:
    sys.exit("shell must contain the .work element (editor toggles .inspector-hidden on it)")

# Contract check: every window.circuitEditor member host.js uses must exist in the editor.
ui = (SIM / "editor-ui.js").read_text()
api_start = ui.find("window.circuitEditor={")
if api_start < 0:
    sys.exit("editor-ui.js no longer defines window.circuitEditor")
api_members = set(re.findall(r"(?:[{,]|get |set )([A-Za-z_]\w*)\(", ui[api_start + len("window.circuitEditor="):]))
host_members = set(re.findall(r"\bE\.([A-Za-z_]\w*)", host))
unknown = sorted(host_members - api_members)
if unknown:
    sys.exit(f"host.js uses window.circuitEditor members the editor does not provide: {unknown}")

# Provenance: which simulator commit is inside this build.
def git(*args):
    try:
        return subprocess.run(["git", "-C", str(SIM.parent), *args], capture_output=True, text=True, check=True).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return ""
commit = git("rev-parse", "--short", "HEAD") or "unknown"
tracked = [f"simulator/{m}" for m in EDITOR_MODULES] + ["simulator/editor-modules.json"]
dirty = bool(git("status", "--porcelain", "--", *tracked))
release_input = HERE / 'release-input.json'
if release_input.exists() and not (SIM.parent / '.git').exists():
    frozen = json.loads(release_input.read_text())
    commit = frozen['simulator_revision'][:7]
    dirty = False
build_date = os.environ.get('INERTANCE_BUILD_DATE', date.today().isoformat())
if release_input.exists() and not (SIM.parent / '.git').exists():
    build_date = frozen['build_date']
stamp = f"cwas {commit}{' + uncommitted changes' if dirty else ''} · built {build_date}"

for s in (modules, host):
    if "</script" in s.lower():
        sys.exit("a script contains '</script' and cannot be inlined")

page = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Circuit · Inertance</title>
<meta name="description" content="Build and run switching power circuits as water: pressure is voltage, flow is current, a flywheel is inductance and a spring-loaded piston is capacitance.">
<meta name="theme-color" content="#191c1f">
<meta name="author" content="Lucas Wybrandt">
<link rel="canonical" href="https://inertance.org/app/">
<meta name="inertance-simulator" content="{stamp}">
<link rel="icon" type="image/svg+xml" href="assets/inertance-pipe-mark.svg">
<link rel="stylesheet" href="../assets/analytics/analytics.css">
<!-- Generated by build_app.py from app-src/ and ../cwas/simulator. Do not edit. -->
<script>try{{var t=localStorage.getItem('inertance-theme');document.documentElement.dataset.theme=t||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light')}}catch(e){{}}</script>
<style>
{css}
</style>
<script src="{D3}"></script>
</head>
<body>
{shell}
<script>
{modules}
</script>
<script>
{host}
</script>
<script src="../assets/analytics/config.js"></script>
<script src="../assets/analytics/analytics.js"></script>
</body>
</html>
"""

OUT.mkdir(exist_ok=True)
(OUT / "index.html").write_text(page)
if (OUT / "assets").exists():
    shutil.rmtree(OUT / "assets")
shutil.copytree(SRC / "assets", OUT / "assets")
analytics_out = HERE / "assets" / "analytics"
analytics_out.mkdir(exist_ok=True)
for name in ("analytics.js", "analytics.css"):
    shutil.copyfile(SRC / "analytics" / name, analytics_out / name)
(analytics_out / "config.js").write_text("window.InertanceAnalyticsConfig = Object.freeze(" + json.dumps(public_analytics) + ");\n")
print(f"built {OUT / 'index.html'}  ({len(page):,} bytes, {len(EDITOR_MODULES)} editor modules, "
      f"{len(editor_ids)} ids and {len(host_members)} API members checked)")
print(f"simulator: {stamp}")


# Static gallery seeds only; no old editor snapshot or browser-local private records.
community_source = SRC / "community"
community_output = OUT / "community"
community_output.mkdir(exist_ok=True)
shutil.copyfile(community_source / "gallery.json", community_output / "gallery.json")
shutil.copytree(community_source / "circuits", community_output / "circuits", dirs_exist_ok=True)
