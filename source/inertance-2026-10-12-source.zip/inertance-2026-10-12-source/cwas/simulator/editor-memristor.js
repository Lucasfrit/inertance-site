/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Reviewed narrow-bore plug / exit meter / meshing rack from Claude's
 * memristor demo, adapted to editor ports. Geometry is illustrative; state,
 * volume, pressure and stop/slip always come from the selected network sample. */
(function(g){
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),smooth=x=>{x=clamp(x,0,1);return x*x*(3-2*x);};
const slip=(F,i)=>Math.abs(i)>1e-12?1-F:0,SLIP_SHOWN=.02;
const GEO={IN:10,X0:46,D:190,TOP:100,HO:36};
const TOOTH=12.6,ADD=1.6,DED=2.3;  // pitch, addendum and dedendum (root clearance 0.7), editor gear scale
const NOSE=32;                     // tapered entry into the moving restriction
const RACK_DEPTH=6;                // rack pitch line below the plug top, on the plug's side face
const STROKE_VOLUMES=2;            // water through the device per full stroke, in open-passage volumes
const areaGain=(p,scale)=>STROKE_VOLUMES*GEO.D*GEO.HO/p.QD*scale*scale; // drawn area units per coulomb

// Laminar slot law: resistance per length ∝ 1/h³, so Roff/Ron fixes the gap.
function gapHeight(p){return clamp(GEO.HO*Math.cbrt(p.Ron/p.Roff),5,30);}

function geometry(p){
 const PW=GEO.HO,hg=gapHeight(p),BOT=GEO.TOP+GEO.HO,yb=GEO.TOP+hg,X1=GEO.X0+GEO.D,pitchY=yb+RACK_DEPTH;
 // Large meter wheel keeps the memory mechanism legible beside other parts.
 // Quantized pitch radius retains rack engagement throughout the stroke.
 const rpTarget=Math.min(2.5*(2*(hg+8)-1),3.2*GEO.HO),N=Math.max(10,Math.round(2*Math.PI*(rpTarget+RACK_DEPTH+.6)/TOOTH)),rg=N*TOOTH/(2*Math.PI);
 // Pitch circle tangent to the rack pitch line; paddles reach the plug top.
 // Round meter body hugging the paddles; its left edge meets the ceiling at the
 // passage exit. Port b rises at pipe width with its right wall flush with the
 // body's right edge, so the wheel's right side lines up with the pipe wall.
 // The body's lower-right arc comes down onto the plug top: that point is the seal.
 const hub=pitchY-rg,rp=yb-hub-.6,R=rp+2.5,half=Math.sqrt(Math.max(0,R*R-(GEO.TOP-hub)**2)),cx=X1+half+1,xb=cx+half,xw=cx+Math.sqrt(Math.max(0,R*R-(yb-hub)**2)),LP=xw-GEO.X0+8;
 const d=R-PW,rx=cx+d+PW/2,yA=hub-Math.sqrt(Math.max(0,R*R-d*d)),yB=hub-R-16,LUG=8;
 // The drawing ends shortly after the seal; the withdrawn plug fades out there.
 return {...GEO,PW,BOT,hg,yb,X1,hub,rg,rp,N,R,cx,xb,xw,LP,pitchY,d,rx,yA,yB,LUG,
  xa:cx-Math.sqrt(Math.max(0,R*R-(GEO.TOP-hub)**2)),right:Math.max(xw+34,cx+R+20)};
}

// Particle tables: cumulative swept area along a polyline with local width.
function table(points){let u=0;const out=[];for(let k=0;k<points.length;k++){const p=points[k];if(k){const a=points[k-1];u+=Math.hypot(p.x-a.x,p.y-a.y)*(p.w+a.w)/2;}out.push({x:p.x,y:p.y,w:p.w,u});}return out;}
function pointAt(tab,u){let lo=0,hi=tab.length-1;while(hi-lo>1){const m=(lo+hi)>>1;if(tab[m].u<u)lo=m;else hi=m;}const a=tab[lo],b=tab[hi],f=b.u>a.u?(u-a.u)/(b.u-a.u):0;return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,w:a.w+(b.w-a.w)*f};}
function placeDots(dots,tab,travel){const U=tab[tab.length-1].u,n=dots.length;for(let j=0;j<n;j++){const u=((j*U/n+travel)%U+U)%U,p=pointAt(tab,u);dots[j].setAttribute('cx',p.x.toFixed(2));dots[j].setAttribute('cy',p.y.toFixed(2));}}

// Tracer paths. Passage lanes end where water enters the paddle pockets; the
// pockets carry it round rigidly (particles fixed between the paddles); outlet
// lanes start where it leaves the paddle circle and rise to port b.
function passageLane(lam,T,G){
 const pts=[],hAt=x=>G.HO+(G.hg-G.HO)*clamp((x-(T-NOSE))/NOSE,0,1);
 for(let x=G.IN;x<=G.cx;x+=3){const h=hAt(x),y=G.TOP+lam*h;if(Math.hypot(x-G.cx,y-G.hub)<G.rp-1&&pts.length>2)break;pts.push({x,y,w:h});}
 return pts;
}
function outletLane(lam,G){
 const x=G.rx-G.PW/2+4+lam*(G.PW-8),dx=x-G.cx,y0=Math.abs(dx)<G.rp?G.hub-Math.sqrt(G.rp*G.rp-dx*dx):G.hub,pts=[];
 for(let y=y0;y>G.yB;y-=3)pts.push({x,y,w:G.PW});
 return pts.length>1?pts:[{x,y:y0,w:G.PW},{x,y:G.yB,w:G.PW}];
}

// Trapezoidal teeth, centred on angle 0 + kΔ (gear) or u0 + jp (rack).
function gearPath(r,N){const d=[],D=2*Math.PI/N;for(let k=0;k<N;k++){const c=k*D;for(const [f,rr] of [[-.29,r-DED],[-.15,r+ADD],[.15,r+ADD],[.29,r-DED]]){const a=c+f*D;d.push(`${(rr*Math.cos(a)).toFixed(2)} ${(rr*Math.sin(a)).toFixed(2)}`);}}return 'M'+d.join(' L')+'Z';}
function rackPath(x0,x1,y,p,u0){let d=`M${x0-p} ${y+DED}`;for(let c=u0-p*Math.ceil((u0-x0)/p+1);c<x1+p;c+=p)d+=` L${(c-.29*p).toFixed(2)} ${y+DED} L${(c-.15*p).toFixed(2)} ${y-ADD} L${(c+.15*p).toFixed(2)} ${y-ADD} L${(c+.29*p).toFixed(2)} ${y+DED}`;return d+` L${x1+p} ${y+DED}`;}

function buildDevice(root,{p,el,color,mini=true,prefix}){
 const G=geometry(p),D=G.D,lw=mini?3.9:3,yb=G.yb,period=2*Math.PI*G.rg/G.N,dotR=mini?4.4:1.9;
 const defs=el('defs',{},root),grad=el('linearGradient',{id:prefix+'grad',gradientUnits:'userSpaceOnUse',x1:G.X0,x2:G.X1,y1:0,y2:0},defs);
 const stops=[0,0,1].map(o=>el('stop',{offset:o},grad));
 const water=el('g',{fill:`url(#${prefix}grad)`},root);
 el('rect',{x:G.IN,y:G.TOP,width:G.xw-G.IN,height:G.HO},water);
 el('circle',{cx:G.cx,cy:G.hub,r:G.R,'data-memristor-body':''},water);
 el('rect',{x:G.rx-G.PW/2,y:G.yB,width:G.PW,height:G.hub-G.yB},water);
 const lams=mini?[.3,.7]:[.18,.5,.82],lanes=lams.map(lam=>({lam,kind:'in',dots:[]})).concat(lams.map(lam=>({lam,kind:'out',dots:[]})));
 const flowLayer=el('g',{},root);
 // Plug: a bar on the floor; the rack runs along its side face below the top.
 const fade=el('linearGradient',{id:prefix+'fade',gradientUnits:'userSpaceOnUse',x1:G.xw+2,x2:G.right,y1:0,y2:0},defs);
 el('stop',{offset:0,'stop-color':'white'},fade);el('stop',{offset:1,'stop-color':'white','stop-opacity':0},fade);
 const mask=el('mask',{id:prefix+'mask',maskUnits:'userSpaceOnUse',x:-10,y:G.yB-20,width:G.right+20,height:G.BOT-G.yB+60},defs);
 el('rect',{x:-10,y:G.yB-20,width:G.xw+12,height:G.BOT-G.yB+60,fill:'white'},mask);el('rect',{x:G.xw+2,y:G.yB-20,width:G.right-G.xw,height:G.BOT-G.yB+60,fill:`url(#${prefix}fade)`},mask);
 // Guide slot in the side wall (drawn under the plug's lug).
 el('rect',{x:G.X0,y:G.BOT+2,width:G.D+G.LUG,height:5,fill:'#f4f5f7',stroke:'#6b737d','stroke-width':mini?1.6:.8},root);
 const plug=el('g',{'data-plug':''},el('g',{mask:`url(#${prefix}mask)`},root)),u0=((G.cx-G.X0)%period+period)%period;
 el('path',{d:`M${-NOSE} ${G.BOT} L0 ${yb} H${G.LP} V${G.BOT} Z`,fill:'#cfd2d6',stroke:'black','stroke-width':lw*.55,'stroke-linejoin':'round','data-plug-nose':''},plug);
 el('path',{d:rackPath(0,G.LP,G.pitchY,period,u0).replace(/^M\S+ \S+/,`M0 ${G.pitchY+DED}`),fill:'none',stroke:'#4a525c','stroke-width':mini?1.6:.9,'stroke-linejoin':'round','clip-path':`url(#${prefix}plugclip)`,'data-rack':''},plug);
 const pc=el('clipPath',{id:prefix+'plugclip'},defs);el('rect',{x:.5,y:yb,width:G.LP-1,height:G.BOT-yb},pc);
 el('rect',{x:0,y:G.BOT-1,width:G.LUG,height:8,fill:'#4a525c',stroke:'black','stroke-width':mini?1.4:.8},plug);

 // One axle fixes the wheel, gear and hub to the same center. Only their
 // angles change independently when the clutch slips at a travel stop.
 const axle=el('g',{transform:`translate(${G.cx} ${G.hub})`,'data-memristor-axle':''},root);
 const paddles=el('g',{'data-memristor-wheel':''},axle),np=6;
 // Water in each pocket turns with the paddles: particles across the whole arm,
 // shown only in the through-flow sector — from where the gap enters the wheel
 // (lower left), round the bottom and right, to where it leaves into port b.
 // Pockets returning over the top-left carry no net flow and stay clear.
 const rings=mini?[.42,.78]:[.3,.5,.7,.88],pocket=[];
 for(let k=0;k<np;k++)for(const f of rings){const r=f*(G.rp-2),m=Math.max(1,Math.round(r*2*Math.PI/np/(mini?26:11)));
  for(let j=0;j<m;j++){const a=(k+(j+.5)/m)*2*Math.PI/np;pocket.push({a,dot:el('circle',{cx:(r*Math.cos(a)).toFixed(2),cy:(r*Math.sin(a)).toFixed(2),r:dotR,fill:'white','data-pocket-particle':''},paddles)});}}
 const thIn=Math.PI-Math.asin(clamp((G.TOP-G.hub)/G.rp,-1,1)),thOut=-Math.acos(clamp(G.d/G.rp,-1,1)),fadeW=.14;
 for(let k=0;k<np;k++){const a=k*2*Math.PI/np;el('line',{x1:3.5*Math.cos(a),y1:3.5*Math.sin(a),x2:G.rp*Math.cos(a),y2:G.rp*Math.sin(a),stroke:k?'#333':'#075e9d','stroke-width':k?(mini?3:1.8):(mini?4.5:3)},paddles);}
 // Side gear sits behind the housing face: drawn before the walls.
 const ring=el('g',{'data-memristor-gear':''},axle);
 el('path',{d:gearPath(G.rg,G.N),fill:'none',stroke:'#3d444c','stroke-width':mini?1.8:.9,'stroke-linejoin':'round'},ring);
 const clutch=el('circle',{cx:0,cy:0,r:mini?6.5:4.5,fill:'#eee',stroke:'black','stroke-width':1.2,'data-memristor-hub':''},axle);
 el('circle',{cx:0,cy:0,r:mini?2.4:1.6,fill:'#333'},axle);
 // Casing shares the axle origin. Split the upstream arc at the left and top
 // of the circle: a single short arc would select the other possible center
 // when the inlet-to-outlet sweep exceeds half a turn.
 const arc=`A${G.R} ${G.R} 0 0 1`,casing=[
  `M${G.xa-G.cx} ${G.TOP-G.hub} ${arc} ${-G.R} 0 ${arc} 0 ${-G.R} ${arc} ${G.d} ${G.yA-G.hub}`,
  `M${G.R} 0 ${arc} ${G.xw-G.cx} ${yb-G.hub}`].join(' ');
 el('path',{d:casing,fill:'none',stroke:'black','stroke-width':lw,'data-memristor-outline':''},axle);
 // Straight housing walls join the circular casing to the inlet and riser.
 const walls=[`M${G.IN} ${G.TOP} H${G.xa} M${G.cx+G.d} ${G.yA} V${G.yB}`,
  `M${G.cx+G.R} ${G.yB} V${G.hub}`,`M${G.IN} ${G.BOT} H${G.xw}`].join(' ');
 el('path',{d:walls,fill:'none',stroke:'black','stroke-width':lw,'stroke-linejoin':'round'},root);
 // Seal where the plug leaves the housing.
 el('path',{d:`M${G.xw-2.5} ${yb-1} h5 M${G.xw} ${G.BOT-1} v5`,stroke:'black','stroke-width':lw,fill:'none'},root);
 el('path',{d:`M${G.IN} ${G.TOP-5} V${G.BOT+5} M${G.rx-G.PW/2-5} ${G.yB} H${G.rx+G.PW/2+5}`,stroke:'black','stroke-width':lw},root);
 for(const lane of lanes){const len=lane.kind==='in'?0:table(outletLane(lane.lam,G)).at(-1).u/G.PW,n=lane.kind==='in'?(mini?10:24):Math.max(2,Math.round(len/(mini?26:12))); for(let j=0;j<n;j++)lane.dots.push(el('circle',{r:dotR,fill:'white'},flowLayer));}
 const gain=areaGain(p,1),rad2deg=180/Math.PI,gearZero=Math.PI/2-Math.PI/G.N;
 for(const [k,v] of Object.entries({period,teeth:G.N,pitchRadius:G.rg,hub:G.cx,x0:G.X0,d:D,rackU0:u0}))root.dataset[k]=v;
 return {update(s){
  const T=G.X0+s.x*D,pa=s.pa,pb=s.pb,pTip=pa-s.i*p.Ron*s.x;
  stops[0].setAttribute('stop-color',color(pa));stops[1].setAttribute('offset',s.x);stops[1].setAttribute('stop-color',color(pTip));stops[2].setAttribute('stop-color',color(pb));
  plug.setAttribute('transform',`translate(${T.toFixed(3)} 0)`);
  root.setAttribute('data-tip',T.toFixed(3));root.setAttribute('data-x',s.x.toFixed(6));
  // Keep the label on the part of the plug still inside the housing.
  // Rolling without slip: plug travel s·D = −rg·Δθ (counter-clockwise when moving right).
  const gear=gearZero-s.x*D/G.rg,pad=gearZero-(p.x0+s.q/p.QD)*D/G.rg;
  ring.setAttribute('transform',`rotate(${(gear*rad2deg).toFixed(3)})`);
  paddles.setAttribute('transform',`rotate(${(pad*rad2deg).toFixed(3)})`);
  for(const p of pocket){let th=((p.a+pad)%(2*Math.PI)+3*Math.PI)%(2*Math.PI)-Math.PI;const o=Math.min(smooth((th-thOut)/fadeW),smooth((thIn-th)/fadeW));p.dot.setAttribute('opacity',o.toFixed(2));}
  root.setAttribute('data-gear-rad',gear);root.setAttribute('data-paddle-rad',pad);
  const sl=slip(s.F,s.i),slipping=sl>SLIP_SHOWN;
  clutch.setAttribute('fill',slipping?'#f2b84b':'#eee');root.setAttribute('data-slip',slipping?'1':'0');
  for(const lane of lanes)placeDots(lane.dots,table(lane.kind==='in'?passageLane(lane.lam,T,G):outletLane(lane.lam,G)),s.q*gain);
 }};
}


function draw(c,ctx){
 if(c.type!=='memristor')return false;
 const {g:parent,el,text,updates,color,pressure}=ctx,p=EditorMemristorModel.parameters(c);
 const root=el('g',{transform:'translate(-95 -59) scale(.5)','data-memristor':c.id},parent),G=geometry(p);
 // A standard 12-unit riser reaches the fixed b port, even when the gap changes.
 const neckPath=`M410 -162 V${Math.min(-162,G.yB)-14} H${G.rx} V${G.yB}`,neck=el('path',{d:neckPath,fill:'none',stroke:'black','stroke-width':27},root);
 const neckWater=el('path',{d:neckPath,fill:'none','stroke-width':24},root);
 const neckDots=Array.from({length:6},()=>el('circle',{r:4.4,fill:'white','data-memristor-neck':''},root)),neckLen=neckWater.getTotalLength();
 const device=buildDevice(root,{p,el,color,prefix:'ed-mem-'+c.id+(ctx.detail?'-detail-':'-')});
 const inlet=el('path',{d:'M-90 -6 L-80 -9 V9 L-90 6 Z',stroke:'black','stroke-width':1.5},parent);
 text(parent,-85,-16,'a +',{'font-size':10});text(parent,120,-135,'b',{'font-size':10});
 const note=text(parent,-20,40,'',{'text-anchor':'middle','font-size':11,'data-memristor-reading':''});
 updates.push((v,s)=>{const mem=v?.memristors?.[c.id]||EditorMemristorModel.sample(c,p.x0,0,0),i=s.currents[c.id]||0;
  device.update({x:mem.x,M:mem.resistance,F:mem.window,i,q:s.volumes[c.id]||0,pa:pressure(s,'a'),pb:pressure(s,'b')});
  inlet.setAttribute('fill',color(pressure(s,'a')));neckWater.setAttribute('stroke',color(pressure(s,'b')));const travel=-(s.volumes[c.id]||0)*areaGain(p,1)/G.PW;neckDots.forEach((dot,k)=>{const distance=((k*neckLen/neckDots.length+travel)%neckLen+neckLen)%neckLen,point=neckWater.getPointAtLength(distance);dot.setAttribute('cx',point.x);dot.setAttribute('cy',point.y);});note.textContent=`${Number(mem.resistance.toPrecision(3))} Ω · x ${mem.x.toFixed(2)}`;
  root.dataset.resistance=mem.resistance;root.dataset.current=i;
 });return true;
}
const api={draw,geometry,passageLane,outletLane};if(typeof module!=='undefined')module.exports=api;else g.EditorMemristor=api;
})(globalThis);
