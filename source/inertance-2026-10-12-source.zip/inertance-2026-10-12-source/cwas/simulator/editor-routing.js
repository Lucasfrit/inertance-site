/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
(function(g){
const D=typeof module!=='undefined'?require('./editor-document.js'):g.CircuitDocument;
function routeAll(doc){const results=[],occupied=new Set(),segments=[],nets=D.nets(doc),boxes=doc.components.filter(c=>c.type!=='junction').map(c=>({...D.bounds(c,9),id:c.id}));
const blocked=(x,y)=>boxes.some(b=>x>b.x&&x<b.x+b.w&&y>b.y&&y<b.y+b.h),segClear=(a,b,skip=[])=>!boxes.some(r=>!skip.includes(r.id)&&(a.x===b.x?a.x>r.x&&a.x<r.x+r.w&&Math.max(a.y,b.y)>r.y&&Math.min(a.y,b.y)<r.y+r.h:a.y>r.y&&a.y<r.y+r.h&&Math.max(a.x,b.x)>r.x&&Math.min(a.x,b.x)<r.x+r.w));
// Different electrical nets may cross, but must never share a length of pipe.
const overlapLength=(a,b,net)=>segments.reduce((sum,s)=>{if(s.net===net)return sum;const horizontal=a.y===b.y;if(horizontal!==(s.a.y===s.b.y)||(horizontal?a.y!==s.a.y:a.x!==s.a.x))return sum;const axis=horizontal?'x':'y';return sum+Math.max(0,Math.min(Math.max(a[axis],b[axis]),Math.max(s.a[axis],s.b[axis]))-Math.max(Math.min(a[axis],b[axis]),Math.min(s.a[axis],s.b[axis])));},0),remember=(points,wire)=>{for(let j=1;j<points.length;j++)segments.push({a:points[j-1],b:points[j],net:nets[D.key(wire.from)]});};
// Allocate distinct exits at a junction: three/four branches must not share a spoke.
const exits={};for(const c of doc.components.filter(c=>c.type==='junction')){const incident=doc.wires.filter(w=>w.from.component===c.id||w.to.component===c.id);if(incident.length<3||incident.length>4)continue;const dirs=[[1,0],[0,1],[-1,0],[0,-1]];let best=null;
function assign(j,used,chosen,cost){if(j===incident.length){if(!best||cost<best.cost)best={chosen:[...chosen],cost};return;}const w=incident[j],end=w.from.component===c.id?w.to:w.from,q=D.port(doc.components.find(o=>o.id===end.component),end.port),len=Math.hypot(q.x-c.x,q.y-c.y)||1;for(let k=0;k<4;k++){if(used.includes(k))continue;assign(j+1,[...used,k],[...chosen,k],cost+1-((q.x-c.x)*dirs[k][0]+(q.y-c.y)*dirs[k][1])/len);}}
assign(0,[],[],0);incident.forEach((w,j)=>exits[c.id+'|'+w.id]=dirs[best.chosen[j]]);}
for(const wire of doc.wires){if(wire.waypoints?.length){const temp=D.clone(doc),ends=[wire.from];wire.waypoints.forEach((p,j)=>{let id='RoutePoint'+j;while(temp.components.some(c=>c.id===id))id+='x';temp.components.push({id,type:'junction',value:0,rotation:0,...p});ends.push({component:id,port:'j'});});ends.push(wire.to);temp.wires=ends.slice(1).map((to,j)=>({id:'RouteSegment'+j,from:ends[j],to}));const pieces=routeAll(temp);results.push({wire,points:pieces.flatMap((r,j)=>j?r.points.slice(1):r.points),failed:pieces.some(r=>r.failed)});remember(results.at(-1).points,wire);continue;}const ca=doc.components.find(c=>c.id===wire.from.component),cb=doc.components.find(c=>c.id===wire.to.component),a=D.port(ca,wire.from.port),b=D.port(cb,wire.to.port);let points,failed=false;const net=nets[D.key(wire.from)],clear=(p,q)=>segClear(p,q,[ca.id,cb.id])&&overlapLength(p,q,net)<.01;for(const [c,p]of [[ca,a],[cb,b]]){const dir=exits[c.id+'|'+wire.id];if(dir){p.nx=dir[0];p.ny=dir[1];}}
const outward=(p,q)=>!p.nx&&!p.ny||(q.x-p.x)*p.nx+(q.y-p.y)*p.ny>1e-8;
const junction=ca.type==='junction'?a:cb.type==='junction'?b:null,other=ca.type==='junction'?b:a;
const elbowCandidates=[{x:a.x,y:b.y},{x:b.x,y:a.y}],simple=elbowCandidates.find(p=>outward(a,p)&&outward(b,p)&&Math.hypot(p.x-a.x,p.y-a.y)>0&&Math.hypot(p.x-b.x,p.y-b.y)>0&&clear(a,p)&&clear(p,b));
const corner=junction?(other.ny?{x:other.x,y:junction.y}:{x:junction.x,y:other.y}):null;
if((a.x===b.x||a.y===b.y)&&outward(a,b)&&outward(b,a)&&clear(a,b))points=[a,b];
else if(!junction&&simple)points=[a,simple,b];
else if(junction&&outward(junction,corner)&&outward(other,corner)&&clear(other,corner)&&clear(corner,junction))points=[a,corner,b];
else{
const start={x:Math.round((a.x+a.nx*25)/10)*10,y:Math.round((a.y+a.ny*25)/10)*10},end={x:Math.round((b.x+b.nx*25)/10)*10,y:Math.round((b.y+b.ny*25)/10)*10};
const minX=Math.min(0,...doc.components.map(c=>c.x-140)),maxX=Math.max(900,...doc.components.map(c=>c.x+140)),minY=Math.min(0,...doc.components.map(c=>c.y-140)),maxY=Math.max(520,...doc.components.map(c=>c.y+140)),key=(x,y)=>x+','+y,goal=key(end.x,end.y),initial=key(start.x,start.y),open=[{...start,k:initial,g:0,f:0,dir:-1}],scores=new Map([[initial,0]]),back=new Map();let found=false,steps=0;
while(open.length&&steps++<14000){let best=0;for(let j=1;j<open.length;j++)if(open[j].f<open[best].f)best=j;const cur=open.splice(best,1)[0];if(cur.k===goal){found=true;break;}if(cur.g!==scores.get(cur.k))continue;for(const[dx,dy,dir]of[[10,0,0],[-10,0,0],[0,10,1],[0,-10,1]]){const x=cur.x+dx,y=cur.y+dy,k=key(x,y);if(x<minX||x>maxX||y<minY||y>maxY||(k!==goal&&k!==initial&&blocked(x,y)))continue;const shared=segments.some(s=>s.net===net&&(dx?s.a.y===y&&s.b.y===y&&Math.min(s.a.x,s.b.x)<=Math.min(cur.x,x)&&Math.max(s.a.x,s.b.x)>=Math.max(cur.x,x):s.a.x===x&&s.b.x===x&&Math.min(s.a.y,s.b.y)<=Math.min(cur.y,y)&&Math.max(s.a.y,s.b.y)>=Math.max(cur.y,y)));const cost=cur.g+10+(cur.dir!==-1&&cur.dir!==dir?9:0)+(!shared&&occupied.has(k)?12:0)+overlapLength(cur,{x,y},net)*1000;if(cost>=(scores.get(k)??Infinity))continue;scores.set(k,cost);back.set(k,cur.k);open.push({x,y,k,g:cost,dir,f:cost+Math.abs(end.x-x)+Math.abs(end.y-y)});}}
if(found){let k=goal;const path=[];while(k){const[x,y]=k.split(',').map(Number);path.push({x,y});k=back.get(k);}points=[a,a.nx?{x:start.x,y:a.y}:{x:a.x,y:start.y},...path.reverse(),b.nx?{x:end.x,y:b.y}:{x:b.x,y:end.y},b];}else{failed=true;points=[a,a.nx?{x:start.x,y:a.y}:{x:a.x,y:start.y},start,{x:end.x,y:start.y},end,b.nx?{x:end.x,y:b.y}:{x:b.x,y:end.y},b];}}
points=points.filter((p,j)=>!j||p.x!==points[j-1].x||p.y!==points[j-1].y);let clean=[];for(const p of points){while(clean.length>=2){const u=clean.at(-2),v=clean.at(-1);if((u.x===v.x&&v.x===p.x)||(u.y===v.y&&v.y===p.y))clean.pop();else break;}clean.push(p);}// Smooth grid-sized doglegs using continuous-coordinate shortcuts. Keep fitting
// tangents, body clearance and electrical-net separation, not just a shorter line.
const simplify=ps=>{const out=[];for(const p of ps){if(out.length&&p.x===out.at(-1).x&&p.y===out.at(-1).y)continue;while(out.length>1){const a=out.at(-2),b=out.at(-1);if((a.x===b.x&&b.x===p.x&&(b.y-a.y)*(p.y-b.y)>=0)||(a.y===b.y&&b.y===p.y&&(b.x-a.x)*(p.x-b.x)>=0))out.pop();else break;}out.push(p);}return out;};
const shapeCost=ps=>ps.slice(1).reduce((sum,p,j)=>{const q=ps[j],length=Math.abs(p.x-q.x)+Math.abs(p.y-q.y),clearance=(j>0?14:0)+(j<ps.length-2?14:0);return sum+length+80*Math.max(0,clearance-length);},30*Math.max(0,ps.length-2));
for(let pass=0;pass<2;pass++){let best=clean,cost=shapeCost(clean);for(let i=0;i<clean.length-2;i++)for(let j=i+2;j<clean.length;j++)for(const corner of [{x:clean[i].x,y:clean[j].y},{x:clean[j].x,y:clean[i].y}]){const trial=simplify([...clean.slice(0,i+1),corner,...clean.slice(j)]);if(trial.length<2||!outward(a,trial[1])||!outward(b,trial.at(-2)))continue;const next=shapeCost(trial);if(next>=cost)continue;let valid=true;for(let k=1;k<trial.length;k++){const skip=[...(k===1?[ca.id]:[]),...(k===trial.length-1?[cb.id]:[])];if(!segClear(trial[k-1],trial[k],skip)||overlapLength(trial[k-1],trial[k],net)>.01){valid=false;break;}}if(valid){best=trial;cost=next;}}if(best===clean)break;clean=best;}
for(let j=1;j<clean.length;j++){const a=clean[j-1],b=clean[j],n=Math.max(Math.abs(b.x-a.x),Math.abs(b.y-a.y))/10;for(let k=0;k<=n;k++)occupied.add(Math.round((a.x+(b.x-a.x)*k/Math.max(1,n))/10)*10+','+Math.round((a.y+(b.y-a.y)*k/Math.max(1,n))/10)*10);}remember(clean,wire);results.push({wire,points:clean,failed});}
return results;}
function junctions(doc,routes){
 const net=D.nets(doc),segments=[],points=new Map(),key=(n,x,y)=>n+'|'+x.toFixed(5)+','+y.toFixed(5);
 for(const route of routes){const n=net[D.key(route.wire.from)],signal=[route.wire.from,route.wire.to].some(e=>doc.components.find(c=>c.id===e.component)?.type==='pressuremeter');
 for(const p of route.points)points.set(key(n,p.x,p.y),{...p,net:n});
 for(let j=1;j<route.points.length;j++)segments.push({a:route.points[j-1],b:route.points[j],net:n,width:signal?2:12});}
 for(const a of segments)for(const b of segments){if(a.net!==b.net||a.a.y!==a.b.y||b.a.x!==b.b.x)continue;const x=b.a.x,y=a.a.y;if(x>=Math.min(a.a.x,a.b.x)&&x<=Math.max(a.a.x,a.b.x)&&y>=Math.min(b.a.y,b.b.y)&&y<=Math.max(b.a.y,b.b.y))points.set(key(a.net,x,y),{x,y,net:a.net});}
 const result=[];
 for(const p of points.values()){const arms={};for(const s of segments){if(s.net!==p.net)continue;const h=s.a.y===s.b.y,axis=h?'x':'y',cross=h?'y':'x';if(Math.abs(p[cross]-s.a[cross])>1e-5||p[axis]<Math.min(s.a[axis],s.b[axis])-1e-5||p[axis]>Math.max(s.a[axis],s.b[axis])+1e-5)continue;for(const q of [s.a,s.b]){const length=Math.abs(q[axis]-p[axis]);if(length<1e-5)continue;const dir=h?(q.x>p.x?'E':'W'):(q.y>p.y?'S':'N');arms[dir]={width:Math.max(arms[dir]?.width||0,s.width),length:Math.max(arms[dir]?.length||0,length)};}}
 if(Object.keys(arms).length>=3)result.push({...p,arms});
 }
 return result;
}

function crossings(doc,routes){
 const net=D.nets(doc),ss=[],found=new Map();
 for(const route of routes)for(let j=1;j<route.points.length;j++)ss.push({a:route.points[j-1],b:route.points[j],route,net:net[D.key(route.wire.from)]});
 for(const h of ss.filter(s=>s.a.y===s.b.y))for(const v of ss.filter(s=>s.a.x===s.b.x)){
 if(h.net===v.net)continue;const x=v.a.x,y=h.a.y,clearH=Math.min(x-Math.min(h.a.x,h.b.x),Math.max(h.a.x,h.b.x)-x),clearV=Math.min(y-Math.min(v.a.y,v.b.y),Math.max(v.a.y,v.b.y)-y);
 if(clearH<2||clearV<2)continue;
 const signal=route=>[route.wire.from,route.wire.to].some(e=>doc.components.find(c=>c.id===e.component)?.type==='pressuremeter');
 found.set(x+','+y,{x,y,top:h.net,under:v.net,topWire:h.route.wire.id,underWire:v.route.wire.id,topWidth:signal(h.route)?2:12,underWidth:signal(v.route)?2:12,reach:Math.min(23,clearV*.7),halfTop:Math.min(20,clearH*.7)});
 }return [...found.values()];
}

function path(points){let d=`M${points[0].x} ${points[0].y}`;for(let j=1;j<points.length-1;j++){const a=points[j-1],p=points[j],b=points[j+1],before=Math.hypot(a.x-p.x,a.y-p.y),after=Math.hypot(b.x-p.x,b.y-p.y),r=Math.min(14,before/2,after/2);if(!r)continue;d+=` L${p.x+(a.x-p.x)*r/before} ${p.y+(a.y-p.y)*r/before} Q${p.x} ${p.y} ${p.x+(b.x-p.x)*r/after} ${p.y+(b.y-p.y)*r/after}`;}return d+` L${points.at(-1).x} ${points.at(-1).y}`;}
function layoutScore(doc){const routes=routeAll(doc);let score=0;const segments=[];for(const route of routes){score+=route.failed?100000:0;score+=Math.max(0,route.points.length-2)*35;for(let j=1;j<route.points.length;j++){const a=route.points[j-1],b=route.points[j];score+=Math.hypot(a.x-b.x,a.y-b.y);segments.push({a,b,id:route.wire.id});}}
for(let i=0;i<segments.length;i++)for(let j=i+1;j<segments.length;j++){const a=segments[i],b=segments[j];if(a.id===b.id)continue;const h=a.a.y===a.b.y?a:b,v=h===a?b:a;if(h.a.y!==h.b.y||v.a.x!==v.b.x)continue;if(v.a.x>Math.min(h.a.x,h.b.x)&&v.a.x<Math.max(h.a.x,h.b.x)&&h.a.y>Math.min(v.a.y,v.b.y)&&h.a.y<Math.max(v.a.y,v.b.y))score+=1500;}
const boxes=doc.components.filter(c=>c.type!=='junction').map(c=>D.bounds(c,20));for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){const a=boxes[i],b=boxes[j];if(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y)score+=10000;}return score;}
function arrange(doc){const source=doc.components.find(c=>c.type==='source'),rest=doc.components.filter(c=>c!==source),candidates=[D.clone(doc),D.arrange(doc)];for(const order of [[...rest].reverse(),[...rest].sort((a,b)=>a.type.localeCompare(b.type))])candidates.push(D.arrange({...D.clone(doc),components:[...(source?[source]:[]),...order]}));let best=candidates[0],bestScore=layoutScore(best);for(const candidate of candidates.slice(1)){const movement=candidate.components.reduce((sum,c)=>{const old=doc.components.find(o=>o.id===c.id);return sum+Math.hypot(c.x-old.x,c.y-old.y);},0);const score=layoutScore(candidate)+movement*.01;if(score<bestScore){best=candidate;bestScore=score;}}return best;}
const api={crossings,junctions,routeAll,path,arrange,layoutScore};if(typeof module!=='undefined')module.exports=api;else g.CircuitRouting=api;
})(globalThis);
