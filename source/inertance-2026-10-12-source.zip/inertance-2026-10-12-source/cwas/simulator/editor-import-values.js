/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Literal values only. Import never evaluates expressions or executes content. */
(function(g){
const scales={t:1e12,g:1e9,meg:1e6,k:1e3,m:1e-3,u:1e-6,n:1e-9,p:1e-12,f:1e-15,mil:25.4e-6};
function value(text,{spice=false,unit=''}={}){
 text=String(text).trim().replace(/[µμ]/g,'u');
 if(!spice){
  const embedded=text.match(/^(\d+)([RrKkMm])(\d+)$/);
  if(embedded&&unit==='R')return Number(embedded[1]+'.'+embedded[3])*({R:1,r:1,K:1e3,k:1e3,M:1e6,m:1e-3}[embedded[2]]);
 }
 const m=text.match(/^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)([a-zA-ZΩ]*)$/i);
 if(!m)throw Error('Use a literal numeric value with a supported unit suffix; expressions and parameters are unsupported: '+text);
 let suffix=m[2],scale=1;
 if(spice){
  const lower=suffix.toLowerCase(),prefix=['meg','mil','t','g','k','m','u','n','p','f'].find(s=>lower.startsWith(s));
  // LTspice ignores trailing letters after the multiplier, but arbitrary names
  // are rejected here to avoid treating a model name as a numeric literal.
  if(prefix){scale=scales[prefix];suffix=suffix.slice(prefix.length);}
  if(suffix&&!/^(?:ohms?|[rhvfs]|Ω)$/i.test(suffix))throw Error('Unsupported value suffix: '+text);
 }else{
  const units={R:/^(?:Ω|ohms?|R)$/i,C:/^F$/,L:/^H$/,V:/^V$/};
  if(suffix&&units[unit]?.test(suffix))suffix='';
  else if(suffix){const prefix=suffix.match(/^(meg|[TGMkKmunpfu])/);if(!prefix)throw Error('Unsupported value suffix: '+text);scale=prefix[1]==='M'?1e6:scales[prefix[1].toLowerCase()];suffix=suffix.slice(prefix[1].length);if(suffix&&!units[unit]?.test(suffix))throw Error('Wrong unit for '+unit+': '+text);}
 }
 const result=Number(m[1])*scale;if(!Number.isFinite(result))throw Error('Value is not finite: '+text);return result;
}
const api={value};if(typeof module!=='undefined')module.exports=api;else g.CircuitImportValues=api;
})(globalThis);
