/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Circuit-derived waveform annotations. KVL/KCL use the solved graph, not preset IDs.
   Expressions describe instantaneous signals, not a fictitious steady-state peak. */
(function(g){
const D=typeof module!=='undefined'?require('./editor-document.js'):g.CircuitDocument;
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
const symbol=(name,id)=>`<msub><mi>${name}</mi><mtext>${escape(id)}</mtext></msub>`;
const timed=(name,id)=>symbol(name,id)+'<mo>(</mo><mi>t</mi><mo>)</mo>';
const sum=terms=>terms.length?terms.map((x,j)=>(x.sign<0?'<mo>−</mo>':j?'<mo>+</mo>':'')+(x.sign<0&&x.math.includes('<mo>+</mo>')?'<mo>(</mo>'+x.math+'<mo>)</mo>':x.math)).join(''):'<mn>0</mn>';
function create(doc,model){
 const solved=model.effectiveDocument||doc,net=model.net||D.nets(solved),edges=[];
 for(const c of solved.components){if(c.type==='junction')continue;const count=c.type.startsWith('coupled')?Object.keys(D.types[c.type].ports).length/2:1;
  for(let j=0;j<count;j++){const ports=count>1?['p'+(j+1),'n'+(j+1)]:Object.keys(D.types[c.type].ports),id=count>1?c.id+'.w'+(j+1):c.id;edges.push({c,id,owner:c.id,winding:j,a:net[c.id+'.'+ports[0]],b:net[c.id+'.'+ports[1]],type:count>1?'winding':c.type});}
 }
 const voltage=(e,s)=>(s.state.pressure[e.a]??0)-(s.state.pressure[e.b]??0),current=(e,s)=>s.state.currents[e.c.bodyDiode?e.id+'.total':e.id]??0;
 const atom=(name,id,value,cost=2)=>({math:timed(name,id),value,cost});
 function law(id,winding,key){
  const e=edges.find(e=>e.owner===id&&e.winding===(winding||0));if(!e||!['voltage','current'].includes(key))return null;
  const derivative=(name,id)=>'<mfrac><mrow><mi>d</mi>'+timed(name,id)+'</mrow><mrow><mi>d</mi><mi>t</mi></mrow></mfrac>';
  const lhs=timed(key==='voltage'?'v':'i',e.id)+'<mo>=</mo>';
  if(e.type==='memristor')return lhs+(key==='voltage'?timed('M',e.id)+timed('i',e.id):'<mfrac><mrow>'+timed('v',e.id)+'</mrow><mrow>'+timed('M',e.id)+'</mrow></mfrac>');
  if(e.type==='inductor'&&key==='voltage')return lhs+symbol('L',e.id)+derivative('i',e.id);
  if(e.type==='capacitor'&&key==='current')return lhs+symbol('C',e.id)+derivative('v',e.id);
  if(e.type==='capacitor'&&key==='voltage')return lhs+'<mfrac><mrow>'+timed('q',e.id)+'</mrow><mrow>'+symbol('C',e.id)+'</mrow></mfrac>';
  if(e.type==='winding'&&key==='voltage')return lhs+edges.filter(other=>other.owner===id).map((other,j)=>(j?'<mo>+</mo>':'')+symbol('L',e.id+', '+other.id)+derivative('i',other.id)).join('');
  return null;
 }
 function drop(e,s){
  const i=current(e,s),v=voltage(e,s);
  if(['flowmeter','input','output'].includes(e.type))return {math:'<mn>0</mn>',value:0,cost:0};
  if(e.type==='pressuremeter')return null;
  if(e.type==='switch'){
   if(!s.switchStates?.[e.id])return null;
   // Combined switch/body-diode currents are not channel currents.
   const channel=s.state.currents[e.id]??0,r=e.c.ron||0;
   return {math:r?symbol('R',e.id+' · on')+timed('i',e.id+' · channel'):'<mn>0</mn>',value:r*channel,cost:.1};
  }
  if(e.type==='diode'){
   const r=e.c.ron??.01;if(Math.abs(v-e.c.value-r*i)>1e-6*Math.max(1,Math.abs(v)))return null;
   return {math:symbol('V',e.id+' · F')+(r?'<mo>+</mo>'+symbol('R',e.id+' · on')+timed('i',e.id):''),value:e.c.value+r*i,cost:.5};
  }
  if(e.type==='memristor')return {math:timed('M',e.id)+timed('i',e.id),value:s.memristors[e.id].resistance*i,cost:1};
  if(['resistor','load'].includes(e.type))return {math:symbol('R',e.id)+timed('i',e.id),value:e.c.value*i,cost:1};
  return atom('v',e.id,v,e.type==='source'||e.type==='capacitor'?1:4);
 }
 function expression(id,winding,key,s){
  const e=edges.find(e=>e.owner===id&&e.winding===(winding||0));if(!e||!s?.state?.pressure||!['voltage','current'].includes(key))return null;
  const actual=key==='voltage'?voltage(e,s):current(e,s),lhs=timed(key==='voltage'?'v':'i',e.id);let terms=[],method='';
  if(key==='voltage'){
   // Dijkstra through independently known branch drops; exclude the measured branch.
   const todo=[{node:e.a,cost:0,terms:[]}],seen=new Set();let path;
   while(todo.length){todo.sort((a,b)=>a.cost-b.cost);const p=todo.shift();if(seen.has(p.node))continue;seen.add(p.node);if(p.node===e.b){path=p;break;}
    for(const other of edges){if(other===e)continue;const sign=other.a===p.node?1:other.b===p.node?-1:0;if(!sign)continue;const term=drop(other,s);if(!term)continue;todo.push({node:sign===1?other.b:other.a,cost:p.cost+term.cost+.01,terms:[...p.terms,{...term,sign}]});}
   }
   if(path){terms=path.terms.filter(x=>x.math!=='<mn>0</mn>');method='KVL';}
   else if(e.type==='memristor'){terms=[{math:timed('M',e.id)+timed('i',e.id),value:s.memristors[e.id].resistance*current(e,s),sign:1}];method='State-dependent Ohm’s law';}
   else if(['resistor','load'].includes(e.type)){terms=[{math:symbol('R',e.id)+timed('i',e.id),value:actual,sign:1}];method='Ohm’s law';}
   else {terms=[{math:timed('φ',e.a)+'<mo>−</mo>'+timed('φ',e.b),value:actual,sign:1}];method='Terminal potentials';}
  }else{
   if(e.type==='memristor'){terms=[{math:'<mfrac><mrow>'+timed('v',e.id)+'</mrow><mrow>'+timed('M',e.id)+'</mrow></mfrac>',value:actual,sign:1}];method='State-dependent Ohm’s law';}
   else if(['resistor','load'].includes(e.type)){terms=[{math:'<mfrac><mrow>'+timed('v',e.id)+'</mrow><mrow>'+symbol('R',e.id)+'</mrow></mfrac>',value:actual,sign:1}];method='Ohm’s law';}
   else {for(const other of edges){if(other===e)continue;const sign=(other.b===e.a?1:0)-(other.a===e.a?1:0);if(!sign)continue;
     // Open branches carry no current. Keep tiny nonzero solved currents honest.
     const value=current(other,s);if(value===0)continue;terms.push({math:timed('i',other.id),value,sign});}method='KCL';}
  }
  let value=terms.reduce((v,x)=>v+x.sign*x.value,0),residual=Math.abs(value-actual);
  // Reduced teaching models may not conserve instantaneous branch currents.
  // Never show a KCL/KVL claim that disagrees with the waveform being plotted.
  if(residual>1e-6*Math.max(1,Math.abs(actual))){terms=[{math:timed(key==='voltage'?'v':'i',e.id),value:actual,sign:1}];value=actual;method='Solved signal (no validated reduction)';}
  return {math:sum(terms),lhs,equation:lhs+'<mo>=</mo>'+sum(terms),value,actual,residual,method,time:s.t,state:Object.entries(s.switchStates||{}).map(([id,on])=>id+' '+(on?'ON':'OFF')).join(', ')};
 }
 return {expression,law};
}
const api={create,escape,symbol};if(typeof module!=='undefined')module.exports=api;else g.EditorWaveformExpressions=api;
})(globalThis);
