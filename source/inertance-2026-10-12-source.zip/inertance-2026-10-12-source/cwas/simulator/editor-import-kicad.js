/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* KiCad native exported S-expression netlists. No geometry-based connectivity. */
(function(g){
const V=typeof module!=='undefined'?require('./editor-import-values.js'):g.CircuitImportValues;
function sexpr(text){
 let pos=0,count=0;const skip=()=>{while(/\s/.test(text[pos]||'')&&pos<text.length)pos++;};
 function read(depth){
  if(depth>80||++count>100000)throw Error('Netlist nesting or token limit exceeded.');skip();
  if(text[pos]==='('){pos++;const list=[];skip();while(pos<text.length&&text[pos]!==')'){list.push(read(depth+1));skip();}if(text[pos++]!==')')throw Error('Unclosed S-expression.');return list;}
  if(text[pos]==='"'){pos++;let s='';while(pos<text.length){const c=text[pos++];if(c==='"')return s;if(c==='\\'){const next=text[pos++];if(!['"','\\','n','r','t'].includes(next))throw Error('Unsupported quoted escape.');s+=({n:'\n',r:'\r',t:'\t'}[next]??next);}else s+=c;}throw Error('Unclosed quoted string.');}
  const start=pos;while(pos<text.length&&!/[\s()"]/.test(text[pos]))pos++;if(start===pos)throw Error('Unexpected character at offset '+pos+'.');return text.slice(start,pos);
 }
 const root=read(0);skip();if(pos!==text.length)throw Error('Unexpected data after netlist.');return root;
}
const children=(n,key)=>n.filter(v=>Array.isArray(v)&&v[0]===key);
function field(n,key){const all=children(n,key);if(all.length!==1||all[0].length!==2||typeof all[0][1]!=='string')throw Error('Expected exactly one '+key+' field.');return all[0][1];}
function section(n,key){const all=children(n,key);if(all.length!==1)throw Error('Expected exactly one '+key+' section.');return all[0];}
const symbols={R:'R',R_Small:'R',C:'C',C_Small:'C',C_Polarized:'C',C_Polarized_Small:'C',CP:'C',CP1:'C',L:'L',L_Small:'L',Battery:'V',Battery_Cell:'V'};
function parse(text,report){
 const root=sexpr(text);if(!Array.isArray(root)||root[0]!=='export')throw Error('Choose a native KiCad exported netlist (.net), not a schematic or board.');
 const version=field(root,'version');if(!['D','E'].includes(version))throw Error('Supported KiCad netlist versions: D and E. Found '+version+'.');
 const parts=[],byRef=new Map(),pins=new Map(),codes=new Set(),names=new Set();
 for(const c of section(root,'components').slice(1)){
  try{
   if(!Array.isArray(c)||c[0]!=='comp')throw Error('Unexpected component record.');const ref=field(c,'ref'),lib=section(c,'libsource'),name=field(lib,'part'),kind=field(lib,'lib')==='Device'?symbols[name]:undefined;
   if(/memrist/i.test(name))throw Error(ref+': unsupported memristor symbol. Add the native Memristor in Build; no resistor substitution is made.');
   if(!kind)throw Error(ref+': unsupported symbol '+field(lib,'lib')+':'+name+'. Only standard Device R/C/L and Battery/Battery_Cell are supported.');
   // A netlist's simulation properties can change pin order, device model or
   // value. Do not silently ignore those overrides on a nominal passive symbol.
   const encoded=JSON.stringify(c);if(/"(?:Sim\.|Spice|exclude_from_sim)/i.test(encoded))throw Error(ref+': simulation overrides/exclusions are unsupported. Export SPICE or remove overrides deliberately.');
   if(byRef.has(ref))throw Error('Duplicate reference '+ref+'.');
   const value=V.value(field(c,'value'),{unit:kind});if(value<=0)throw Error(ref+': use a positive literal value.');
   const part={ref,kind,value,nodes:[],polarized:['C_Polarized','C_Polarized_Small','CP','CP1'].includes(name)};parts.push(part);byRef.set(ref,part);
  }catch(e){report('error','KICAD_COMPONENT',e.message);}
 }
 for(const n of section(root,'nets').slice(1)){
  try{
   if(!Array.isArray(n)||n[0]!=='net')throw Error('Unexpected net record.');const code=field(n,'code'),name=field(n,'name');if(!code||codes.has(code)||name&&names.has(name))throw Error('Duplicate/empty net code or duplicate name: '+code+' '+name);codes.add(code);if(name)names.add(name);
   const key='net:'+code;
   for(const p of children(n,'node')){const ref=field(p,'ref'),pin=field(p,'pin'),part=byRef.get(ref);if(!part)throw Error('Net '+name+' references unsupported/unknown '+ref+'.');if(!['1','2'].includes(pin))throw Error(ref+': only pins 1 and 2 are supported.');const pk=ref+'\0'+pin;if(pins.has(pk))throw Error(ref+' pin '+pin+' occurs more than once.');pins.set(pk,key);part.nodes[+pin-1]=key;}
   for(const p of parts)if(p.nodes.includes(key))p.netNames={...p.netNames,[key]:name||'Net '+code};
  }catch(e){report('error','KICAD_NET',e.message);}
 }
 for(const p of parts)if(!p.nodes[0]||!p.nodes[1])report('error','MISSING_PIN',p.ref+': both pins must occur in explicit nets. Re-export complete connectivity.');
 const groundNets=parts.flatMap(p=>Object.entries(p.netNames||{})).filter(([,n])=>['GND','0','/GND','/0'].includes(n)).map(([k])=>k),grounds=[...new Set(groundNets)];
 if(grounds.length!==1)report('error','GROUND','Provide exactly one explicit net named GND, 0, /GND or /0. Other named grounds remain separate nets.');
 report('warning','KICAD_MODEL','Connectivity and literal values only: PCB footprints/ratings are not electrical models. Standard Device parts become ideal R/L/C and constant battery sources.');
 return {parts,couplings:[],ground:grounds[0]};
}
const api={parse,sexpr};if(typeof module!=='undefined')module.exports=api;else g.CircuitImportKiCad=api;
})(globalThis);
