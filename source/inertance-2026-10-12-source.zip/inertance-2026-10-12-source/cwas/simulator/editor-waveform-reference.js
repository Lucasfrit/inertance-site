/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Report 1 full-bridge boost state table. Plot-only ideal CCM reference:
   infinite filtering L/C, ideal devices/source feed, symmetric overlap sharing.
   Does not change the numerical model or its animation. T is a half cycle.
   Based on pe1/report1/scripts/analysis.py and the lecture's slide 39.
   Secondary currents follow editor dotted-terminal polarity, not report arrows. */
(function(g){
const node=typeof module!=='undefined',Modes=node?require('./editor-modes.js'):g.EditorModes;
const sub=(base,index)=>`<msub><mi>${base}</mi><mi>${index}</mi></msub>`,Vi=sub('V','i'),Vo=sub('V','o'),Ii=sub('I','i'),Io=sub('I','o'),ratio=`<mfrac>${Vo}<mi>n</mi></mfrac>`,iratio=`<mfrac>${Ii}<mi>n</mi></mfrac>`,zero='<mn>0</mn>',minus=x=>'<mo>−</mo>'+x;
function create(doc,recognition){
 const r=recognition||Modes.recognize(doc);if(r?.type!=='fullboost')return {available:false,reason:'Report-style ideal waveforms currently support the recognized full-bridge boost topology.'};
 const p=r.parts,q=p.Q1,others=[p.Q2,p.Q3,p.Q4],d=q.pwm?.duty,f=q.pwm?.frequency;
 if(!q.pwm||others.some(c=>!c.pwm||Math.abs(c.pwm.duty-d)>1e-9||c.pwm.frequency!==f)||(doc.settings.manualEvents||[]).length||p.V1.waveform==='sine')return {available:false,reason:'The report reference requires equal bridge PWM duties, a common frequency, DC excitation and no manual switching.'};
 const phase=c=>((c.pwm.phase||0)%1+1)%1,near=(a,b)=>Math.min(Math.abs(a-b),1-Math.abs(a-b))<1e-9;
 if(!near(phase(q),phase(p.Q4))||!near(phase(p.Q2),phase(p.Q3))||!near(phase(p.Q2),(phase(q)+.5)%1))return {available:false,reason:'The bridge pairs must be half a period apart, as in the report.'};
 const D=2*d-1,n=(p.T1.turns?.[1]??1)/(p.T1.turns?.[0]??1),n2=(p.T1.turns?.[2]??1)/(p.T1.turns?.[0]??1),vin=p.V1.value;
 if(D<0||D>=1||n<=0||Math.abs(n-n2)>1e-9||vin<=0)return {available:false,reason:'Requires 0 ≤ overlap D < 1, positive DC voltage and equal, positive secondary turns.'};
 const vo=n*vin/(1-D),io=vo/p.Rload.value,ii=vo*io/vin,period=1/f,bounds=[0,D/2,.5,(1+D)/2,1],signals=new Map();
 const item=(value,math)=>({value,math});
 const add=(c,w,voltage,current,vlabels,ilabels)=>signals.set(c.id+(w===null?'':'.w'+(w+1)),{voltage,current,levels:{voltage:[...new Set(voltage)].map(v=>item(v,vlabels[voltage.indexOf(v)])),current:[...new Set(current)].map(v=>item(v,ilabels[current.indexOf(v)]))}});
 const vp=[0,vo/n,0,-vo/n],vs=[0,vo,0,-vo],ip=[0,ii,0,-ii],v14=[0,0,0,vo/n],v23=[0,vo/n,0,0],i14=[ii/2,ii,ii/2,0],i23=[ii/2,0,ii/2,ii],halfi=`<mfrac>${Ii}<mn>2</mn></mfrac>`;
 for(const c of [p.Q1,p.Q4])add(c,null,v14,i14,[zero,zero,zero,ratio],[halfi,Ii,halfi,zero]);
 for(const c of [p.Q2,p.Q3])add(c,null,v23,i23,[zero,ratio,zero,zero],[halfi,zero,halfi,Ii]);
 add(p.Dr1,null,[-vo,0,-vo,-2*vo],[0,ii/n,0,0],[minus(Vo),zero,minus(Vo),minus('<mn>2</mn>'+Vo)],[zero,iratio,zero,zero]);
 add(p.Dr2,null,[-vo,-2*vo,-vo,0],[0,0,0,ii/n],[minus(Vo),minus('<mn>2</mn>'+Vo),minus(Vo),zero],[zero,zero,zero,iratio]);
 add(p.Lin,null,[vin,vin-vo/n,vin,vin-vo/n],[ii,ii,ii,ii],[Vi,Vi+'<mo>−</mo>'+ratio,Vi,Vi+'<mo>−</mo>'+ratio],[Ii,Ii,Ii,Ii]);
 add(p.T1,0,vp,ip,[zero,ratio,zero,minus(ratio)],[zero,Ii,zero,minus(Ii)]);
 add(p.T1,1,vs,[0,-ii/n,0,0],[zero,Vo,zero,minus(Vo)],[zero,minus(iratio),zero,zero]);
 add(p.T1,2,vs,[0,0,0,ii/n],[zero,Vo,zero,minus(Vo)],[zero,zero,zero,iratio]);
 add(p.Ci,null,[vin,vin,vin,vin],[0,0,0,0],[Vi,Vi,Vi,Vi],[zero,zero,zero,zero]);
 add(p.Co,null,[vo,vo,vo,vo],[-io,ii/n-io,-io,ii/n-io],[Vo,Vo,Vo,Vo],[minus(Io),iratio+'<mo>−</mo>'+Io,minus(Io),iratio+'<mo>−</mo>'+Io]);
 add(p.Rload,null,[vo,vo,vo,vo],[io,io,io,io],[Vo,Vo,Vo,Vo],[Io,Io,Io,Io]);
 add(p.V1,null,[vin,vin,vin,vin],[-ii,-ii,-ii,-ii],[Vi,Vi,Vi,Vi],[minus(Ii),minus(Ii),minus(Ii),minus(Ii)]);
 add(p.Rin,null,[0,0,0,0],[ii,ii,ii,ii],[zero,zero,zero,zero],[Ii,Ii,Ii,Ii]);
 return {available:true,D,n,vin,vo,io,ii,period,bounds,signals,note:'Ideal CCM report reference · infinite filtering L/C · symmetric overlap current sharing · ideal source feed. T = half cycle, 2T = bridge period. Secondary current is positive into the dotted terminal.',signal(id,winding){return signals.get(id+(winding===null?'':'.w'+(winding+1)));},at(signal,time){const phase=Math.max(0,Math.min(1,time/period));let state=3;for(let j=0;j<4;j++)if(phase<bounds[j+1]){state=j;break;}return {voltage:signal.voltage[state],current:signal.current[state]};},samples(signal){const result=[];for(let j=0;j<4;j++){if(bounds[j+1]<=bounds[j])continue;result.push({t:bounds[j]*period,voltage:signal.voltage[j],current:signal.current[j]},{t:bounds[j+1]*period,voltage:signal.voltage[j],current:signal.current[j]});}return result;}};
}
const api={create};if(node)module.exports=api;else g.EditorWaveformReference=api;
})(globalThis);
