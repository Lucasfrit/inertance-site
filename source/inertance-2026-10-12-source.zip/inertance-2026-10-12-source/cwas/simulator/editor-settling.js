/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Bounded periodic solving. Displayed time starts at zero; sourceTime records the
   solved physical time. No averaged state or invented initialization is used. */
(function(g){
const node=typeof module!=='undefined',D=node?require('./editor-document.js'):g.CircuitDocument;
function excitation(doc){
 if((doc.settings.manualEvents||[]).length)throw Error('Steady-state unavailable with manual switching. Enable Transients.');
 const switches=doc.components.filter(c=>c.type==='switch'),pwms=switches.filter(c=>c.pwm),sines=doc.components.filter(c=>c.type==='source'&&c.waveform==='sine');
 if(switches.some(c=>!c.pwm))throw Error('Steady-state unavailable for a single switching pulse. Enable Transients.');
 const f=pwms[0]?.pwm.frequency||(sines.length?(sines[0].frequency||50):0);
 if(!f)throw Error('Steady-state unavailable: no periodic excitation. Enable Transients to inspect this circuit.');
 if(pwms.some(c=>c.pwm.frequency!==f)||sines.some(c=>(c.frequency||50)!==f))throw Error('Steady-state unavailable: excitation frequencies must match. Enable Transients.');
 return {period:1/f,kind:pwms.length?'PWM':'sine',phases:pwms.flatMap(c=>[c.pwm.phase||0,(c.pwm.phase||0)+c.pwm.duty])};
}
function check(model,doc,ex=excitation(doc)){
 const T=ex.period,end=model.duration;if(end<5*T-1e-12)throw Error('Run at least five periodic cycles to verify four displayed cycles.');
 const phases=new Set(Array.from({length:128},(_,j)=>(j+.5)/128));for(const p of [0,...ex.phases])for(const side of [-1,1])phases.add(((p+side*1e-7)%1+1)%1);
 const read=s=>doc.components.flatMap(c=>c.type==='capacitor'?[(s.state.pressure[model.net[c.id+'.p']]-s.state.pressure[model.net[c.id+'.n']])]:c.type==='memristor'?[s.memristors[c.id].x]:c.type==='inductor'?[s.state.currents[c.id]]:c.type.startsWith('coupled')?(c.coupling===1?[s.magnetics[c.id].fluxCurrent]:s.magnetics[c.id].currents):[]);
 const floors=doc.components.flatMap(c=>c.type==='capacitor'?[1]:c.type==='memristor'?[1]:c.type==='inductor'?[.1]:c.type.startsWith('coupled')?Array(c.coupling===1?1:Object.keys(D.types[c.type].ports).length/2).fill(.1):[]);
 const pairs=[],scale=floors.slice(),low=floors.map(()=>Infinity),high=floors.map(()=>-Infinity);
 for(let cycle=0;cycle<4;cycle++)for(const phase of phases){const t=end-(4-cycle-phase)*T,a=read(model.at(t-T)),b=read(model.at(t));pairs.push([a,b]);for(let j=0;j<a.length;j++){scale[j]=Math.max(scale[j],Math.abs(a[j]),Math.abs(b[j]));if(cycle===3){low[j]=Math.min(low[j],b[j]);high[j]=Math.max(high[j],b[j]);}}}
 const memoryIndices=[];let offset=0;for(const c of doc.components){if(c.type==='memristor')memoryIndices.push(offset);offset+=c.type==='capacitor'||c.type==='inductor'||c.type==='memristor'?1:c.type.startsWith('coupled')?(c.coupling===1?1:Object.keys(D.types[c.type].ports).length/2):0;}
 let memoryError=0;for(const [a,b]of pairs)for(const j of memoryIndices)memoryError=Math.max(memoryError,Math.abs(a[j]-b[j]));
 let error=0,rippleError=0;for(const [a,b]of pairs)for(let j=0;j<a.length;j++){const change=Math.abs(a[j]-b[j]);error=Math.max(error,change/scale[j]);rippleError=Math.max(rippleError,change/Math.max(floors[j]*.01,high[j]-low[j]));}
 return {converged:Number.isFinite(error)&&error<.002&&rippleError<.005&&memoryError<1e-7,error,rippleError,memoryError,memoryTolerance:1e-7,period:T,kind:ex.kind,verifiedCycles:4,phaseChecks:phases.size,tolerance:.002,rippleTolerance:.005};
}
function interpolate(samples,t,model,doc){
 let lo=0,hi=samples.length-1;while(lo<hi){const mid=Math.ceil((lo+hi)/2);if(samples[mid].t<=t)lo=mid;else hi=mid-1;}
 const a=samples[lo],b=samples[Math.min(lo+1,samples.length-1)],u=b.t>a.t?(t-a.t)/(b.t-a.t):0,state={},magnetics={};
 for(const field of ['pressure','currents','volumes','portI','portQ']){state[field]={};for(const key of Object.keys(a.state[field]))state[field][key]=a.state[field][key]+u*(b.state[field][key]-a.state[field][key]);}
 for(const id of Object.keys(a.magnetics||{})){magnetics[id]={};for(const key of Object.keys(a.magnetics[id])){const x=a.magnetics[id][key],y=b.magnetics[id][key];magnetics[id][key]=Array.isArray(x)?x.map((v,j)=>v+u*(y[j]-v)):x+u*(y-x);}}
 const memristors={};for(const id of Object.keys(a.memristors||{})){memristors[id]={};for(const key of Object.keys(a.memristors[id]))memristors[id][key]=a.memristors[id][key]+u*(b.memristors[id][key]-a.memristors[id][key]);}if(doc){const MR=node?require('./editor-memristor-model.js'):g.EditorMemristorModel;Object.assign(memristors,MR.interpolate(a.memristors,b.memristors,u,state,model.net,doc.components.filter(c=>c.type==='memristor')));}return {...a,t,state,magnetics,memristors};
}
function crop(model,start,duration,doc=model.effectiveDocument){
 const requestedEnd=start+duration,sourceEnd=Math.abs(requestedEnd-model.duration)<duration*1e-12?model.duration:requestedEnd;
 const shift=(s,time)=>{const t=Math.max(0,Math.min(duration,time));return {...s,t,sourceTime:s.t};};
 const samples=[shift(model.at(start),0),...model.samples.filter(s=>s.t>start&&s.t<=sourceEnd).map(s=>shift(s,s.t-start))];
 if(samples.at(-1).t<duration)samples.push(shift(model.at(sourceEnd),duration));
 // No returned function captures the full run's at()/samples or solver context.
 const interpolationModel={net:model.net},source=model.source,supplyAt=source?(t=>source.waveform==='sine'?(source.offset||0)+source.value*Math.sin(2*Math.PI*(source.frequency||50)*(start+t)):source.value):undefined;
 return {...model,duration,samples,supplyAt,windowStart:start,windowEnd:sourceEnd,at:t=>{t=Math.max(0,Math.min(duration,t));return {...interpolate(samples,t,interpolationModel,doc),sourceTime:t===duration?sourceEnd:start+t};}};
}
function solve(doc,{dt,run,maxSteps=350000,maxCycles=512}){
 const ex=excitation(doc),T=ex.period,perCycle=Math.max(200,Math.ceil(T/dt)),limit=Math.min(maxCycles,Math.floor(maxSteps/perCycle));
 let cycles=Math.max(8,Math.ceil((doc.settings.duration||.04)/T)),totalSteps=0,attempts=0,last;
 if(cycles>limit)throw Error('Steady-state resolution exceeds the settling budget. Reduce minimum steps or enable Transients.');
 while(cycles<=limit){
  const d=D.clone(doc);d.settings.duration=cycles*T;const steps=cycles*perCycle,model=run(d,steps);totalSteps+=steps;attempts++;
  last=check(model,d,ex);
  if(last.converged){const out=crop(model,(cycles-4)*T,4*T,d);out.settling={...last,solvedDuration:model.duration,solvedCycles:cycles,attempts,totalSteps,maxSteps,maxCycles};out.effectiveDocument=d;return out;}
  if(cycles===limit)break;cycles=Math.min(limit,cycles*2);
 }
 throw Error('Did not settle: cycle state change '+(last.error*100).toFixed(3)+'% (ripple-relative '+(last.rippleError*100).toFixed(2)+'%). Memory residual '+last.memoryError.toExponential(2)+' (limit 1e−7). Limits are 0.2% of state scale and 0.5% of ripple scale, within '+limit+' cycles / '+maxSteps+' steps. Enable Transients to inspect startup.');
}
const api={excitation,check,crop,solve};if(node)module.exports=api;else g.EditorSettling=api;
})(globalThis);
