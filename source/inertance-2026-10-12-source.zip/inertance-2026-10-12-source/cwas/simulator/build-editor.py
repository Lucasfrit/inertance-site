# SPDX-License-Identifier: AGPL-3.0-or-later
from pathlib import Path
import json
b=Path(__file__).parent
modules=json.loads((b/'editor-modules.json').read_text())['modules']
assert modules[-1]=='editor-ui.js','editor-ui.js must be the last module'
content=(b/'editor-shell.html').read_text()+'\n<script>\n'+'\n'.join((b/f).read_text() for f in modules)+'\n</script>\n'
(b/'circuit-editor.fragment.html').write_text(content)
