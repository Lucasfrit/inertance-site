# SPDX-License-Identifier: AGPL-3.0-or-later
from pathlib import Path
b=Path(__file__).parent
old=(b/'boost-preview.fragment.html').read_text()
plots=old[old.index('function makeCharts()'):old.index('function render()')].replace('bs-','cl-')
plots=plots.replace('model.values(s.s,!s.on)','model.values(s.s,{on:model.samples[i-1].on,pol:model.samples[i-1].pol})')
plots=plots.replace('h=155','h=170').replace("svg.append('g').attr('transform',`translate(0,${h-m.b})`)","svg.append('g').attr('transform',`translate(0,${h-m.b})`)")
# Refactor the old fixed signal list into a model-specific selection.
plots=plots.replace("charts=[];$('#cl-plots')", "const specs=[['vq','Q₁ voltage','V'],['iq','Q₁ current','A'],['vd','D₁ voltage','V'],['id','D₁ current','A'],['vl',model.p.type==='flyback'?'Lₘ voltage':'L voltage','V'],['i',model.p.type==='flyback'?'Magnetizing current':'L current','A'],['vi','Cᵢ voltage','V'],['ici','Cᵢ current','A'],['vo','Cₒ voltage','V'],['ico','Cₒ current','A']];if(model.bridge||model.p.type==='flyback')specs.push(['vp','Primary voltage','V'],['ip','Primary current','A']);if(model.bridge)specs.push(['d1','Secondary S₁ current','A'],['d2','Secondary S₂ current','A']);if(model.p.type==='half')specs.push(['vc1','C₁ voltage','V'],['ic1','C₁ current','A'],['vc2','C₂ voltage','V'],['ic2','C₂ current','A']);charts=[];$('#cl-plots')")
plots=plots.replace("charts.push({key,title,unit:u,convert,heading,x,clip,cursor,mean,zoom});", "addStatistics(svg,y,w,h,m,key,u,convert);const expressionGuide=document.createElement('div');expressionGuide.className='calculation text-small';expressionGuide.style.whiteSpace='pre-line';const calc=document.createElement('details');calc.className='calculation text-small';const summary=document.createElement('summary');summary.textContent='Values & calculations · now, min, mean, max';calc.append(summary,expressionGuide);const formulaNode=document.createElement('div');formulaNode.style.whiteSpace='pre-line';calc.append(formulaNode);calc.hidden=!$('#cl-calcs').checked;box.append(calc);charts.push({key,title,unit:u,convert,heading,x,clip,cursor,mean,zoom,formulaNode,calc,guide:expressionGuide});")

plots=plots.replace("key==='vi'||key==='vo'", "key==='vi'||key==='vo'||key==='vc1'||key==='vc2'")
(b/'lab-plots.js').write_text(plots)
content=(b/'lab-shell.html').read_text()+'\n<script>\n'+ '\n'.join((b/name).read_text() for name in ['lab-model.js','lab-ui-prefix.js','lab-diagrams.js','lab-plots.js','lab-ui-suffix.js'])+'\n</script>\n'
(b/'circuit-lab.fragment.html').write_text(content)
