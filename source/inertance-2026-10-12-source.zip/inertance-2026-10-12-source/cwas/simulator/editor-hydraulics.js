/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Review instruments. 100 Pa/V, 100 mL/s/A, water density 1000 kg/m³.
   Meters are electrically ideal. A resistive load uses a variable nozzle:
   a fixed nozzle would have a square-root pressure/flow law, not Ohm's law. */
(function(g){
const D=typeof module!=='undefined'?require('./editor-document.js'):g.CircuitDocument;
const rho=1000,gravity=9.81,paPerVolt=100,flowPerAmp=1e-4,pipeArea=Math.PI*.01**2;
function measures(voltage,current){
 const pressure=paPerVolt*voltage,flow=flowPerAmp*current,velocity=flow/pipeArea,head=pressure/(rho*gravity),pitotHead=velocity**2/(2*gravity),jetSpeed=Math.sqrt(2*Math.abs(pressure)/rho);
 return {pressure,flow,velocity,head,pitotHead,jetSpeed,nozzleDiameter:jetSpeed?2*Math.sqrt(Math.abs(flow)/(Math.PI*jetSpeed)):0};
}
function particles({g,el,updates,doc},d,id,widthAt=()=>12){
 const path=el('path',{d,fill:'none',stroke:'none','pointer-events':'none'},g),len=path.getTotalLength(),steps=160,table=[{distance:0,volume:0}];let volume=0;
 for(let k=1;k<=steps;k++){const p=path.getPointAtLength(len*(k-.5)/steps),w=widthAt(p.x,p.y);volume+=len/steps*(w/12)**2;table.push({distance:len*k/steps,volume});}
 const dots=Array.from({length:Math.max(3,Math.ceil(volume/17))},()=>el('circle',{r:1.7,fill:'white','pointer-events':'none','data-flow-particle':id},g));
 updates.push((v,s)=>{const travel=(s.volumes[id]||0)*640000/12*doc.settings.travel;dots.forEach((dot,k)=>{
  const q=((k*volume/dots.length+travel)%volume+volume)%volume;let j=1;while(j<table.length-1&&table[j].volume<q)j++;
  const a=table[j-1],b=table[j],point=path.getPointAtLength(a.distance+(b.distance-a.distance)*(q-a.volume)/(b.volume-a.volume));
  dot.setAttribute('cx',point.x);dot.setAttribute('cy',point.y);dot.setAttribute('r',Math.min(1.7,widthAt(point.x,point.y)*.3));
 });});
 return dots;
}
function draw(c,ctx){
 if(!['load','flowmeter','pressuremeter','input','output'].includes(c.type))return false;
 const {el,text,pressure,updates,color,doc,model}=ctx;
 // Height instruments stay vertical under gravity when their terminals rotate.
 const g=el('g',{transform:`rotate(${-c.rotation})`,'data-hydraulic-component':c.type},ctx.g);
 const line=(d,width=12)=>{el('path',{d,fill:'none',stroke:'black','stroke-width':width+3,'stroke-linejoin':'round'},g);return el('path',{d,fill:'none',stroke:'#73baf0','stroke-width':width,'stroke-linejoin':'round'},g);};
 const port=name=>D.port({...c,x:0,y:0},name);
 const lead=(name,x,y,width=12)=>{const p=port(name),q={x:p.x-p.nx*14,y:p.y-p.ny*14},d=`M${p.x} ${p.y} L${q.x} ${q.y} L${p.nx?x:q.x} ${p.nx?q.y:y} L${x} ${y}`,water=line(d,width);updates.push((v,s)=>water.setAttribute('stroke',color(pressure(s,name))));return d;};
 const label=text(g,0,0,'',{'font-size':10,'text-anchor':'middle','data-hydraulic-readout':''});
 if(c.type==='input'||c.type==='output'){
  const a=port('a'),b=port('b'),d=`M${a.x} ${a.y} L${b.x} ${b.y}`,water=line(d);particles({g,el,updates,doc},d,c.id);
  text(g,0,-15,c.type==='input'?'IN':'OUT',{'font-size':10,'text-anchor':'middle'});label.setAttribute('y',26);
  updates.push((v,s)=>{water.setAttribute('stroke',color(pressure(s,'a')));label.textContent=(s.currents[c.id]||0).toFixed(2)+' A';});
 }else if(c.type==='flowmeter'){
  const left=lead('a',-32,35),right=lead('b',32,35),d='M-32 35 H32',water=line(d);particles({g,el,updates,doc},left,c.id);particles({g,el,updates,doc},d,c.id);particles({g,el,updates,doc},right,c.id);
  // Upstream-facing stagnation tap and transverse static tap.
  el('path',{d:'M-12 35 H0 V22',fill:'none',stroke:'black','stroke-width':1.2,'data-pitot-taps':''},g);
  const cols=[0].map(x=>{el('rect',{x:x-3,y:-66,width:6,height:88,fill:'white',stroke:'black','stroke-width':1},g);return el('rect',{x:x-2,y:0,width:4,height:22,fill:'#1683c5','data-current-column':''},g);});

  const maxI=model?Math.max(.1,...model.samples.map(v=>Math.abs(v.state?.currents[c.id]||0))):1;
  const scale=Math.min(2000,68/Math.max(.001,measures(0,maxI).pitotHead));
  label.setAttribute('x',12);label.setAttribute('text-anchor','start');label.setAttribute('data-current-label','');

  updates.push((v,s)=>{const i=s.currents[c.id]||0,m=measures(0,i),h=m.pitotHead*scale,levels=[22-h];
   water.setAttribute('stroke',color(pressure(s,'a')));
   cols.forEach((n,k)=>{n.setAttribute('y',levels[k]);n.setAttribute('height',22-levels[k]);});

   // Select an opposed upstream-facing tap in reverse flow; height is unsigned.
   ctx.g.setAttribute('data-flow-direction',i<0?'reverse':'forward');
   g.querySelector('[data-pitot-taps]').setAttribute('d',i<0?'M12 35 H0 V22':'M-12 35 H0 V22');
   label.textContent=i.toFixed(3)+' A';label.setAttribute('y',levels[0]+3);

   ctx.g.setAttribute('data-head-m',m.pitotHead);
  });
 }else if(c.type==='pressuremeter'){
  lead('a',-20,40,2);lead('b',20,40,2);
  const columns=[-20,20].map(x=>{el('rect',{x:x-4,y:-62,width:8,height:102,fill:'white',stroke:'black','stroke-width':1.2},g);return el('rect',{x:x-3,y:0,width:6,height:40},g);});
  const maxV=model?Math.max(1,...model.samples.map(v=>{const s=v.state;return s?Math.abs((s.pressure[model.net[c.id+'.a']]||0)-(s.pressure[model.net[c.id+'.b']]||0)):0;})):12,scale=Math.min(600,86/Math.abs(measures(maxV,0).head));
  const senseDots=[-20,20].map(x=>Array.from({length:4},()=>el('circle',{cx:x,r:1.2,fill:'white','data-sensing-particle':'','pointer-events':'none'},g)));
  label.setAttribute('x',28);label.setAttribute('text-anchor','start');
  const bracket=el('path',{'data-head-bracket':'',fill:'none',stroke:'black','stroke-width':1.2},g);text(g,0,56,'0 V',{'text-anchor':'middle','font-size':10});

  updates.push((v,s)=>{const dv=pressure(s,'a')-pressure(s,'b'),m=measures(dv,0),levels=[40-Math.max(0,m.head)*scale,40-Math.max(0,-m.head)*scale];columns.forEach((n,k)=>{n.setAttribute('y',levels[k]);n.setAttribute('height',40-levels[k]);n.setAttribute('fill',color(pressure(s,k?'b':'a')));});
   senseDots.forEach((dots,k)=>dots.forEach((dot,j)=>dot.setAttribute('cy',levels[k]+(40-levels[k])*(j+1)/5)));

   bracket.setAttribute('d',`M-7 ${levels[0]} H7 M0 ${levels[0]} V${levels[1]} M-7 ${levels[1]} H7`);label.setAttribute('y',(levels[0]+levels[1])/2+3);label.textContent=dv.toFixed(2)+' V';ctx.g.setAttribute('data-head-m',m.head);
  });
 }else{
  const left=lead('a',-35,40),right=lead('b',35,40);
  particles({g,el,updates,doc},left,c.id);particles({g,el,updates,doc},right,c.id);
  const hose=line('M-35 40 H-20',8),stream=el('path',{fill:'none',stroke:'#1683c5','stroke-linecap':'round','data-load-stream':''},g);
  const tray=el('path',{d:'M8 22 V43 Q8 51 18 51 H35 V40',fill:'none',stroke:'black','stroke-width':1.5},g);
  const collector=line('M18 46 H35 V40',8),bracket=el('path',{fill:'none',stroke:'black','stroke-width':1,'stroke-dasharray':'2 3'},g);
  const hoseDots=Array.from({length:7},()=>el('circle',{r:1.4,fill:'white','pointer-events':'none','data-flow-particle':c.id},g));
  const dots=Array.from({length:10},()=>el('circle',{r:1.4,fill:'white','pointer-events':'none','data-flow-particle':c.id},g));
  const maxV=model?Math.max(1,...model.samples.map(v=>{const s=v.state;return s?Math.abs((s.pressure[model.net[c.id+'.a']]||0)-(s.pressure[model.net[c.id+'.b']]||0)):0;})):12,scale=Math.min(600,115/Math.abs(measures(maxV,0).head));
  label.setAttribute('y',82);const heightLabel=text(g,0,100,'',{'font-size':10,'text-anchor':'middle'});
  updates.push((v,s)=>{const dv=pressure(s,'a')-pressure(s,'b'),i=s.currents[c.id]||0,m=measures(dv,i),h=Math.abs(m.head)*scale,top=30-h,fall=c.loadView==='fall',reverse=i<0;
   // A variable-area nozzle preserves the resistor I=V/R model.
   const cy=30-h-Math.sqrt(h*(h+12)),tangent=Math.hypot(19,30-cy),nx=-20-6*19/tangent,ny=30+6*(30-cy)/tangent;
   const hosePath=fall?`M-35 40 H-28 V${top} H-16`:`M-35 40 H-30 Q${nx} 40 ${nx} ${ny} L-20 30`;
   hose.setAttribute('d',hosePath);hose.previousSibling.setAttribute('d',hosePath);
   hose.setAttribute('stroke',color(pressure(s,reverse?'b':'a')));collector.setAttribute('stroke',color(pressure(s,reverse?'a':'b')));
   for(const n of [hose,hose.previousSibling,stream,tray,collector,collector.previousSibling,...dots,...hoseDots])n.setAttribute('transform',reverse?'scale(-1 1)':'');
   const d=fall?`M-16 ${top} Q16 ${top} 18 42`:`M-20 30 Q-1 ${cy} 18 42`;
   stream.setAttribute('d',d);stream.setAttribute('stroke-width',Math.max(.2,m.nozzleDiameter*scale*1.6));stream.setAttribute('data-nozzle-diameter-m',m.nozzleDiameter);stream.setAttribute('visibility',Math.abs(i)>1e-9?'visible':'hidden');
   const length=stream.getTotalLength(),travel=Math.abs(s.volumes[c.id]||0)*640000/12*doc.settings.travel;
   const hoseLength=hose.getTotalLength();hoseDots.forEach((dot,k)=>{const point=hose.getPointAtLength(((k*hoseLength/hoseDots.length+travel)%hoseLength+hoseLength)%hoseLength);dot.setAttribute('cx',point.x);dot.setAttribute('cy',point.y);});
   dots.forEach((dot,k)=>{const point=stream.getPointAtLength(((k*length/dots.length+travel)%length+length)%length);dot.setAttribute('cx',point.x);dot.setAttribute('cy',point.y);dot.setAttribute('r',Math.min(1.4,m.nozzleDiameter*scale*.28));dot.setAttribute('visibility',Math.abs(i)>1e-9?'visible':'hidden');});
   bracket.setAttribute('d',`M40 30 H53 M48 30 V${top} M40 ${top} H53`);
   label.textContent=dv.toFixed(2)+' V · '+i.toFixed(3)+' A';
   heightLabel.textContent=(reverse?'Reverse · ':'')+(Math.abs(m.head)*1000).toFixed(1)+' mm · '+Math.abs(m.flow*1e6).toFixed(1)+' mL/s';
   ctx.g.setAttribute('data-head-m',m.head);ctx.g.setAttribute('data-flow-m3s',m.flow);
  });
 }
 // Readouts above water/particles.
 g.append(label);
 return true;
}
function review(){
 const components=[
 {id:'V1',type:'source',value:6,offset:6,waveform:'sine',frequency:1,x:100,y:280,rotation:0},
 {id:'In1',type:'input',value:1,x:240,y:110,rotation:0},
 {id:'FM1',type:'flowmeter',value:1,x:420,y:75,rotation:0},
 {id:'Load1',type:'load',value:10,x:800,y:180,rotation:0,loadView:'jet'},
 {id:'Out1',type:'output',value:1,x:420,y:500,rotation:180},
 {id:'PM1',type:'pressuremeter',value:1,x:650,y:360,rotation:0},
 {id:'J1',type:'junction',value:0,x:540,y:110,rotation:0},
 {id:'J0',type:'junction',value:0,x:950,y:500,rotation:0}
 ];
 const pairs=[['V1.p','In1.a'],['In1.b','FM1.a'],['FM1.b','J1.j'],['J1.j','Load1.a'],['Load1.b','J0.j'],['J0.j','Out1.a'],['Out1.b','V1.n'],['J1.j','PM1.a'],['PM1.b','J0.j']],end=s=>{const[component,port]=s.split('.');return {component,port};};
 return {schemaVersion:1,components,wires:pairs.map(([a,b],j)=>({id:'W'+(j+1),from:end(a),to:end(b)})),settings:{duration:2,loadOn:.01,tail:.015,travel:1.8,colorReference:'supply'}};
}
const api={measures,particles,draw,review};if(typeof module!=='undefined')module.exports=api;else g.EditorHydraulics=api;
})(globalThis);
