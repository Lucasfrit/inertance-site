/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Editable netlists. Values are SI-display units: mH, uF, ohm, V. */
(function(g){const D=typeof module!=='undefined'?require('./editor-document.js'):g.CircuitDocument;
const E=typeof module!=='undefined'?require('./editor-example-layouts.js'):g.EditorExampleLayouts;
const names={memristor:'AC hysteresis · memory vs resistor',memristorHold:'Program & hold · retained state',memristorStates:'Starting states · same supply',buck:'Buck',boost:'Boost',inverting:'Buck–boost · inverting',noninverting:'Buck–boost · two switches',flyback:'Flyback',forward:'Forward · reset winding',half:'Half bridge · isolated',fullbuck:'Full bridge · buck type',fullboost:'Full bridge · boost type',transformer:'AC coupled-winding study'};
function memoryComparison(){
 const components=[{id:'V1',type:'source',value:2.5,waveform:'sine',frequency:.5,offset:0,x:100,y:240,rotation:0},{id:'M1',type:'memristor',value:5000,Ron:100,QD:.001,x0:.2,window:'hard',p:4,x:340,y:160,rotation:0},{id:'Rref',label:'Rref · initial M',type:'resistor',value:4020,x:340,y:320,rotation:0},{id:'Jp',type:'junction',value:0,x:200,y:160,rotation:0},{id:'Jg',type:'junction',value:0,x:500,y:320,rotation:0}];
 const end=s=>{const [component,port]=s.split('.');return {component,port};},pairs=[['V1.p','Jp.j'],['Jp.j','M1.a'],['M1.b','Jg.j'],['Jp.j','Rref.a'],['Rref.b','Jg.j'],['V1.n','Jg.j']];
 return E.apply(D.validate({schemaVersion:1,components,wires:pairs.map(([a,b],j)=>({id:'W'+(j+1),from:end(a),to:end(b)})),settings:{loadOn:.01,tail:.015,duration:6,travel:1.8,colorReference:'return',model:{mode:'ripple',view:'startup',steps:5000}}}),'memristor');
}
// These are ordinary editable documents, solved by the same implicit network model.
function memoryStudy(type){
 const hold=type==='memristorHold',components=[
  {id:'V1',type:'source',value:hold?2:.4,...(hold?{}:{waveform:'sine',frequency:1,offset:0}),x:100,y:300,rotation:0},
  {id:'M1',type:'memristor',value:5000,Ron:100,QD:.001,x0:.2,window:'hard',p:4,x:420,y:200,rotation:0}
 ];
 let pairs;
 if(hold){components.push({id:'Q1',type:'switch',value:600,ron:.02,x:250,y:120,rotation:270});pairs=[['V1.p','Q1.a'],['Q1.b','M1.a'],['M1.b','V1.n']];}
 else{components.push({id:'M2',type:'memristor',value:5000,Ron:100,QD:.001,x0:.8,window:'hard',p:4,x:420,y:490,rotation:0},{id:'Jp',type:'junction',value:0,x:220,y:200,rotation:0},{id:'Jg',type:'junction',value:0,x:680,y:490,rotation:0});pairs=[['V1.p','Jp.j'],['Jp.j','M1.a'],['M1.b','Jg.j'],['Jp.j','M2.a'],['M2.b','Jg.j'],['V1.n','Jg.j']];}
 const end=s=>{const [component,port]=s.split('.');return {component,port};};
 return E.apply(D.validate({schemaVersion:1,components,wires:pairs.map(([a,b],j)=>({id:'W'+(j+1),from:end(a),to:end(b)})),settings:{loadOn:.2,tail:.015,duration:hold?3:3,travel:1.8,colorReference:'return',model:{mode:'ripple',view:'startup',steps:5000}}}),type);
}
function create(type){if(type==='memristor')return memoryComparison();if(['memristorHold','memristorStates'].includes(type))return memoryStudy(type);if(!names[type])throw Error('Unknown preset');const components=[],connections={},anchors={g:[140,560],vin:[230,100],out:[950,160],sg:[850,560]},f=1000,cycles=10;
function part(id,kind,value,x,y,terminals,extra={}){const rotation=extra.rotation??0,c={id,type:kind,value,x,y,rotation,...extra};components.push(c);Object.entries(terminals).forEach(([port,node])=>(connections[node]??=[]).push({component:id,port}));return c;}
const r=(id,a,b,x,y,value=12,rotation=90)=>part(id,'resistor',value,x,y,{a,b},{rotation}),cap=(id,a,b,x,y,value=100)=>part(id,'capacitor',value,x,y,{p:a,n:b}),l=(id,a,b,x,y,value=4.7)=>part(id,'inductor',value,x,y,{a,b}),diode=(id,a,b,x,y,rotation=0)=>part(id,'diode',.3,x,y,{a,b},{rotation});
const q=(id,a,b,x,y,duty=.5,phase=0,rotation=0)=>part(id,'switch',1,x,y,{a,b},{rotation,ron:.02,pwm:{frequency:f,duty,phase}});
part('V1','source',12,80,320,{p:'raw',n:'g'},type==='transformer'?{waveform:'sine',frequency:f}:{});r('Rin','raw','vin',180,100,.1,0);cap('Ci','vin','g',250,320,type==='transformer'?100:150);
let ret='g';
if(type==='buck'){q('Q1','vin','sw',370,100,.5,0,270);diode('D1','g','sw',480,340,180);l('L1','sw','out',670,180,4.7);anchors.sw=[480,100];}
if(type==='boost'){l('L1','vin','sw',400,180);q('Q1','sw','g',550,340);diode('D1','sw','out',750,100,270);anchors.sw=[550,100];}
if(type==='inverting'){q('Q1','vin','sw',380,100,.5,0,270);l('L1','sw','g',600,330,4.7);diode('D1','out','sw',780,100,90);anchors.sw=[500,100];}
if(type==='noninverting'){q('Q1','vin','left',370,100,.5,0,270);diode('D1','g','left',470,350,180);l('L1','left','right',620,180);q('Q2','right','g',760,350);diode('D2','right','out',870,100,270);anchors.left=[470,100];anchors.right=[760,100];}
if(['flyback','forward','transformer','half','fullbuck','fullboost'].includes(type)){ret='sg';const map=type==='forward'?{p1:'vin',n1:'drain',p2:'g',n2:'reset',p3:'sa',n3:'sg'}:type==='flyback'?{p1:'vin',n1:'drain',p2:'sg',n2:'sa'}:['half','fullbuck','fullboost'].includes(type)?{p1:'pa',n1:'pb',p2:'sa',n2:'sg',p3:'sg',n3:'sb'}:{p1:'pa',n1:'pb',p2:'sa',n2:'sb'};
part('T1',['forward','half','fullbuck','fullboost'].includes(type)?'coupled3':'coupled',type==='flyback'?2:20,630,300,map,{turns:['forward','half','fullbuck','fullboost'].includes(type)?[1,1,1]:[1,1],coupling:1,...(type==='flyback'?{windingFlips:[true,true]}:{})});
if(type==='flyback'||type==='forward'){q('Q1','drain','g',420,400,.4);diode('Dout','sa',type==='flyback'?'out':'rect',830,100,270);if(type==='forward'){diode('Dreset','reset','vin',350,240,180);diode('Dfree','sg','rect',860,400,180);l('Lout','rect','out',1020,200,4.7);anchors.out=[1200,160];anchors.rect=[900,100];}}
if(type==='transformer'){anchors.pa=[230,100];anchors.pb=[140,560];// Primary fed through the source resistance; secondary drives a resistive load.
connections.pa=connections.pa.concat(connections.vin);delete connections.vin;connections.pb=connections.pb.concat(connections.g);delete connections.g;connections.sg=connections.sb;delete connections.sb;connections.out=connections.sa;delete connections.sa;}
if(type==='half'){cap('Ctop','vin','mid',340,210,220);cap('Cbottom','mid','g',340,420,220);q('Q1','vin','pa',470,180,.2,0);q('Q2','pa','g',470,420,.2,.5);diode('Db1','pa','vin',530,180,180);diode('Db2','g','pa',530,420,180);connections.pb=connections.pb.concat(connections.mid);delete connections.mid;anchors.pa=[470,300];}
if(type==='fullbuck'||type==='fullboost'){const bus=type==='fullboost'?'bus':'vin',duty=type==='fullboost'?.6:.2;if(type==='fullboost')l('Lin','vin','bus',350,160,1);q('Q1',bus,'pa',400,200,duty,0);q('Q2','pa','g',400,450,duty,.5);q('Q3',bus,'pb',780,200,duty,.5);q('Q4','pb','g',780,450,duty,0);diode('Db1','pa',bus,450,200,180);diode('Db2','g','pa',450,450,180);diode('Db3','pb',bus,830,200,180);diode('Db4','g','pb',830,450,180);anchors.pa=[450,300];anchors.pb=[780,320];}
if(['half','fullbuck','fullboost'].includes(type)){const rect=type==='fullboost'?'out':'rect';diode('Dr1','sa',rect,1000,160,270);diode('Dr2','sb',rect,1000,300,270);anchors.sa=[900,200];anchors.sb=[900,340];anchors.sg=[1050,620];if(type!=='fullboost')l('Lout','rect','out',1200,150,1);anchors.out=[1380,200];}}
if(['half','fullbuck','fullboost'].includes(type)){const positions={T1:[850,300],Q1:[type==='half'?520:350,200],Q2:[type==='half'?520:350,450],Q3:[520,200],Q4:[520,450],Db1:[type==='half'?580:410,200],Db2:[type==='half'?580:410,450],Db3:[580,200],Db4:[580,450],Dr1:[1130,120],Dr2:[1130,440],Lout:[1340,210],Lin:[340,20]};for(const c of components)if(positions[c.id])[c.x,c.y]=positions[c.id];anchors.pa=[type==='half'?520:350,310];anchors.pb=[520,350];anchors.sa=[1070,120];anchors.sb=[1070,440];anchors.sg=[1070,650];anchors.rect=[1240,120];anchors.out=[1530,180];}
const ox=anchors.out[0];if(type!=='transformer')cap('Co',type==='inverting'?ret:'out',type==='inverting'?'out':ret,ox,350,type==='boost'?68:['half','fullbuck'].includes(type)?220:100);r('Rload','out',ret,ox+170,350,12);const wires=[];let jid=1;for(const[node,ends]of Object.entries(connections)){if(ends.length<2)throw Error('Unconnected preset node '+node);if(ends.length===2)wires.push({id:'W'+(wires.length+1),from:ends[0],to:ends[1]});else{let point=anchors[node];if(!point){const ports=ends.map(e=>D.port(components.find(c=>c.id===e.component),e.port));point=[Math.round(ports.reduce((sum,p)=>sum+p.x,0)/ports.length/10)*10,Math.round(ports.reduce((sum,p)=>sum+p.y,0)/ports.length/10)*10];}const c={id:'J'+jid++,type:'junction',value:0,x:point[0],y:point[1],rotation:0};components.push(c);for(const end of ends)wires.push({id:'W'+(wires.length+1),from:end,to:{component:c.id,port:'j'}});}}
// Modest ripple at a visible 1 kHz switching rate, rather than large DCM
// spikes in every example. The half bridge has the lowest load current.
for(const c of components){
 if(c.type==='inductor'&&c.value===1)c.value=c.id==='Lout'&&type==='half'?10:4.7;
 if(c.id==='T1'&&type==='flyback')c.value=4.7;
 c.x=Math.round(c.x*1.4/10)*10;c.y=Math.round(c.y*1.3/10)*10;
}
return E.apply(D.validate(D.combineSwitchDiodes({schemaVersion:1,components,wires,settings:{loadOn:1/f,tail:cycles/f,duration:cycles/f,travel:1.8,colorReference:'supply'},preset:type})),type);}
const api={names,create};if(typeof module!=='undefined')module.exports=api;else g.EditorPresets=api;
})(globalThis);
