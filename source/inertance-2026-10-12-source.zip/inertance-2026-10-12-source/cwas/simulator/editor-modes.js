/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Selected-model contract. Reduced models are periodic references, never startup.
   Derived devices/parameters never mutate the editable document. */
(function(g){
const node=typeof module!=='undefined',D=node?require('./editor-document.js'):g.CircuitDocument,P=node?require('./editor-presets.js'):g.EditorPresets,M=node?require('./editor-rc-model.js'):g.EditorRCModel;
const defaults={mode:'ripple',losses:'ideal',view:'settled',coupling:.98,snubberCap:5,snubberResistance:8,steps:5000,overlay:false};
const labels={ideal:'Ideal · teaching model',ripple:'Ripple · steady state',leakage:'Leakage · Experimental'};
function config(doc){const saved=doc.settings.model||{};return {...defaults,...(saved.mode==='leakage'?{view:'startup'}:{}),...saved};}
// Port-preserving electrical graph isomorphism, independent of names, placement,
// wire subdivision and preset metadata. Strict matching prevents edited topologies
// from receiving a familiar formula merely because they retain familiar IDs.
function recognize(doc){
 const active=doc.components.filter(c=>c.type!=='junction'),net=D.nets(doc);
 for(const type of ['buck','boost','inverting','noninverting','flyback','forward','half','fullbuck','fullboost','transformer']){
  const template=P.create(type),parts=template.components.filter(c=>c.type!=='junction'),tn=D.nets(template);
  if(parts.length!==active.length)continue;
  // Search is small (at most four same-type switches); node bijection prunes early.
  const ordered=parts.slice().sort((a,b)=>active.filter(c=>c.type===a.type).length-active.filter(c=>c.type===b.type).length);
  let result;
  function search(j,map,nodes,reverse,used){
   if(j===ordered.length){result=map;return true;}
   const a=ordered[j];
   for(const b of active.filter(c=>c.type===a.type&&!used.has(c.id))){
    let ok=true;const nn={...nodes},rr={...reverse};
    for(const port of Object.keys(D.types[a.type].ports)){const x=tn[a.id+'.'+port],y=net[b.id+'.'+port];if(nn[x]&&nn[x]!==y||rr[y]&&rr[y]!==x){ok=false;break;}nn[x]=y;rr[y]=x;}
    if(ok&&search(j+1,{...map,[a.id]:b},nn,rr,new Set([...used,b.id])))return true;
   }return false;
  }
  if(search(0,{}, {}, {},new Set()))return {type,parts:result,net};
 }return null;
}
function fullBoostParameters(doc,r){
 if(config(doc).losses!=='ideal')throw Error('Full-bridge boost course reference requires ideal devices. Select ideal losses.');
 const W=node?require('./editor-waveform-reference.js'):g.EditorWaveformReference,table=W.create(doc,r);
 if(!table.available)throw Error(table.reason);
 return {...table,duty:table.D,f:1/table.period,regime:'CCM',ratio:table.n/(1-table.D),mean:table.ii,sourceCurrent:table.ii};
}
function reducedParameters(doc,r){
 if(r?.type==='fullboost')return fullBoostParameters(doc,r);
 if(!r||!['buck','boost','inverting','flyback','forward'].includes(r.type))throw Error('Course reference supports recognized buck, boost, inverting buck–boost, flyback and reset-forward only. Use Ripple for this circuit.');
 const c=config(doc),p=r.parts,q=p.Q1;
 if(c.losses!=='ideal')throw Error('Course reference requires the ideal-device loss choice. Use Ripple for configured device losses.');
 if(!q.pwm||(doc.settings.manualEvents||[]).length||p.V1.waveform==='sine'||p.V1.value<=0||q.bodyDiode)throw Error('Course reference requires automatic PWM, a positive DC supply and the recognized conduction paths. Use Ripple.');
 const duty=q.pwm.duty,f=q.pwm.frequency,n=p.T1?(p.T1.turns?.[r.type==='forward'?2:1]??1)/(p.T1.turns?.[0]??1):1;
 if(n<=0)throw Error('Course reference requires the recognized positive winding polarity. Use Ripple for reversed turns.');
 const reset=p.T1?(p.T1.turns?.[1]??1)/(p.T1.turns?.[0]??1):1;
 if(r.type==='forward'&&(reset<=0||duty>1/(1+reset)+1e-12))throw Error('Forward reset invalid: D must be ≤ Np/(Np+Nr) = '+(1/(1+reset)).toFixed(4)+'. Reduce duty; this model has no saturation.');
 const ratio=r.type==='buck'?duty:r.type==='boost'?1/(1-duty):r.type==='inverting'?-duty/(1-duty):r.type==='forward'?n*duty:n*duty/(1-duty),R=p.Rload.value,Rs=p.Rin.value;
 let vin=p.V1.value/(1+Rs*ratio*ratio/R),vo=ratio*vin,io=Math.abs(vo)/R,L=(p.L1||p.Lout||p.T1).value*1e-3,delta=(r.type==='buck'?vin-vo:r.type==='forward'?n*vin-vo:vin)*duty/(L*f);
 let mean=r.type==='buck'||r.type==='forward'?io:r.type==='boost'?io/(1-duty):r.type==='inverting'?io/(1-duty):n*io/(1-duty),min=mean-delta/2,regime='CCM';
 if(r.type==='flyback'&&min<0){regime='DCM';// Energy per pulse: 1/2 L (Vin D / Lf)^2 f = Vo²/R.
  const gain=duty*Math.sqrt(R/(2*L*f));vin=p.V1.value/(1+Rs*gain*gain/R);vo=vin*gain;io=vo/R;delta=vin*duty/(L*f);min=0;mean=delta/2;
 }
 if(r.type!=='flyback'&&min<=0)throw Error('Course reference CCM assumption fails (Imin ≤ 0). Use Ripple for DCM.');
 const offFraction=r.type==='flyback'?L*delta*f/(vo/n):1-duty;
 if(r.type==='flyback'&&regime==='DCM'&&duty+offFraction>1+1e-9)throw Error('Invalid flyback DCM interval. Use Ripple.');
 return {duty,f,n,reset,ratio,vin,vo,io,L,delta,mean,min,regime,offFraction,sourceCurrent:vo*vo/(R*vin)};
}
function availability(doc){const r=recognize(doc),c=config(doc);let ideal='',leakage='';try{reducedParameters(doc,r);}catch(e){ideal=e.message;}
 if(doc.components.some(c=>c.type==='memristor'))leakage='Memristor plus automatic magnetic leakage is not validated. Use Ideal or Ripple / Transients.';else if(!doc.components.some(c=>c.type.startsWith('coupled')))leakage='No coupled windings: a plain converter has no magnetic leakage.';
 else if(!r||!['flyback','forward'].includes(r.type))leakage='Automatic protective paths are validated for recognized flyback and reset-forward only. Use Ripple with an explicit custom protective circuit.';
 else if(r.parts.V1.waveform==='sine'||r.parts.V1.value<=0)leakage='Automatic leakage protection is validated for positive DC excitation only.';
 else if(!r.parts.Q1.pwm||(doc.settings.manualEvents||[]).length)leakage='Leakage protection requires automatic PWM.';
 else if(r.parts.Q1.bodyDiode)leakage='Automatic leakage protection is not validated with an integrated primary switch diode.';
 else if(r.parts.T1.turns?.some(v=>v<=0))leakage='Automatic protection requires positive winding turns.';
 if(r?.type==='forward'){const p=r.parts,duty=p.Q1.pwm?.duty,reset=(p.T1.turns?.[1]??1)/(p.T1.turns?.[0]??1);if(duty>1/(1+reset))leakage='Forward duty exceeds available core reset time; reduce D to ≤ '+(1/(1+reset)).toFixed(4)+'.';}
 return {topology:r?.type||'custom',reduction:{enabled:!ideal,reason:ideal},ideal:{enabled:true,reason:''},ripple:{enabled:true,reason:''},leakage:{enabled:!leakage,reason:leakage}};
}
function interpolate(samples,time){let lo=0,hi=samples.length-1;while(lo<hi){const mid=Math.ceil((lo+hi)/2);if(samples[mid].t<=time)lo=mid;else hi=mid-1;}const a=samples[lo],b=samples[Math.min(lo+1,samples.length-1)],u=b.t>a.t?(time-a.t)/(b.t-a.t):0,out={...a,t:time,state:{},magnetics:{}};
 for(const field of ['pressure','currents','volumes','portI','portQ'])out.state[field]=Object.fromEntries(Object.keys(a.state[field]).map(k=>[k,a.state[field][k]+u*(b.state[field][k]-a.state[field][k])]));
 for(const id of Object.keys(a.magnetics||{})){out.magnetics[id]={};for(const key of Object.keys(a.magnetics[id])){const x=a.magnetics[id][key],y=b.magnetics[id][key];out.magnetics[id][key]=Array.isArray(x)?x.map((v,j)=>v+u*(y[j]-v)):x+u*(y-x);}}
 return out;
}
function reference(doc,r){
 if(r.type==='fullboost')return fullBoostReference(doc,r);
 const p=r.parts,a=reducedParameters(doc,r),net=r.net,ground=net[p.V1.id+'.n'],supply=net[p.V1.id+'.p'],duration=4/a.f,T=1/a.f,phase=p.Q1.pwm.phase||0;
 // Currents in filtering L are cycle averages; flyback/forward magnetization ramps
 // are retained. Capacitor current is an averaged zero, Q=CV is constant. Thus
 // terminal KCL is averaged at capacitors, not claimed exact within the cycle.
 function make(t,side=1){const x=((t/T-phase)%1+1)%1,on=x<a.duty&&(Math.abs(x-a.duty)>1e-12||side>0),z=x*T,pressure={},currents={},volumes={},portI={},portQ={},magnetics={};
  const set=(c,port,v)=>pressure[net[c.id+'.'+port]]=v,flow=(c,i,w)=>currents[c.id+(w?'.w'+w:'')]=i;
  set(p.V1,'p',p.V1.value);set(p.V1,'n',0);set(p.Ci,'p',a.vin);set(p.Ci,'n',0);set(p.Co,'p',Math.abs(a.vo));set(p.Co,'n',0);set(p.Rload,'a',a.vo);set(p.Rload,'b',0);
  flow(p.V1,-a.sourceCurrent);flow(p.Rin,a.sourceCurrent);flow(p.Ci,0);flow(p.Co,0);flow(p.Rload,a.vo/p.Rload.value);
  if(r.type==='buck'){set(p.Q1,'b',on?a.vin:0);flow(p.Q1,on?a.io:0);flow(p.D1,on?0:a.io);flow(p.L1,a.io);}
  if(r.type==='boost'){set(p.Q1,'a',on?0:a.vo);flow(p.Q1,on?a.mean:0);flow(p.D1,on?0:a.mean);flow(p.L1,a.mean);}
  if(r.type==='inverting'){set(p.Co,'p',0);set(p.Co,'n',a.vo);set(p.Q1,'b',on?a.vin:a.vo);flow(p.Q1,on?a.mean:0);flow(p.D1,on?0:a.mean);flow(p.L1,a.mean);}
  if(r.type==='flyback'){
   const delivery=!on&&x<a.duty+a.offFraction,im=on?a.min+a.vin*z/a.L:delivery?Math.max(0,a.min+a.delta-(a.vo/a.n)*(z-a.duty*T)/a.L):0;
   set(p.T1,'p1',a.vin);set(p.T1,'n1',on?0:delivery?a.vin+a.vo/a.n:a.vin);set(p.T1,'p2',0);set(p.T1,'n2',on?-a.n*a.vin:delivery?a.vo:0);
   flow(p.T1,on?im:0,1);flow(p.T1,delivery?-im/a.n:0,2);flow(p.Q1,on?im:0);flow(p.Dout,delivery?im/a.n:0);
   magnetics[p.T1.id]={energy:.5*a.L*im*im,fluxCurrent:im,fluxCharge:0,powers:[on?a.vin*im:0,delivery?-a.vo*im/a.n:0],currents:[on?im:0,delivery?-im/a.n:0]};
  }
  if(r.type==='forward'){
   const reset=!on&&x<a.duty*(1+a.reset),im=on?a.vin*z/(p.T1.value*1e-3):reset?Math.max(0,a.vin*a.duty*T/(p.T1.value*1e-3)-a.vin/a.reset*(z-a.duty*T)/(p.T1.value*1e-3)):0;
   const vp=on?a.vin:reset?-a.vin/a.reset:0;
   set(p.T1,'p1',a.vin);set(p.T1,'n1',a.vin-vp);set(p.T1,'p2',0);set(p.T1,'n2',-a.reset*vp);set(p.T1,'p3',a.n*vp);set(p.T1,'n3',0);set(p.Lout,'a',on?a.n*a.vin:0);
   flow(p.T1,on?im+a.n*a.io:0,1);flow(p.T1,reset?im/a.reset:0,2);flow(p.T1,on?-a.io:0,3);flow(p.Q1,on?im+a.n*a.io:0);flow(p.Dout,on?a.io:0);flow(p.Dreset,reset?im/a.reset:0);flow(p.Dfree,on?0:a.io);flow(p.Lout,a.io);
   magnetics[p.T1.id]={energy:.5*p.T1.value*1e-3*im*im,fluxCurrent:im,fluxCharge:0,powers:[on?a.vin*(im+a.n*a.io):0,reset?-a.vin*im/a.reset:0,on?-a.n*a.vin*a.io:0],currents:[on?im+a.n*a.io:0,reset?im/a.reset:0,on?-a.io:0]};
  }
  for(const c of doc.components.filter(c=>c.type!=='junction')){const count=c.type.startsWith('coupled')?Object.keys(D.types[c.type].ports).length/2:1;for(let j=1;j<=count;j++){const ports=count>1?['p'+j,'n'+j]:Object.keys(D.types[c.type].ports),id=c.id+(count>1?'.w'+j:''),i=currents[id]||0;volumes[id]=c.type==='capacitor'?c.value*1e-6*(pressure[net[c.id+'.'+ports[0]]]-pressure[net[c.id+'.'+ports[1]]]):0;portI[c.id+'.'+ports[0]]=-i;portI[c.id+'.'+ports[1]]=i;portQ[c.id+'.'+ports[0]]=-volumes[id];portQ[c.id+'.'+ports[1]]=volumes[id];}}
  return {t,on,switchStates:{[p.Q1.id]:on},state:{pressure,currents,volumes,portI,portQ},magnetics};
 }
 const times=[0,duration,...Array.from({length:801},(_,j)=>j*duration/800)];for(let k=-1;k<=5;k++)for(const x of [0,a.duty,a.duty+a.offFraction,r.type==='forward'?a.duty*(1+a.reset):1]){const t=(k+phase+x)*T;if(t>0&&t<duration)times.push(t-1e-12,t);}
 const samples=[...new Set(times)].sort((a,b)=>a-b).map(t=>make(t));
 // Integrate actual reconstructed path flow for particles, while cap stored Q
 // stays fixed. This cannot accumulate fictitious capacitor charge.
 const totals={};for(let j=0;j<samples.length;j++){const s=samples[j],old=samples[j-1],h=old?s.t-old.t:0;for(const id of Object.keys(s.state.volumes)){if(doc.components.find(c=>c.id===id)?.type==='capacitor')continue;totals[id]=(totals[id]||0)+h*((old?.state.currents[id]||0)+(s.state.currents[id]||0))/2;s.state.volumes[id]=totals[id];}for(const c of doc.components.filter(c=>c.type!=='junction'))for(const port of Object.keys(D.types[c.type].ports)){const w=c.type.startsWith('coupled')?'.w'+port.slice(1):'',sign=port[0]==='p'||port==='a'?-1:1;s.state.portQ[c.id+'.'+port]=sign*(s.state.volumes[c.id+w]||0);}for(const c of doc.components.filter(c=>c.type.startsWith('coupled'))){s.state.currents[c.id]=s.state.currents[c.id+'.w1'];s.state.volumes[c.id]=s.state.volumes[c.id+'.w1'];s.magnetics[c.id].fluxCharge=Object.keys(D.types[c.type].ports).length/2===2?s.state.volumes[c.id+'.w1']+a.n*s.state.volumes[c.id+'.w2']:s.state.volumes[c.id+'.w1']+a.reset*s.state.volumes[c.id+'.w2']+a.n*s.state.volumes[c.id+'.w3'];}}
 return {kind:'network',net,ground,supply,references:[ground,...(p.T1?[net[p.T1.id+(r.type==='flyback'?'.p2':'.n3')]]:[])],p:{Vs:p.V1.value,loadOn:0},source:p.V1,capacitor:p.Co,duration,dt:duration/800,samples,at:t=>interpolate(samples,Math.max(0,Math.min(duration,t))),referenceParameters:a};
}
// Same report state table as the plots, reconstructed into one authoritative
// periodic scene sample. Filtering L/C ripple and transformer excitation omitted.
function fullBoostReference(doc,r){
 const a=fullBoostParameters(doc,r),p=r.parts,net=r.net,T=a.period,duration=4*T,phase=p.Q1.pwm.phase||0;
 const stateAt=x=>{const u=((x%1)+1)%1;for(let j=0;j<4;j++)if(u<a.bounds[j+1])return j;return 3;};
 const primitive=(levels,x)=>{const cycles=Math.floor(x),u=x-cycles;let sum=0,partial=0;for(let j=0;j<4;j++){sum+=levels[j]*(a.bounds[j+1]-a.bounds[j]);partial+=levels[j]*Math.max(0,Math.min(u,a.bounds[j+1])-a.bounds[j]);}return T*(cycles*sum+partial);};
 function make(time){
  const t=Math.max(0,Math.min(duration,time)),x=t/T-phase,j=stateAt(x),transfer=j===1||j===3,bus=transfer?a.vo/a.n:0,pa=j===1?bus:0,pb=j===3?bus:0;
  const pressure={},currents={},volumes={},portI={},portQ={},magnetics={};
  const set=(c,port,v)=>pressure[net[c.id+'.'+port]]=v;
  set(p.V1,'p',a.vin);set(p.V1,'n',0);set(p.Rin,'b',a.vin);set(p.Lin,'b',bus);
  set(p.Q1,'b',pa);set(p.Q3,'b',pb);set(p.T1,'p2',(pa-pb)*a.n);set(p.T1,'n2',0);set(p.T1,'n3',-(pa-pb)*a.n);set(p.Co,'p',a.vo);set(p.Co,'n',0);
  for(const c of doc.components.filter(c=>c.type!=='junction')){
   const magnetic=c.type.startsWith('coupled'),count=magnetic?Object.keys(D.types[c.type].ports).length/2:1;
   for(let w=0;w<count;w++){
    const id=c.id+(magnetic?'.w'+(w+1):''),ps=magnetic?['p'+(w+1),'n'+(w+1)]:Object.keys(D.types[c.type].ports),signal=a.signal(c.id,magnetic?w:null),i=signal?.current[j]||0,flow=signal?primitive(signal.current,x)-primitive(signal.current,-phase):0;
    currents[id]=i;volumes[id]=c.type==='capacitor'?c.value*1e-6*(pressure[net[c.id+'.'+ps[0]]]-pressure[net[c.id+'.'+ps[1]]]):flow;
    portI[c.id+'.'+ps[0]]=-i;portI[c.id+'.'+ps[1]]=i;portQ[c.id+'.'+ps[0]]=-flow;portQ[c.id+'.'+ps[1]]=flow;
   }
   if(c.type==='switch'&&c.bodyDiode){currents[c.id+'.total']=currents[c.id];volumes[c.id+'.total']=volumes[c.id];currents[c.id+'.diode']=0;volumes[c.id+'.diode']=0;}
  }
  const wi=[1,2,3].map(w=>currents[p.T1.id+'.w'+w]),powers=wi.map((i,w)=>a.signal(p.T1.id,w).voltage[j]*i);
  currents[p.T1.id]=wi[0];volumes[p.T1.id]=volumes[p.T1.id+'.w1'];magnetics[p.T1.id]={energy:0,fluxCurrent:0,fluxCharge:0,powers,currents:wi};
  const overlap=j===0||j===2,switchStates={[p.Q1.id]:overlap||j===1,[p.Q4.id]:overlap||j===1,[p.Q2.id]:overlap||j===3,[p.Q3.id]:overlap||j===3};
  return {t,on:overlap,switchStates,state:{pressure,currents,volumes,portI,portQ},magnetics};
 }
 const times=new Set(Array.from({length:801},(_,j)=>duration*j/800)),events=new Set();
 for(let k=-1;k<=5;k++)for(const b of a.bounds){const t=(k+phase+b)*T;if(t>=0&&t<=duration){times.add(t);events.add(t);}}
 const samples=[];for(const t of [...times].sort((a,b)=>a-b)){if(t>0&&events.has(t))samples.push({...make(t-1e-12),t});samples.push(make(t));}
 return {kind:'network',net,ground:net[p.V1.id+'.n'],supply:net[p.V1.id+'.p'],references:[net[p.V1.id+'.n'],net[p.Co.id+'.n']],p:{Vs:p.V1.value,loadOn:0},source:p.V1,capacitor:p.Co,duration,dt:duration/800,samples,at:make,referenceParameters:a};
}
function derived(doc,c,r){
 const out=D.clone(doc),equivalent=[];
 // Imported Ripple networks retain the explicit K coefficient from their file.
 // The preset teaching modes still select their existing ideal/leakage values.
 for(const p of out.components){if(p.type.startsWith('coupled')&&!(c.mode==='ripple'&&doc.settings.import))p.coupling=c.mode==='leakage'?c.coupling:1;if(c.losses==='ideal'){if(p.type==='switch')p.ron=0;if(p.type==='diode'){p.value=0;p.ron=0;}if(p.bodyDiode)p.bodyDiode={value:0};}}
 if(c.mode==='leakage'){
  // Series R-C snubber across the primary switch: real commutation path in MNA,
  // finite C voltage at both switching edges; named R supplies damping. No Coss
  // claim and no lossless charged-capacitor short at turn-on.
  const q=out.components.find(p=>p.id===r.parts.Q1.id),ids=new Set(out.components.map(p=>p.id));let k=1;while(ids.has('ModeC'+k)||ids.has('ModeR'+k))k++;
  const capacitor={id:'ModeC'+k,type:'capacitor',value:c.snubberCap,x:q.x+160,y:q.y,rotation:0,capMode:'ac'},resistor={id:'ModeR'+k,type:'resistor',value:c.snubberResistance,x:q.x+160,y:q.y+160,rotation:90};out.components.push(capacitor,resistor);
  let w=1;const wire=(a,ap,b,bp)=>{while(out.wires.some(x=>x.id==='ModeW'+w))w++;out.wires.push({id:'ModeW'+w++,from:{component:a,port:ap},to:{component:b,port:bp}});};wire(q.id,'a',resistor.id,'a');wire(resistor.id,'b',capacitor.id,'p');wire(capacitor.id,'n',q.id,'b');
  equivalent.push({name:'Primary switch RC snubber',capacitor:capacitor.id,capacitanceUF:c.snubberCap,resistor:resistor.id,resistanceOhm:c.snubberResistance,connections:q.id+'.a → Rsnub → Csnub → '+q.id+'.b'});
 }
 return {document:out,equivalent};
}
const S=node?require('./editor-settling.js'):g.EditorSettling;
function settling(model,doc){return S.check(model,doc);}
function formula(r,a){if(!r||!a)return 'Numerical extrema and time integral mean. Governing equations: KCL Σi=0; capacitor Q=CV; v=L·di/dt (matrix for windings).';const p=r.parts,F=x=>Number(x.toPrecision(5));if(r.type==='fullboost')return `Report CCM: D=2 dgate−1=${F(a.D)}; n=Ns/Np=${F(a.n)}; Vo=n Vi/(1−D)=${F(a.n)} × ${F(a.vin)}/(1−${F(a.D)})=${F(a.vo)} V; Io=Vo/R=${F(a.io)} A; Ii=Vo Io/Vi=${F(a.ii)} A. Lin current min=mean=max=Ii; vLin=Vi (overlap) or Vi−Vo/n (transfer). Primary v=0, +Vo/n, 0, −Vo/n; i=0, +Ii, 0, −Ii. Co voltage min=mean=max=Vo; iCo=−Io or Ii/n−Io. Source feed idealized; symmetric overlap sharing; finite filter ripple and transformer excitation omitted.`;let text=`${a.regime} reference: Vin (after averaged Rin drop) = ${F(a.vin)} V; Vo = ${F(a.vo)} V; Io = ${F(a.io)} A. `;
 if(['buck','boost','inverting','forward'].includes(r.type))text+=`Vo/Vin = ${r.type==='buck'?'D':r.type==='boost'?'1/(1−D)':r.type==='inverting'?'−D/(1−D)':'(Ns/Np)D'}; D=${a.duty}. ΔiL = ${F(a.delta)} A; Imin/max = ${F(a.mean-a.delta/2)} / ${F(a.mean+a.delta/2)} A. `;
 if(r.type==='buck')text+=`Δvo ≈ ΔiL/(8 fs C) = ${F(a.delta)}/(8 × ${a.f} × ${p.Co.value*1e-6}) = ${F(a.delta/(8*a.f*p.Co.value*1e-6))} V (small ripple, zero ESR). `;
 if(r.type==='flyback')text+=`Ns/Np=${a.n}; ${a.regime==='CCM'?'Vo/Vin=(Ns/Np)D/(1−D)':'Vo=Vin D √(R/(2 Lm fs))'}; Δim=Vin D/(Lm fs)=${F(a.delta)} A. Storage ramps retained. `;
 if(r.type==='forward')text+=`Reset limit D≤Np/(Np+Nr)=${F(1/(1+a.reset))}; selected D=${a.duty}. `;return text;
}
function audit(model,doc,r){
 const parts=doc.components.filter(c=>c.type!=='junction'),net=model.net;
 const voltage=(s,c,j)=>{const ps=c.type.startsWith('coupled')?['p'+j,'n'+j]:Object.keys(D.types[c.type].ports);return (s.state.pressure[net[c.id+'.'+ps[0]]]||0)-(s.state.pressure[net[c.id+'.'+ps[1]]]||0);};
 const energy=s=>parts.reduce((sum,c)=>sum+(c.type==='capacitor'?.5*c.value*1e-6*voltage(s,c)**2:c.type==='inductor'?.5*c.value*1e-3*(s.state.currents[c.id]||0)**2:c.type.startsWith('coupled')?s.magnetics[c.id].energy:0),0);
 let inputJ=0,loadJ=0,lossJ=0,kclMax=0;const charge={},voltSeconds={};
 for(let j=0;j<model.samples.length;j++){
  const s=model.samples[j],h=j?s.t-model.samples[j-1].t:0,balance={};for(const [port,i]of Object.entries(s.state.portI))balance[net[port]]=(balance[net[port]]||0)+i;for(const i of Object.values(balance))kclMax=Math.max(kclMax,Math.abs(i));
  for(const c of parts){const v=voltage(s,c),i=s.state.currents[c.id]||0;if(c.type==='source')inputJ-=v*i*h;else if(['resistor','load','memristor'].includes(c.type)){const e=v*i*h;if(c.id===r?.parts.Rload?.id||c.type==='load')loadJ+=e;else lossJ+=e;}else if(c.type==='switch'){lossJ+=v*(c.bodyDiode?s.state.currents[c.id+'.total']:i)*h;}else if(c.type==='diode')lossJ+=v*i*h;
   if(c.type==='capacitor')charge[c.id]=(charge[c.id]||0)+i*h;
   if(c.type==='inductor')voltSeconds[c.id]=(voltSeconds[c.id]||0)+v*h;
   if(c.type.startsWith('coupled'))for(let w=1;w<=Object.keys(D.types[c.type].ports).length/2;w++)voltSeconds[c.id+'.w'+w]=(voltSeconds[c.id+'.w'+w]||0)+voltage(s,c,w)*h;
  }
 }
 const first=model.samples[0],last=model.samples.at(-1),storedDeltaJ=energy(last)-energy(first);const capacitorBalance=Object.fromEntries(parts.filter(c=>c.type==='capacitor').map(c=>[c.id,{integratedCurrentC:charge[c.id],storedChangeC:last.state.volumes[c.id]-first.state.volumes[c.id],residualC:charge[c.id]-(last.state.volumes[c.id]-first.state.volumes[c.id])}]));
 return {integration:'right-end backward-Euler steps; event states have zero duration',inputJ,loadJ,modeledLossJ:lossJ,storedDeltaJ,numericalResidualJ:inputJ-loadJ-lossJ-storedDeltaJ,kclMaxA:kclMax,capacitorBalance,voltSeconds};
}
function create(doc,options={}){
 doc=D.validate(doc);
 const c={...config(doc),...((options.mode==='leakage'&&options.view===undefined)?{view:'startup'}:{}),...options},r=recognize(doc);D.validate({...doc,settings:{...doc.settings,model:c}});if(c.mode==='ideal')c.losses='ideal';let lossReason='';if(r?.type==='fullboost'&&c.mode!=='ideal'&&c.losses==='ideal'){c.losses='configured';lossReason='Current-fed full bridge has redundant ideal conduction constraints: ideal-device mode is unavailable; configured device losses are active.';}const allowed=availability({...doc,settings:{...doc.settings,model:c}});let effective=c.mode,reason=lossReason;if(!allowed[c.mode].enabled){reason=allowed[c.mode].reason;effective='ripple';}
 if(r?.type==='forward'){const reset=(r.parts.T1.turns?.[1]??1)/(r.parts.T1.turns?.[0]??1);if(r.parts.Q1.pwm?.duty>1/(1+reset))reason+=' Forward reset invalid: D exceeds Np/(Np+Nr); core does not reset. Saturation is not modeled.';}
 const reduced=effective==='ideal'&&allowed.reduction.enabled;
 let model,derivedModel;
 if(reduced)model=reference({...doc,settings:{...doc.settings,model:c}},r);
 else {
  if(effective==='ideal')c.losses='ideal';
  derivedModel=derived(doc,{...c,mode:effective},r);const d=derivedModel.document;
  let steps=Math.max(c.steps,...doc.components.filter(p=>p.pwm).map(p=>Math.ceil((d.settings.duration||.04)*p.pwm.frequency*200)));
  if(effective==='leakage'){const L=r.parts.T1.value*1e-3*(1-c.coupling*c.coupling),C=c.snubberCap*1e-6,tau=Math.min(Math.sqrt((L>0?L:r.parts.T1.value*1e-3)*C),c.snubberResistance*C),h=tau/32;steps=Math.max(steps,Math.ceil((d.settings.duration||.04)/h));if(steps>350000)throw Error('Parasitic timescale needs more than 350,000 steps. Increase snubber capacitance or shorten duration.');}
  if(steps>350000)throw Error('PWM resolution requires more than 350,000 steps. Shorten duration or reduce frequency.');
  const run=(document,n)=>M.create(document,{steps:n,diodeResistance:c.losses==='ideal'?0:.01,allowRedundantConstraints:effective==='ideal'});
  if(c.view==='settled'){try{model=S.solve(d,{dt:(d.settings.duration||.04)/steps,run});}catch(e){throw Error((reason?reason+' ':'')+e.message);}derivedModel.document=model.effectiveDocument;}else model=run(d,steps);
 }
 let a=model.referenceParameters;try{a=a||reducedParameters({...doc,settings:{...doc.settings,model:{...c,losses:'ideal'}}},r);}catch{}
 const metadata={requestedMode:c.mode,mode:effective,label:effective==='ideal'?(reduced?'Ideal · course reference':'Ideal · component dynamics'):effective==='ripple'&&c.view==='startup'?'Transients · finite L/C':labels[effective],approximation:effective==='ideal'?r?.type==='fullboost'?'report CCM cycle; filtering L/C ripple and transformer excitation omitted; symmetric overlap sharing; source feed idealized':'periodic reduced reference; filtering-L ripple omitted; capacitor charge and KCL cycle-averaged':'finite L/C switched backward Euler',window:effective==='ideal'?'Periodic teaching cycle; no startup':c.view==='settled'?'Four converged '+(model.settling?.kind||'PWM')+' cycles':'Startup from zero stored energy',losses:c.losses,reason,equivalent:derivedModel?.equivalent||[],sourceImpedance:reduced&&r?.type==='fullboost'?0:r?.parts.Rin?.value??null,dt:model.dt,topology:r?.type||'custom',formula:effective==='leakage'?formula(null,null):formula(r,a)};
 metadata.requestedView=c.view;metadata.view=reduced?'settled':c.view;metadata.windowStart=model.windowStart||0;metadata.windowEnd=model.windowEnd||model.duration;metadata.settling=model.settling||null;
 metadata.reduced=reduced;metadata.currentSharing=effective==='ideal'&&!reduced?'Redundant consistent ideal constraints use a minimum-norm solution; real branch sharing is not determined.':null;
 if(effective==='ideal'&&!reduced){metadata.approximation='ideal-component network; finite L/C dynamics retained';metadata.window=c.view==='settled'?'Four converged '+(model.settling?.kind||'PWM')+' cycles':'Startup from zero stored energy';metadata.formula=formula(null,null);metadata.reason='No validated ripple-neglected reduction for this graph/operating point. Ideal components are simulated with finite L/C; charging, oscillations and switching ripple are retained. '+allowed.reduction.reason;}
 if(reduced&&r?.type==='fullboost'){metadata.reason='Periodic CCM approximation: capacitor current alternates but stored Q and voltage use the ripple-neglected mean. Transformer excitation omitted. Configured source feed is bypassed only in this report model.';}
 if(effective==='leakage')metadata.magnetic=`Fixed self L and signed turns; Mij=k√(LiLj). Uniform k=${c.coupling} gives PSD L=diag(√L)[(1−k)I+k ssᵀ]diag(√L). No second leakage inductance. E=½iᵀLi. RC snubber dissipates energy even with ideal devices.`;
 if(!reduced)model.audit=audit(model,derivedModel.document,r);
 if(c.overlay&&effective!=='ideal'&&allowed.reduction.enabled)model.referenceModel=reference({...doc,settings:{...doc.settings,model:{...c,losses:'ideal'}}},r);
 // Adding a derived branch can change union-find representative names. Keep
 // pressure aliases for the editable schematic's nets so its pipes and windings
 // consume exactly the same solved pressures as probes on the effective circuit.
 const editableNet=D.nets(doc),aliases=Object.fromEntries(Object.keys(editableNet).map(port=>[editableNet[port],model.net[port]]));
 const tag=s=>{if(s.state)for(const [display,solved]of Object.entries(aliases))s.state.pressure[display]=s.state.pressure[solved];s.metadata=metadata;return s;};
 // Keep the default output-capacitor probe stable across converter modes.
 model.capacitor=r?.parts.Co||model.capacitor;
 if(doc.components.some(c=>c.type==='memristor')){metadata.memory='HP two-region model: M=Ron x+Roff(1−x), QD dx/dt=i F. Forward a→b lowers M. Transients starts at saved x0; Ripple verifies memory too and may fail to settle. No threshold or retention leakage; read current disturbs state.';metadata.formula+=' '+metadata.memory;if(c.view==='startup')metadata.window='Startup from zero C/L energy and configured memristor x0';}
 model.metadata=metadata;model.effectiveDocument=derivedModel?.document||D.clone(doc);if(reduced&&r?.type==='fullboost'){for(const part of model.effectiveDocument.components){if(part.id===r.parts.Rin.id)part.value=0;if(part.type==='switch')part.ron=0;if(part.type==='diode')part.value=0;if(part.bodyDiode)part.bodyDiode={value:0};}}const at=model.at;model.samples.forEach(tag);model.at=t=>tag(at(t));
 return model;
}
const api={defaults,labels,config,recognize,availability,reducedParameters,create,settling,derived,formula,audit};if(node)module.exports=api;else g.EditorModes=api;
})(globalThis);
