/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Power-conserving inertia equivalent of the solver's coupled-inductance matrix.
   Generalized wheel speed = winding current; shaft torque = winding voltage.
   A weighted differential gives Ω = Σ n_i I_i. Shared J = k L1; each
   winding additionally carries leakage inertia J_i = (1-k) L1 n_i².
   Thus E = 1/2 Iᵀ L I and torque_i = Σ L_ij dI_j/dt. */
(function(g){
function state(c,s){
 const count=c.turns?.length||({'coupled':2,'coupled3':3,'coupled4':4}[c.type]),n=Array.from({length:count},(_,j)=>(c.turns?.[j]??1)/(c.turns?.[0]??1)),currents=n.map((_,j)=>s.currents[c.id+'.w'+(j+1)]||0),angles=n.map((_,j)=>s.volumes[c.id+'.w'+(j+1)]||0),L=c.value*.001,k=c.coupling??1;
 const speed=currents.reduce((sum,i,j)=>sum+n[j]*i,0),angle=angles.reduce((sum,q,j)=>sum+n[j]*q,0),sharedEnergy=.5*k*L*speed**2,leakage=currents.map((i,j)=>.5*(1-k)*L*n[j]**2*i**2);
 return {ratios:n,currents,angles,speed,angle,inertia:k*L,sharedEnergy,leakage,energy:sharedEnergy+leakage.reduce((a,b)=>a+b,0)};
}
// Display-only engaged train: the strongest active winding sets the rim speed.
// Never sum opposing winding currents here: that yields magnetizing current,
// not through-flow. The energy-equivalent state() above remains independent.
function motion(model,c,wheels,activeWinding=null){
 const samples=model?.samples||[];
 let driver=-1,lastSign=1;
 const rates=samples.map(v=>{
  const candidates=wheels.map(w=>-(v.state?.currents[c.id+'.w'+(w.j+1)]||0)*w.flip*w.r/(40*w.sign));
  const strongest=candidates.reduce((best,q,j)=>Math.abs(q)>Math.abs(candidates[best]||0)?j:best,0),magnitude=Math.abs(candidates[strongest]||0),primary=wheels.findIndex(w=>w.j===0);
  if(magnitude<1e-9)return 0;
  // Primary conduction defines direction; during freewheel retain the active
  // driver until another winding clearly takes over, avoiding near-tie chatter.
  if(primary>=0&&Math.abs(candidates[primary])>magnitude*.05)driver=primary;
  else if(driver<0||Math.abs(candidates[driver]||0)<magnitude*.85)driver=strongest;
  lastSign=Math.sign(candidates[driver])||lastSign;return activeWinding!==null&&Math.abs(v.state?.currents[c.id+'.w'+(activeWinding+1)]||0)<1e-6?0:lastSign*magnitude;
 });
 const phase=[0];for(let j=1;j<samples.length;j++)phase[j]=phase[j-1]+(samples[j].t-samples[j-1].t)*(rates[j]+rates[j-1])/2;
 return t=>{if(!samples.length)return 0;let lo=0,hi=samples.length-1;while(lo<hi){const mid=Math.ceil((lo+hi)/2);if(samples[mid].t<=t)lo=mid;else hi=mid-1;}const next=Math.min(lo+1,samples.length-1),dt=Math.max(0,Math.min(t,samples[next].t)-samples[lo].t),span=samples[next].t-samples[lo].t;return phase[lo]+rates[lo]*dt+(span? .5*(rates[next]-rates[lo])*dt*dt/span:0);};
}
function draw({svg,c,el,text,updates,doc}){
 svg.replaceChildren();if(!c)return;
 const width=760,height=370;svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
 const group=el('g',{},svg),count=({'coupled':2,'coupled3':3,'coupled4':4}[c.type]),nodes=[],scale=640000/12/40*180/Math.PI*doc.settings.travel;
 text(group,380,19,'Differential + shared flywheel · functional prototype',{'text-anchor':'middle','font-size':14});
 el('path',{d:`M90 180 H670 M380 180 V225`,fill:'none',stroke:'black','stroke-width':1.5},group);
 for(let j=0;j<count;j++){
  const x=120+j*520/(count-1),mount=el('g',{transform:`translate(${x} 96)`},group);
  el('line',{x1:x,y1:96,x2:x,y2:180,stroke:'black','stroke-width':1.4},group);
  el('circle',{r:46,fill:'#8acbfa',stroke:'black','stroke-width':1.5},mount);
  el('circle',{r:34,fill:'white',stroke:'black','stroke-width':1},mount);
  const rotor=el('g',{'data-differential-input':j+1},mount),points=[];
  for(let k=0;k<96;k++){const a=k/96*2*Math.PI,r=54+(k%4<2?1.5:-1.5);points.push(`${r*Math.cos(a)},${r*Math.sin(a)}`);}
  el('polygon',{points:points.join(' '),fill:'none',stroke:'black','stroke-width':1},rotor);
  for(let k=0;k<4;k++){const a=k*Math.PI/2;el('line',{x1:12*Math.cos(a),y1:12*Math.sin(a),x2:45*Math.cos(a),y2:45*Math.sin(a),stroke:k?'#444':'#076aab','stroke-width':k?2:3},rotor);}
  el('circle',{r:13,fill:'#ddd',stroke:'black','stroke-width':1},mount);
  text(mount,0,4,String(j+1),{'text-anchor':'middle','font-size':12,'data-device-symbol':''});
  el('rect',{x:x-82,y:151,width:164,height:20,fill:'white'},group);
  const label=text(group,x,164,'',{'text-anchor':'middle','font-size':11});nodes.push({rotor,label});
 }
 el('rect',{x:353,y:165,width:54,height:31,rx:5,fill:'white',stroke:'black','stroke-width':1.5},group);
 text(group,380,186,'Σ nᵢωᵢ',{'text-anchor':'middle','font-size':13});
 const fly=el('g',{transform:'translate(380 272)'},group);
 el('circle',{r:45,fill:'#ddd',stroke:'black','stroke-width':3},fly);
 const spin=el('g',{'data-differential-flywheel':''},fly);
 for(let j=0;j<4;j++){const a=j*Math.PI/2;el('line',{x1:13*Math.cos(a),y1:13*Math.sin(a),x2:41*Math.cos(a),y2:41*Math.sin(a),stroke:j?'#555':'#076aab','stroke-width':j?2:4},spin);}
 el('circle',{r:12,fill:'white',stroke:'black'},fly);text(fly,0,4,'J',{'text-anchor':'middle','font-size':12,'data-device-symbol':''});
 const info=text(group,380,341,'',{'text-anchor':'middle','font-size':12});
 const phase=text(group,380,359,'',{'text-anchor':'middle','font-size':11});
 updates.push((v,s)=>{const m=state(c,s);nodes.forEach((node,j)=>{node.rotor.setAttribute('transform',`rotate(${m.angles[j]*scale})`);node.label.textContent=`W${j+1}: ${m.currents[j].toFixed(3)} A · n = ${m.ratios[j]}`;});
 spin.setAttribute('transform',`rotate(${m.angle*scale})`);spin.setAttribute('data-energy',m.energy);info.textContent=`Stored ${(m.energy*1000).toFixed(3)} mJ · shared ${(m.sharedEnergy*1000).toFixed(3)} mJ · leakage ${(m.leakage.reduce((a,b)=>a+b,0)*1000).toFixed(3)} mJ`;
 const powers=v?.magnetics?.[c.id]?.powers||[],total=powers.reduce((a,b)=>a+b,0);
 phase.textContent=total>1e-5?'Flywheel gains stored energy':total< -1e-5?'Flywheel releases stored energy':powers.some(p=>Math.abs(p)>1e-5)?'Power transfers with nearly constant stored energy':'At rest / no net transfer';
 });
}
const api={state,draw,motion};if(typeof module!=='undefined')module.exports=api;else g.EditorMagnetic=api;
})(globalThis);
