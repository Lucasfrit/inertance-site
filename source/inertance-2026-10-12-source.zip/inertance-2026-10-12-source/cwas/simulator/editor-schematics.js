/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* Browser-local custom schematics: explicit saved checkpoints and autosaved drafts. */
(function(g){
const D=typeof module!=='undefined'?require('./editor-document.js'):g.CircuitDocument;
const KEY='inertance-schematics-v1';
function create(storage){
 let entries=[],lastId=null,deleted=[],error='',readable=true;
 const copy=value=>D.clone(value);
 const document=value=>{if(JSON.stringify(value).length>1e6)throw Error('Schematic exceeds 1 MB.');return D.validate(copy(value));};
 function read(){
  if(!storage)return {entries:[],lastId:null,deleted:[]};
  const raw=storage.getItem(KEY);if(!raw)return {entries:[],lastId:null,deleted:[]};
  const data=JSON.parse(raw);if(data.version!==1||!Array.isArray(data.entries))throw Error('Unrecognized browser save format.');
  const seen=new Set(),items=data.entries.map(e=>{if(typeof e.id!=='string'||!e.id||seen.has(e.id)||typeof e.name!=='string')throw Error('Invalid browser save.');seen.add(e.id);return {id:e.id,name:e.name.slice(0,80),saved:document(e.saved),draft:document(e.draft),updated:e.updated,origin:e.origin?.kind==='example'&&typeof e.origin.key==='string'&&typeof e.origin.name==='string'?{kind:'example',key:e.origin.key,name:e.origin.name.slice(0,80)}:null};});
  const deleted=Array.isArray(data.deleted)?data.deleted.filter(id=>typeof id==='string'):[];return {entries:items.filter(e=>!deleted.includes(e.id)),lastId:items.some(e=>e.id===data.lastId)&&!deleted.includes(data.lastId)?data.lastId:null,deleted};
 }
 try{({entries,lastId,deleted}=read());}catch(e){readable=false;error='Could not read browser schematics. Existing browser data is retained; use Save JSON to keep this work.';}
 function write(changed,selected=lastId,{remove=null,restore=false}={}){
  // Merge other schematics written by another tab; update only this entry.
  try{if(!storage||!readable)throw Error('Storage unavailable.');const latest=read(),gone=new Set([...deleted,...latest.deleted]),merged=new Map([...entries,...latest.entries].map(e=>[e.id,e]));if(remove)gone.add(remove);if(restore&&changed)gone.delete(changed.id);if(changed)merged.set(changed.id,changed);const next={version:1,entries:[...merged.values()].filter(e=>!gone.has(e.id)),lastId:gone.has(selected)?null:selected,deleted:[...gone]};storage.setItem(KEY,JSON.stringify(next));entries=next.entries;lastId=next.lastId;deleted=next.deleted;error='';return true;}
  catch(e){error='Browser saving is unavailable or full. Your work remains open; use Save JSON to keep a copy.';return false;}
 }
 function entry(id){const e=entries.find(e=>e.id===id);if(!e)throw Error('Saved schematic was not found.');return e;}
 return {
  get error(){return error;},get lastId(){return lastId;},
  retry(candidate){if(candidate)storage=candidate;try{read();readable=true;return write(null);}catch(e){error='Could not read browser schematics. Existing browser data is retained; use Save JSON to keep this work.';return false;}},
  remove(id){const removed=copy(entry(id)),persisted=write(null,lastId===id?null:lastId,{remove:id});return {entry:removed,persisted};},
  restore(value){const e=copy(value);e.saved=document(e.saved);e.draft=document(e.draft);return write(e,e.id,{restore:true});},
  list(){return entries.map(e=>({id:e.id,name:e.name,edited:JSON.stringify(e.saved)!==JSON.stringify(e.draft)||!!e.origin}));},
  open(id){const e=entry(id);lastId=id;write(null,id);return copy(e);},
  select(id){lastId=id;write(null,id);},
  create(doc,name,origin=null){const saved=document(doc),id='custom-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10),e={id,name:(name||'Custom schematic '+(entries.length+1)).trim().slice(0,80),saved,draft:copy(saved),origin:copy(origin),updated:Date.now()};entries.push(e);lastId=id;const persisted=write(e,id);return {...copy(e),persisted};},
  autosave(id,doc){const e=entry(id);e.draft=document(doc);e.updated=Date.now();return write(e,id);},
  rename(id,name){const prior=entry(id),e={...prior,name:name.trim().slice(0,80)||prior.name,updated:Date.now()},persisted=write(e,id);return {...copy(persisted?e:prior),persisted};},
  save(id,doc,name){const prior=entry(id),saved=document(doc),e={...prior,name:(name||prior.name).trim().slice(0,80)||'Custom schematic',origin:null,saved,draft:copy(saved),updated:Date.now()},persisted=write(e,id);return {...copy(persisted?e:prior),persisted};},
  origin(id){return copy(entry(id).origin||null);},
  checkpoint(id){return copy(entry(id).saved);}
 };
}
const api={create,key:KEY};if(typeof module!=='undefined')module.exports=api;else g.EditorSchematics=api;
})(globalThis);
