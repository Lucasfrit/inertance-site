/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
// Diagram paths are separate from the electrical state model.
function buildDiagram(){
 powerLinks.length=0;pipes.length=0;caps.length=0;rotors.length=0;switches.length=0;diodes.length=0;gears.length=0;valueLabels.length=0;$('#cl-defs').replaceChildren();$('#cl-pipes').replaceChildren();parts.replaceChildren();labels.replaceChildren();
 const p=model.p,type=p.type,iso=['flyback','half','fullbuck','fullboost'].includes(type);
 function label(x,y,name,value){text(x,y,name);if(value){const n=text(x,y+21,value);n.classList.add('value');valueLabels.push(n);}}
 function valve(x,y,key,name,orientation='v'){const h=orientation==='h',n=el('line',{x1:h?x:x-10,x2:h?x:x+10,y1:h?y-10:y,y2:h?y+10:y,stroke:'black','stroke-width':4},parts);switches.push({n,key,h});label(x+(h?0:-28),y+(h?35:-18),name);}
 function diode(x,y,key,name,h=true){const n=el('line',{x1:h?x:x-6,x2:h?x:x+6,y1:h?y-6:y,y2:h?y+6:y,stroke:'black','stroke-width':3},parts);diodes.push({n,key,x,y,h});label(x+(h?0:-25),y+(h?30:0),name);}
 function cap(x,top,bottom,key,voltage,name,C,p0=voltage,p1='zero'){const cy=(top+bottom)/2;pipe(`M${x} ${top} V${cy-42}`,key,p0,p0);pipe(`M${x} ${cy+42} V${bottom}`,key,p1,p1);const g=el('g',{'data-capacitor':name},parts);el('rect',{x:x-25,y:cy-42,width:50,height:84,fill:'white',stroke:'black','stroke-width':2},g);const a=el('rect',{x:x-23,y:cy-40,width:46,height:40,fill:'#8fc5ee'},g),b=el('rect',{x:x-23,y:cy,width:46,height:40,fill:'#d8ecfa'},g),wall=el('line',{x1:x-24,x2:x+24,y1:cy,y2:cy,stroke:'black','stroke-width':4},g),spring=el('path',{fill:'none',stroke:'black','stroke-width':1.5},g);caps.push({x,cy,C,key,voltage,p0,p1,a,b,wall,spring});label(p1==='mid'||voltage==='vc2'?x+47:x,p1==='mid'||voltage==='vc2'?cy-12:cy-85,name,(C*1e6).toFixed(0)+' µF');}
 function wheel(cx,cy,r,key,pa,pb,name,parameter,motor=false,reverse=false){if(key==='i')reverse=true;const dir=reverse?-1:1,offset=.22*r*dir,py=cy-r-22,y=cy-.866*r;pipe(`M${cx+offset} ${py} C${cx+offset} ${y-12} ${cx+.64*r*dir} ${y-9} ${cx+.5*r*dir} ${y} A${r} ${r} 0 1 ${reverse?0:1} ${cx-.5*r*dir} ${y} C${cx-.64*r*dir} ${y-9} ${cx-offset} ${y-12} ${cx-offset} ${py}`,key,pa,pb,14);const rot=el('g',{},parts);for(let k=0;k<4;k++){const a=k*Math.PI/2;el('line',{x1:cx+15*Math.cos(a),y1:cy+15*Math.sin(a),x2:cx+(r+3)*Math.cos(a),y2:cy+(r+3)*Math.sin(a),stroke:'#444','stroke-width':2},rot);}el('circle',{cx,cy,r:18,fill:'#ccc',stroke:'black','stroke-width':2},parts);text(cx,cy+5,motor?'':name?'J':'');if(motor){el('line',{x1:cx+18,y1:cy,x2:cx+44,y2:cy,stroke:'black','stroke-width':4},parts);el('rect',{x:cx+44,y:cy-14,width:32,height:28,fill:'white',stroke:'black','stroke-width':2},parts);text(cx+60,cy+5,'M');}registerRotor(rot,cx,cy,r,key,dir,key==='i');label(cx,cy+r+28,name,parameter);return{left:cx-offset,right:cx+offset,y:py};}
 function load(x,top,bottom){pipe(`M${x} ${top} V${top+70}`,'ir','vo','vo');pipe(`M${x} ${top+70} V${bottom-70}`,'ir','vo','zero',4);pipe(`M${x} ${bottom-70} V${bottom}`,'ir','zero','zero');label(x-26,(top+bottom)/2,'R',p.R+' Ω');}
 function primary(x,key,a,b){const w=wheel(x,245,35,key,a,b,'',null);text(x,250,'P');pipe(`M${x} 180 H${w.right} V${w.y}`,key,a,a);pipe(`M${w.left} ${w.y} V165 H${x-48} V310 H${x}`,key,b,b);}
 const ground=420,top=90;
 const pump=wheel(70,260,36,'is','zero','vs','Source',p.vs+' V',true);pipe(`M70 ${ground} H22 V170 H${pump.right} V${pump.y}`,'is','zero','zero');pipe(`M${pump.left} ${pump.y} V${top} H165`,'is','vs','vi');
 if(!iso){
 cap(190,top,ground,'ici','vi','Cᵢ',p.Ci);pipe('M165 90 H190','is','vi','vi');
 const out=1030;cap(out,top,ground,'ico','vc','Cₒ',p.Co);pipe('M1030 90 H1130','ir','vo','vo');load(1130,top,ground);pipe('M1130 420 H1030','ir','zero','zero');pipe('M190 420 H70','is','zero','zero');
 if(type==='buck'){
 pipe('M190 90 H360','iq','vi','vi');pipe('M360 90 H490','iq','sw','sw');valve(360,90,'q1','Q','h');pipe('M490 420 V90','id','zero','sw');diode(490,270,'id','Dᵢ',false);const w=wheel(690,240,65,'i','sw','vo','L',p.L*1000+' mH');pipe(`M490 90 H${w.right} V${w.y}`,'i','sw','sw');pipe(`M${w.left} ${w.y} V40 H1030 V90`,'i','vo','vo');pipe('M1030 420 H490','i','zero','zero');pipe('M490 420 H190','iq','zero','zero');
 }else if(type==='boost'){
 const w=wheel(380,240,65,'i','vi','sw','L',p.L*1000+' mH');pipe(`M190 90 H${w.right} V${w.y}`,'i','vi','vi');pipe(`M${w.left} ${w.y} V40 H650 V90`,'i','sw','sw');pipe('M650 90 V260','iq','sw','sw');pipe('M650 260 V420','iq','zero','zero');valve(650,260,'q1','Q');pipe('M650 90 H830','id','sw','sw');pipe('M830 90 H1030','id','vo','vo');diode(830,90,'id','Dᵢ');pipe('M1030 420 H650','id','zero','zero');pipe('M650 420 H190','i','zero','zero');
 }else if(type==='inverting'){
 pipe('M190 90 H350','iq','vi','vi');pipe('M350 90 H500','iq','sw','sw');valve(350,90,'q1','Q','h');const w=wheel(530,250,65,'i','sw','zero','L',p.L*1000+' mH');pipe(`M500 90 H${w.right} V${w.y}`,'i','sw','sw');pipe(`M${w.left} ${w.y} V130 H425 V420 H190`,'i','zero','zero');pipe('M1030 90 H815','id','vo','vo');pipe('M815 90 H500','id','sw','sw');diode(815,90,'id','Dᵢ ←');diodes.at(-1).reverse=true;pipe('M190 420 H1030','output','zero','zero');label(1030,65,'− Vₒ');
 }else{
 pipe('M190 90 H310','iq','vi','vi');pipe('M310 90 H405','iq','left','left');valve(310,90,'q1','Q₁','h');pipe('M405 420 V90','d2','zero','left');diode(405,280,'d2','D₁',false);const w=wheel(600,240,60,'i','left','right','L',p.L*1000+' mH');pipe(`M405 90 H${w.right} V${w.y}`,'i','left','left');pipe(`M${w.left} ${w.y} V40 H765 V90`,'i','right','right');pipe('M765 90 V270','q2','right','right');pipe('M765 270 V420','q2','zero','zero');valve(765,270,'q2','Q₂');pipe('M765 90 H885','id','right','right');pipe('M885 90 H1030','id','vo','vo');diode(885,90,'id','D₂');pipe('M1030 420 H765','output','zero','zero');pipe('M765 420 H405','i','zero','zero');pipe('M405 420 H190','iq','zero','zero');
 }
 }else{
 // Three-port, center-tapped secondary. Opposing freewheel currents cancel ampere-turns.
 pipe('M165 90 H190','is','vi','vi');cap(190,90,420,'ici','vi','Cᵢ',p.Ci);pipe('M190 420 H70','is','zero','zero');
 const full=type==='fullbuck'||type==='fullboost',fly=type==='flyback';let bus='vi';
 if(type==='fullboost'){const w=wheel(310,220,40,'i','vi','sw','L',p.L*1000+' mH');pipe(`M190 90 H${w.right} V${w.y}`,'i','vi','vi');pipe(`M${w.left} ${w.y} V45 H390 V90`,'i','sw','sw');bus='sw';}else if(type==='half'){pipe('M190 90 H280','input','vi','vi');pipe('M280 90 H390','q1','vi','vi');}else pipe('M190 90 H390','input','vi','vi');
 if(fly){pipe('M390 90 H580 V180','iq','vi','vi');primary(580,'iq','vi','sw');pipe('M580 310 V365','iq','sw','sw');pipe('M580 365 V420 H190','iq','zero','zero');valve(580,365,'q1','Q');}
 else if(full){
 pipe('M390 90 H525','q3',bus,bus);pipe('M390 90 V170','q1',bus,bus);pipe('M390 170 V250','q1','pa','pa');pipe('M390 250 V335','q2','pa','pa');pipe('M390 335 V420','q2','zero','zero');pipe('M525 90 V170','q3',bus,bus);pipe('M525 170 V250','q3','pb','pb');pipe('M525 250 V335','q4','pb','pb');pipe('M525 335 V420 H390','q4','zero','zero');pipe('M390 420 H190','input','zero','zero');valve(390,170,'q1','Q₁');valve(390,335,'q2','Q₂');valve(525,170,'q3','Q₃');valve(525,335,'q4','Q₄');pipe('M390 250 H470 V130 H600 V180','ip','pa','pa');pipe('M600 310 V380 H500 V250 H525','ip','pb','pb');primary(600,'ip','pa','pb');
 }else{
 // Dynamic split capacitors; midpoint pressure follows capacitor charge.
 pipe('M390 90 V170','q1','vi','vi');pipe('M390 170 V250','q1','pa','pa');pipe('M390 250 V335','q2','pa','pa');pipe('M390 335 V420 H280','q2','zero','zero');valve(390,170,'q1','Q₁');valve(390,335,'q2','Q₂');pipe('M390 250 H535 V130 H600 V180','ip','pa','pa');primary(600,'ip','pa','mid');pipe('M600 310 V390 H335 V250 H295','ip','mid','mid');cap(280,90,250,'ic1','vc1','C₁',p.C1,'vi','mid');cap(280,250,420,'ic2','vc2','C₂',p.C2,'mid','zero');pipe('M280 420 H190','input','zero','zero');pipe('M280 250 H295','ip','mid','mid');
 }
 const px=fly?580:600,sx=710;
 if(fly){pipe('M710 420 V310','output','zero','zero');const w=wheel(710,245,35,'output','zero','secv','',null,false,true);text(710,250,'S');pipe(`M710 310 H662 V165 H${w.right} V${w.y}`,'output','zero','zero');pipe(`M${w.left} ${w.y} V180 H710`,'output','secv','secv');pipe('M710 180 V90 H850','output','secv','secv');pipe('M850 90 H1030','output','vo','vo');diode(850,90,'id','Dᵢ');}
 else{
 // Restore one compact, center-tapped wheel with its inlet on the left.
 pipe('M660 250 H675 V245 A35 35 0 0 1 742 230 L750 200 H710 V180','d1','zero','s1');
 pipe('M710 180 V90 H830','d1','s1','s1');pipe('M830 90 H900 V145','d1','rect','rect');diode(830,90,'d1','D₁');
 pipe('M660 250 H675 V245 A35 35 0 0 0 742 260 L750 290 H710 V310','d2','zero','s2');
 pipe('M710 310 V355 H830','d2','s2','s2');pipe('M830 355 H900 V145','d2','rect','rect');diode(830,355,'d2','D₂');
 pipe('M1030 420 H660 V250','output','zero','zero');
 // Two paddle sectors in one housing retain the individual winding-flow cues.
 for(const[key,upper,sign]of[['d1',true,1],['d2',false,-1]]){
  const id='cl-sector-'+key,clip=el('clipPath',{id},$('#cl-defs'));
  el('rect',{x:670,y:upper?205:245,width:80,height:40},clip);
  const housing=el('g',{'clip-path':`url(#${id})`},parts),rot=el('g',{},housing);
  for(let k=0;k<4;k++){const a=k*Math.PI/2;el('line',{x1:710+12*Math.cos(a),y1:245+12*Math.sin(a),x2:710+36*Math.cos(a),y2:245+36*Math.sin(a),stroke:'#444','stroke-width':2},rot);}
  registerRotor(rot,710,245,35,key,sign);const w=rotors.at(-1);housing.append(w.arrow,w.tip);
 }
 el('circle',{cx:710,cy:245,r:18,fill:'#ccc',stroke:'black','stroke-width':2},parts);text(710,250,'S');
 }
 // Dashed power links deliberately do not impose rigid winding-speed constraints.
 function link(d,key){const n=el('path',{d,fill:'none',stroke:'#0784cf','stroke-width':3,'stroke-dasharray':'5 5','data-power-link':key},parts);powerLinks.push({n,key});}
 if(fly){
  const cx=645,cy=345,r=24,rot=el('g',{},parts);
  el('circle',{cx,cy,r,fill:'#ddd',stroke:'black','stroke-width':2},parts);
  el('line',{x1:cx,y1:cy,x2:cx+r,y2:cy,stroke:'#444','stroke-width':3},rot);
  registerRotor(rot,cx,cy,r,'i',1,true);text(cx,cy+5,'Jₘ');
  link(`M${px+25} 260 L630 323`,'iq');link('M660 323 L690 260','output');
  label(645,450,'Shared storage',p.L*1000+' mH · 1 : '+p.n);
 }else{

  label(650,470,'Shared core · 1 : '+p.n);
 }
 const ratio=Math.max(.5,Math.min(2,p.n)),r1=(sx-px)/(1+ratio),r2=r1*ratio,cy=245;
 for(const[x,r,scale]of[[px,r1,1],[sx,r2,-1/ratio]]){
  const g=el('g',{'data-gear':x===px?'primary':'secondary'},parts);let d='';const teeth=Math.round(r/2);
  for(let j=0;j<teeth*4;j++){const a=j/(teeth*4)*Math.PI*2,rad=r+(j%4===0||j%4===3?2:-2);d+=(j?' L':'M')+(x+rad*Math.cos(a))+' '+(cy+rad*Math.sin(a));}
  el('path',{d:d+' Z',fill:'white','fill-opacity':.04,stroke:'black','stroke-width':1.5},g);
  el('line',{x1:x-r*.55,y1:cy,x2:x+r*.55,y2:cy,stroke:'black','stroke-width':1.5},g);
  gears.push({g,x,cy,r,key:fly?'i':'ip',scale});
 }
 if(ratio!==p.n)label(650,500,'Actual 1 : '+p.n+' · gears shown 1 : '+ratio);
 if(!fly&&type!=='fullboost'){const w=wheel(985,250,43,'i','rect','vo','L',p.L*1000+' mH');pipe(`M900 145 H${w.right} V${w.y}`,'i','rect','rect');pipe(`M${w.left} ${w.y} V100 H1080 V145`,'i','vo','vo');cap(1080,145,420,'ico','vc','Cₒ',p.Co);pipe('M1080 145 H1160','ir','vo','vo');load(1160,145,420);pipe('M1160 420 H1080','ir','zero','zero');pipe('M1080 420 H1030','i','zero','zero');}
 else{if(!fly)pipe('M900 145 H1030 V90','output','vo','vo');cap(1030,90,420,'ico','vc','Cₒ',p.Co);pipe('M1030 90 H1130','ir','vo','vo');load(1130,90,420);pipe('M1130 420 H1030','ir','zero','zero');if(fly)pipe('M1030 420 H710','output','zero','zero');}
 }
 $('.water').setAttribute('viewBox',iso?'0 0 1200 550':'0 0 1200 500');pressureLabel=text(600,iso?533:480,'');
}
