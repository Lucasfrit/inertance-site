/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* RLC and piecewise-linear diode transient MNA, backward Euler. No hidden wire storage.
   Ideal DC sources and ideal open/closed switches; uncharged capacitors. */
(function(g){
const D=typeof module!=='undefined'?require('./editor-document.js'):g.CircuitDocument;
const MR=typeof module!=='undefined'?require('./editor-memristor-model.js'):g.EditorMemristorModel;
function factor(matrix){const a=matrix.map(row=>row.slice()),n=a.length,swaps=[];for(let k=0;k<n;k++){let pivot=k;for(let j=k+1;j<n;j++)if(Math.abs(a[j][k])>Math.abs(a[pivot][k]))pivot=j;if(Math.abs(a[pivot][k])<1e-13)throw Error('Floating node or conflicting ideal sources/switches. Check return connections and source polarity.');swaps.push(pivot);[a[k],a[pivot]]=[a[pivot],a[k]];for(let j=k+1;j<n;j++){a[j][k]/=a[k][k];for(let h=k+1;h<n;h++)a[j][h]-=a[j][k]*a[k][h];}}return rhs=>{const b=rhs.slice();for(let k=0;k<n;k++)[b[k],b[swaps[k]]]=[b[swaps[k]],b[k]];for(let k=0;k<n;k++)for(let j=k+1;j<n;j++)b[j]-=a[j][k]*b[k];for(let k=n-1;k>=0;k--){for(let j=k+1;j<n;j++)b[k]-=a[k][j]*b[j];b[k]/=a[k][k];}return b;};}
// Rank-deficient ideal constraints may leave parallel branch currents undefined.
// Preserve all equations and choose the minimum-norm state; never add resistance.
// Inconsistent equations still fail. Enabled only by the general Ideal model.
function redundantFactor(matrix){
 const n=matrix.length,a=matrix.map(row=>row.slice()),transform=Array.from({length:n},(_,i)=>Array.from({length:n},(_,j)=>+(i===j))),pivots=[];
 const scales=a.map(row=>Math.max(...row.map(Math.abs),1e-30));
 for(let i=0;i<n;i++)for(let j=0;j<n;j++){a[i][j]/=scales[i];transform[i][j]/=scales[i];}
 let rank=0;
 for(let col=0;col<n;col++){
  let best=rank;for(let i=rank+1;i<n;i++)if(Math.abs(a[i][col])>Math.abs(a[best][col]))best=i;
  if(rank===n||Math.abs(a[best][col])<1e-11)continue;
  [a[rank],a[best]]=[a[best],a[rank]];[transform[rank],transform[best]]=[transform[best],transform[rank]];
  const pivot=a[rank][col];for(let j=0;j<n;j++){a[rank][j]/=pivot;transform[rank][j]/=pivot;}
  for(let i=0;i<n;i++)if(i!==rank){const v=a[i][col];for(let j=0;j<n;j++){a[i][j]-=v*a[rank][j];transform[i][j]-=v*transform[rank][j];}}
  pivots.push(col);rank++;
 }
 const free=Array.from({length:n},(_,i)=>i).filter(i=>!pivots.includes(i));
 const basis=free.map(col=>{const v=Array(n).fill(0);v[col]=1;pivots.forEach((p,i)=>v[p]=-a[i][col]);return v;});
 const dot=(x,y)=>x.reduce((sum,v,i)=>sum+v*y[i],0),gram=basis.map(x=>basis.map(y=>dot(x,y))),solve=free.length?factor(gram):null;
 return rhs=>{
  const b=transform.map(row=>dot(row,rhs));
  for(let i=rank;i<n;i++)if(Math.abs(b[i])>1e-8*Math.max(1,transform[i].reduce((sum,v,j)=>sum+Math.abs(v*rhs[j]),0)))throw Error('Conflicting ideal constraints: no consistent voltage/current state.');
  const x=Array(n).fill(0);pivots.forEach((p,i)=>x[p]=b[i]);
  if(solve){const coefficients=solve(basis.map(v=>-dot(v,x)));basis.forEach((v,j)=>v.forEach((value,i)=>x[i]+=coefficients[j]*value));}
  return x;
 };
}
function create(doc,{steps=5000,diodeResistance=.01,allowRedundantConstraints=false}={}){
const originals=doc.components.filter(c=>c.type!=='junction'),coupled=originals.filter(c=>c.type.startsWith('coupled')),parts=originals.flatMap(c=>c.type.startsWith('coupled')?Array.from({length:Object.keys(D.types[c.type].ports).length/2},(_,j)=>({id:c.id+'.w'+(j+1),owner:c.id,winding:j,type:'inductor',value:c.value*((c.turns?.[j]??1)/(c.turns?.[0]??1))**2,ratio:(c.turns?.[j]??1)/(c.turns?.[0]??1),coupling:c.coupling??1})):c.type==='switch'&&c.bodyDiode?[c,{id:c.id+'.diode',owner:c.id,body:true,type:'diode',value:c.bodyDiode.value}]:c),sources=parts.filter(c=>c.type==='source'),caps=parts.filter(c=>c.type==='capacitor'),switches=parts.filter(c=>c.type==='switch'),inductors=parts.filter(c=>c.type==='inductor'),diodes=parts.filter(c=>c.type==='diode'),unsupported=parts.filter(c=>!['source','resistor','memristor','capacitor','switch','inductor','diode','load','flowmeter','pressuremeter','input','output'].includes(c.type));if(unsupported.length)throw Error('This component has no electrical solver model: '+unsupported.map(c=>c.id+' ('+c.type+')').join(', ')+' still needs a solver model.');if(diodes.length>8)throw Error('This diode solver supports up to eight diodes.');if(!sources.length)throw Error('Add a supply and connect its return.');if(parts.length>60)throw Error('This circuit solver review supports up to 60 electrical components.');for(const c of originals)for(const port of Object.keys(D.types[c.type].ports))if(!doc.wires.some(w=>D.key(w.from)===c.id+'.'+port||D.key(w.to)===c.id+'.'+port))throw Error('Unconnected fitting: '+c.id+'.'+port+'. Connect it before Run.');
const net=D.nets(doc),ground=net[doc.settings.referencePort?D.key(doc.settings.referencePort):sources[0].id+'.n'],supply=net[sources[0].id+'.p'],edges=parts.map(c=>{const ps=c.body?['b','a']:c.owner?['p'+(c.winding+1),'n'+(c.winding+1)]:Object.keys(D.types[c.type].ports),owner=c.owner||c.id;return {c,ps,owner,a:net[owner+'.'+ps[0]],b:net[owner+'.'+ps[1]]}});
// Each galvanically isolated network has its own arbitrary voltage reference.
// These references remove common-mode freedom; they are not electrical connections.
const allNodes=[...new Set(edges.flatMap(e=>[e.a,e.b]))],unseen=new Set(allNodes),references=[ground],islands={};while(unseen.size){const first=unseen.values().next().value,seen=new Set([first]),todo=[first];while(todo.length){const n=todo.pop();unseen.delete(n);islands[n]=first;for(const e of edges.filter(e=>e.c.type!=='pressuremeter')){const next=e.a===n?e.b:e.b===n?e.a:null;if(next&&!seen.has(next)){seen.add(next);todo.push(next);}}}if(!seen.has(ground)){const winding=edges.find(e=>e.c.owner&&seen.has(e.b));const capacitor=edges.find(e=>e.c.type==='capacitor'&&seen.has(e.b));references.push(capacitor?.b||winding?.b||first);}}
for(const e of edges.filter(e=>e.c.type==='pressuremeter'))if(islands[e.a]!==islands[e.b])throw Error(e.c.id+' spans isolated circuits with no common voltage reference. Connect both sensing leads within one circuit.');
const nodes=allNodes.filter(n=>!references.includes(n)),index=Object.fromEntries(nodes.map((n,j)=>[n,j])),manual=(doc.settings.manualEvents||[]).filter(e=>switches.some(c=>c.id===e.id)),duration=doc.settings.duration||Math.max(doc.settings.loadOn+Math.max(.01,...switches.map(c=>c.value*.001))+doc.settings.tail,...sources.filter(c=>c.waveform==='sine').map(c=>4/(c.frequency||50))),dt=duration/steps;
const inductance=(a,b)=>a.id===b.id?a.value*1e-3:a.owner&&a.owner===b.owner?a.coupling*Math.sqrt(a.value*b.value)*1e-3*Math.sign(a.ratio*b.ratio):0;
const gate=(c,t)=>{const events=manual.filter(e=>e.id===c.id&&e.time<=t).sort((a,b)=>a.time-b.time);if(events.length)return events.at(-1).on;if(c.pwm){const phase=((t*c.pwm.frequency-(c.pwm.phase||0))%1+1)%1;return phase<c.pwm.duty;}return t>=doc.settings.loadOn&&t<doc.settings.loadOn+c.value*.001;};
const boundaries=[0,duration,...switches.flatMap(c=>[doc.settings.loadOn,doc.settings.loadOn+c.value*.001]),...manual.map(e=>e.time),...switches.filter(c=>c.pwm).flatMap(c=>{const out=[];for(let k=-1;k<=Math.ceil(duration*c.pwm.frequency);k++)out.push((k+(c.pwm.phase||0))/c.pwm.frequency,(k+(c.pwm.phase||0)+c.pwm.duty)/c.pwm.frequency);return out;})].filter(t=>t>=0&&t<=duration).sort((a,b)=>a-b),times=[...new Set([...Array.from({length:steps+1},(_,j)=>j*dt),...boundaries])].sort((a,b)=>a-b),cache=new Map();let oldCurrent=Object.fromEntries(inductors.map(c=>[c.id,0])),diodeMask=(1<<diodes.length)-1;let oldVolt=Object.fromEntries(caps.map(c=>[c.id,0])),oldQ=Object.fromEntries(parts.map(c=>[c.id,0]));
const memristors=parts.filter(c=>c.type==='memristor'),memEdges=edges.filter(e=>e.c.type==='memristor');
let oldX=Object.fromEntries(memristors.map(c=>[c.id,MR.parameters(c).x0])),oldMemV=Object.fromEntries(memristors.map(c=>[c.id,0])),trialX={...oldX};
function electrical(t,h,gateTime,integrate=true){const switchStates=Object.fromEntries(switches.map(c=>[c.id,gate(c,gateTime)]));let solution=null;const attempts=[diodeMask,...Array.from({length:1<<diodes.length},(_,j)=>j).filter(j=>j!==diodeMask)];let lastError;
for(const mask of attempts){const onDiode=c=>c.type==='diode'&&!!(mask&(1<<diodes.findIndex(d=>d.id===c.id))),constraints=edges.filter(e=>['source','inductor','flowmeter','input','output'].includes(e.c.type)||e.c.type==='switch'&&switchStates[e.c.id]||onDiode(e.c)),n=nodes.length+constraints.length,k=Object.values(switchStates).map(Boolean).join(',')+'|'+mask+'|'+h.toPrecision(12);try{let item=memristors.length?null:cache.get(k);if(!item){const matrix=Array.from({length:n},()=>Array(n).fill(0)),stamp=(a,b,value)=>{const i=index[a],j=index[b];if(i!==undefined)matrix[i][i]+=value;if(j!==undefined)matrix[j][j]+=value;if(i!==undefined&&j!==undefined){matrix[i][j]-=value;matrix[j][i]-=value;}};
for(const e of edges)if(['resistor','load'].includes(e.c.type))stamp(e.a,e.b,1/e.c.value);else if(e.c.type==='memristor')stamp(e.a,e.b,1/MR.resistance(trialX[e.c.id],MR.parameters(e.c)));else if(e.c.type==='capacitor')stamp(e.a,e.b,e.c.value*1e-6/h);;
constraints.forEach((e,j)=>{const branch=nodes.length+j,i=index[e.a],k=index[e.b];if(i!==undefined){matrix[i][branch]+=1;matrix[branch][i]+=1;}if(k!==undefined){matrix[k][branch]-=1;matrix[branch][k]-=1;}if(e.c.type==='diode')matrix[branch][branch]=-(e.c.ron??diodeResistance);if(e.c.type==='switch')matrix[branch][branch]=-(e.c.ron||0);if(e.c.type==='inductor')constraints.forEach((other,k)=>{if(other.c.type==='inductor')matrix[branch][nodes.length+k]-=inductance(e.c,other.c)/h;});});let solve;try{solve=factor(matrix);}catch(error){if(!allowRedundantConstraints)throw error;solve=redundantFactor(matrix);}item={solve};if(!memristors.length)cache.set(k,item);}
const rhs=Array(n).fill(0);for(const e of edges){const injection=e.c.type==='capacitor'?e.c.value*1e-6/h*oldVolt[e.c.id]:0;if(index[e.a]!==undefined)rhs[index[e.a]]+=injection;if(index[e.b]!==undefined)rhs[index[e.b]]-=injection;}constraints.forEach((e,j)=>rhs[nodes.length+j]=e.c.type==='source'?(e.c.waveform==='sine'?(e.c.offset||0)+e.c.value*Math.sin(2*Math.PI*(e.c.frequency||50)*t):e.c.value):e.c.type==='diode'?e.c.value:e.c.type==='inductor'?-inductors.reduce((sum,c)=>sum+inductance(e.c,c)*oldCurrent[c.id]/h,0):0);
const x=item.solve(rhs),pressure=Object.fromEntries(references.map(n=>[n,0]));nodes.forEach((node,j)=>pressure[node]=x[j]);const branches=Object.fromEntries(constraints.map((e,j)=>[e.c.id,x[nodes.length+j]]));
if(diodes.some(c=>{const edge=edges.find(e=>e.c.id===c.id),a=edge.a,b=edge.b;return onDiode(c)?branches[c.id]<-1e-10:pressure[a]-pressure[b]>c.value+1e-7;}))continue;
solution={pressure,branches};diodeMask=mask;break;}catch(e){lastError=e;}}
if(!solution)throw lastError||Error('No consistent diode state: check topology and values.');const {pressure,branches}=solution,currents={},volumes={},portI={},portQ={};
for(const e of edges){const voltage=pressure[e.a]-pressure[e.b];let i=['resistor','load'].includes(e.c.type)?voltage/e.c.value:e.c.type==='memristor'?voltage/MR.resistance(trialX[e.c.id],MR.parameters(e.c)):e.c.type==='capacitor'?e.c.value*1e-6*(voltage-oldVolt[e.c.id])/h:branches[e.c.id]||0;
if(!Number.isFinite(voltage)||!Number.isFinite(i))throw Error('Numerical failure: check connections and values.');if(e.c.type==='capacitor'&&e.c.capMode==='dc'&&voltage<-.00001)throw Error(e.c.id+' has reverse voltage. This compact DC capacitor requires positive polarity.');currents[e.c.id]=i;volumes[e.c.id]=e.c.type==='capacitor'?e.c.value*1e-6*voltage:oldQ[e.c.id]+(integrate?i*h:0);portI[e.owner+'.'+e.ps[0]]=(portI[e.owner+'.'+e.ps[0]]||0)-i;portI[e.owner+'.'+e.ps[1]]=(portI[e.owner+'.'+e.ps[1]]||0)+i;portQ[e.owner+'.'+e.ps[0]]=(portQ[e.owner+'.'+e.ps[0]]||0)-volumes[e.c.id];portQ[e.owner+'.'+e.ps[1]]=(portQ[e.owner+'.'+e.ps[1]]||0)+volumes[e.c.id];}
for(const c of switches.filter(c=>c.bodyDiode)){currents[c.id+'.total']=currents[c.id]-currents[c.id+'.diode'];volumes[c.id+'.total']=volumes[c.id]-volumes[c.id+'.diode'];}
const magnetics={};for(const c of coupled){const windings=edges.filter(e=>e.c.owner===c.id),i=windings.map(e=>currents[e.c.id]),powers=windings.map((e,j)=>(pressure[e.a]-pressure[e.b])*i[j]);let energy=0;windings.forEach((a,j)=>windings.forEach((b,k)=>energy+=.5*inductance(a.c,b.c)*i[j]*i[k]));magnetics[c.id]={energy:Math.max(0,energy),fluxCharge:windings.reduce((sum,e)=>sum+e.c.ratio*volumes[e.c.id],0),powers,currents:i,fluxCurrent:windings.reduce((sum,e,j)=>sum+e.c.ratio*i[j],0)};currents[c.id]=i[0];volumes[c.id]=volumes[windings[0].c.id];}
const memristorsState=Object.fromEntries(memEdges.map(e=>[e.c.id,MR.sample(e.c,trialX[e.c.id],currents[e.c.id],pressure[e.a]-pressure[e.b])]));
return {t,magnetics,memristors:memristorsState,on:Object.values(switchStates).some(Boolean),switchStates,state:{pressure,currents,volumes,portI,portQ}};}
// Solve the end-state conductance and MNA together; retry smaller steps when
// the nonlinear iteration or state resolution requires it. C/L remain BE.
function commit(result){for(const c of caps)oldVolt[c.id]=result.state.pressure[net[c.id+'.p']]-result.state.pressure[net[c.id+'.n']];for(const c of inductors)oldCurrent[c.id]=result.state.currents[c.id];oldQ={...result.state.volumes};for(const e of memEdges){oldX[e.c.id]=result.memristors[e.c.id].x;oldMemV[e.c.id]=result.state.pressure[e.a]-result.state.pressure[e.b];}}
let internalSteps=0;
function step(t,h,gateTime,integrate=true,depth=0){
 trialX={...oldX};if(!memristors.length||!integrate)return electrical(t,h,gateTime,integrate);
 let result,converged=false;
 for(let iteration=0;iteration<60;iteration++){
  result=electrical(t,h,gateTime,integrate);let error=0,travel=0;const next={};
  for(const e of memEdges){const id=e.c.id,v=result.state.pressure[e.a]-result.state.pressure[e.b];next[id]=MR.advance(oldX[id],oldMemV[id],trialX[id],v,h,MR.parameters(e.c));error=Math.max(error,Math.abs(next[id]-trialX[id]));travel=Math.max(travel,Math.abs(next[id]-oldX[id]));}
  if(travel>.025)break;
  if(error<1e-10){trialX=next;result=electrical(t,h,gateTime,integrate);converged=true;break;}
  for(const c of memristors)trialX[c.id]=(trialX[c.id]+next[c.id])/2;
 }
 if(converged){internalSteps++;return result;}
 if(depth>=16)throw Error('Memristor state solve did not converge. Increase steps, increase QD or shorten the run.');
 const saved={oldVolt:{...oldVolt},oldCurrent:{...oldCurrent},oldQ:{...oldQ},oldX:{...oldX},oldMemV:{...oldMemV},diodeMask};
 const half=h/2;try{const middle=step(t-half,half,t-h*.75,true,depth+1);commit(middle);return step(t,half,t-h*.25,true,depth+1);}finally{({oldVolt,oldCurrent,oldQ,oldX,oldMemV,diodeMask}=saved);}
}
const samples=[];let initial=step(0,1e-10,0,false);for(const c of caps){const ps=D.types[c.type].ports,v=initial.state.pressure[net[c.id+'.p']]-initial.state.pressure[net[c.id+'.n']];if(Math.abs(v)>.001)throw Error('An ideal source or closed switch forces an instantaneous voltage jump on '+c.id+'. Add series resistance.');}for(const c of caps)oldVolt[c.id]=initial.state.pressure[net[c.id+'.p']]-initial.state.pressure[net[c.id+'.n']];for(const c of inductors)oldCurrent[c.id]=initial.state.currents[c.id];commit(initial);samples.push(initial);
for(let j=1;j<times.length;j++){const t=times[j],h=t-times[j-1];if(h<1e-14)continue;const result=step(t,h,t-h*.5);for(const c of caps)oldVolt[c.id]=result.state.pressure[net[c.id+'.p']]-result.state.pressure[net[c.id+'.n']];for(const c of inductors)oldCurrent[c.id]=result.state.currents[c.id];commit(result);samples.push(result);if(boundaries.includes(t)&&t<duration){const event=step(t,1e-10,t,false);for(const c of caps){const voltage=event.state.pressure[net[c.id+'.p']]-event.state.pressure[net[c.id+'.n']];if(Math.abs(voltage-oldVolt[c.id])>1e-4*Math.max(1,sources[0].value))throw Error('Switching forces a voltage jump on '+c.id+'. Add resistance to the charging path.');}for(const c of inductors)if(Math.abs(inductors.reduce((sum,k)=>sum+inductance(c,k)*(event.state.currents[k.id]-oldCurrent[k.id]),0))>1e-4*c.value*1e-3*Math.max(1,Math.abs(oldCurrent[c.id])))throw Error('Switching interrupts '+c.id+' current. Add a freewheel diode or another current path.');for(const c of inductors)oldCurrent[c.id]=event.state.currents[c.id];for(const e of memEdges)oldMemV[e.c.id]=event.state.pressure[e.a]-event.state.pressure[e.b];samples.push(event);}}
function at(t){t=Math.max(0,Math.min(duration,t));let lo=0,hi=samples.length-1;while(lo<hi){const mid=Math.ceil((lo+hi)/2);if(samples[mid].t<=t)lo=mid;else hi=mid-1;}const a=samples[lo],b=samples[Math.min(lo+1,samples.length-1)],u=b.t>a.t?(t-a.t)/(b.t-a.t):0,state={};for(const field of ['pressure','currents','volumes','portI','portQ']){state[field]={};for(const key of Object.keys(a.state[field]))state[field][key]=a.state[field][key]+u*(b.state[field][key]-a.state[field][key]);}const magnetics={};for(const id of Object.keys(a.magnetics||{})){const aa=a.magnetics[id],bb=b.magnetics[id];magnetics[id]={fluxCharge:aa.fluxCharge+u*(bb.fluxCharge-aa.fluxCharge),energy:aa.energy+u*(bb.energy-aa.energy),fluxCurrent:aa.fluxCurrent+u*(bb.fluxCurrent-aa.fluxCurrent),powers:aa.powers.map((v,j)=>v+u*(bb.powers[j]-v)),currents:aa.currents.map((v,j)=>v+u*(bb.currents[j]-v))};}const memristorsState=MR.interpolate(a.memristors,b.memristors,u,state,net,memristors);return {t,on:a.on,switchStates:a.switchStates,state,magnetics,memristors:memristorsState};}
return {kind:'network',p:{Vs:sources[0].value,loadOn:doc.settings.loadOn},net,ground,references,supply,source:sources[0],supplyAt:t=>sources[0].waveform==='sine'?(sources[0].offset||0)+sources[0].value*Math.sin(2*Math.PI*(sources[0].frequency||50)*t):sources[0].value,capacitor:caps[0],duration,dt,samples,at};
}
const api={create};if(typeof module!=='undefined')module.exports=api;else g.EditorRCModel=api;
})(globalThis);
