/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (C) 2026 Lucas Wybrandt — copyrightable contributions.
 * Inertance; see LICENSE and SOFTWARE-NOTICE.md. No warranty.
 */
/* HP/Strukov two-region educational model (2008, corrected 2009), normalized
 * x=w/D; QD=D²/(mobility*Ron), in coulombs. Biolek (2009) optional window.
 * Component value is Roff in ohms. No threshold, leakage or stored energy.
 * Extracted from Claude's reviewed demo; network integration lives in RCModel. */
(function(g){
const clamp=x=>Math.max(0,Math.min(1,x));
const parameters=c=>({Ron:c.Ron??100,Roff:c.value,QD:c.QD??.001,x0:c.x0??.1,window:c.window??'hard',p:c.p??4});
const resistance=(x,p)=>p.Ron*x+p.Roff*(1-x);
function windowF(x,i,p){if(p.window==='biolek')return 1-Math.pow(x-(i<=0?1:0),2*p.p);return i>0&&x>=1||i<0&&x<=0?0:1;}
const G=(x,p)=>p.Roff*x-(p.Roff-p.Ron)*x*x/2;
// Rationalized inverse avoids cancellation for small x and Ron=Roff.
function Ginv(u,p){return clamp(2*u/(p.Roff+Math.sqrt(Math.max(0,p.Roff*p.Roff-2*(p.Roff-p.Ron)*u))));}
function advance(x0,v0,x1,v1,h,p){
 if(p.window==='hard')return Ginv(Math.max(0,Math.min(G(1,p),G(x0,p)+h*(v0+v1)/(2*p.QD))),p);
 const i0=v0/resistance(x0,p),i1=v1/resistance(x1,p);
 return clamp(x0+h*(i0*windowF(x0,i0,p)+i1*windowF(x1,i1,p))/(2*p.QD));
}
function sample(c,x,i,v){const p=parameters(c),M=resistance(x,p);return {x,resistance:M,window:windowF(x,i,p),power:v*i};}
// Interpolate solved network fields, then derive M/F/power from that same state.
function interpolate(a,b,u,state,net,components){const out={};for(const c of components){const x=a[c.id].x+u*(b[c.id].x-a[c.id].x),v=state.pressure[net[c.id+'.a']]-state.pressure[net[c.id+'.b']];out[c.id]=sample(c,x,state.currents[c.id],v);}return out;}
const api={clamp,parameters,resistance,windowF,G,Ginv,advance,sample,interpolate};if(typeof module!=='undefined')module.exports=api;else g.EditorMemristorModel=api;
})(globalThis);
