# Inertance preferred release source

This archive is a bounded corresponding-source export, without Git history,
private planning, downloaded course material, credentials or browser records.
Keep `cwas/` beside `inertance-site/`; paths are portable. Requires Python 3.9+
and a modern web browser. No installed Codex tools or private checkout is needed. The optional local
visualization harness is excluded: neither production page uses it.
From the archive root run:

    python3 cwas/simulator/build-editor.py
    python3 cwas/simulator/build-lab.py
    python3 inertance-site/build_app.py
    python3 inertance-site/build.py
    python3 -m http.server 8000 --directory inertance-site

Open http://localhost:8000/app/ or /lab/ directly. The root redirect
points to the production HTTPS site; open /app/ directly for local preview. Builders use Python's
standard library. d3 is pinned locally with full notices; the old lab requests
Google Fonts online. Optional feedback/analytics services are separate and need
no private credentials; local preview analytics is disabled. Do not send test
feedback to the configured production inbox; intercept such requests.

`release-input.json` freezes the simulator stamp/date outside Git. In a Git
checkout the current builder reads the real simulator revision instead. The
manifest records both simulator and website-input revisions, exported source
hashes, build adaptations and reproduction checks. A website input commit
precedes the packaging/deployment commit; the archive does not claim to contain
its own future deployment commit. The final release record identifies that
commit separately. No circular self-hash is claimed.

Software is AGPL-3.0-or-later; see cwas/LICENSE and SOFTWARE-NOTICE.md.
Third-party code retains its own notices in inertance-site/assets/vendor/.
The later release's specifically named teaching guide has the additional
CC BY-SA grant in CONTENT-LICENSE.md. Existing grants remain in place.
