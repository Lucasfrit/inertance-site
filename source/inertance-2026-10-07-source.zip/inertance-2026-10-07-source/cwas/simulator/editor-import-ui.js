/* Shared experimental import flow for both shells. State changes go through API. */
(function(g){
async function prepare(text,options){
 const result=g.CircuitImport.convert(text,options);if(!result.ok)return result;
 try{
  g.EditorModes.create(result.document); // same physics and initialization as Run
  const search=g.CircuitLayout.optimize(g.CircuitDocument.arrange(result.document),{budget:80});let step;
  do{const start=performance.now();do{step=search.next();}while(!step.done&&performance.now()-start<18);if(!step.done)await new Promise(resolve=>setTimeout(resolve,0));}while(!step.done);
  result.document=g.CircuitDocument.validate(step.value.document);result.layout=step.value.after;
  if(result.layout.failed||result.layout.overlaps||result.layout.overlaid)result.diagnostics.push({severity:'warning',code:'LAYOUT',message:'Some pipes or spacing need manual review. Electrical connectivity is preserved; dashed pipes indicate routing failures.'});
 }catch(e){result.ok=false;result.document=null;result.diagnostics.push({severity:'error',code:'SOLVER',message:'CWAS cannot run this circuit: '+e.message+' No current circuit was changed.'});}
 return result;
}
function install(root){
 const get=id=>root.querySelector('#'+id),dialog=get('ed-external-dialog'),input=get('ed-external-text'),format=get('ed-external-format'),preview=get('ed-external-preview'),apply=get('ed-external-apply'),file=get('ed-external-file'),output=get('ed-external-report');let candidate=null,revision=0;
 const outcome=(format,stage)=>root.dispatchEvent(new CustomEvent('circuit-editor:action',{detail:{name:'import_'+(['spice','kicad'].includes(format)?format:'unknown')+'_'+stage}}));
 const invalidate=()=>{revision++;candidate=null;apply.disabled=true;output.textContent='Preview the netlist to validate connectivity, physics and layout. Your current circuit stays in place until Apply.';};
 get('ed-external-open').onclick=()=>{invalidate();dialog.showModal();input.focus();};get('ed-external-close').onclick=()=>dialog.close();dialog.addEventListener('close',invalidate);input.addEventListener('input',invalidate);format.addEventListener('change',invalidate);
 get('ed-external-browse').onclick=()=>file.click();file.onchange=async()=>{const selected=file.files[0];if(!selected)return;invalidate();const token=revision;try{if(selected.size>1e6)throw Error('Choose a UTF-8 netlist smaller than 1 MB.');const content=new TextDecoder('utf-8',{fatal:true}).decode(await selected.arrayBuffer());if(token!==revision)return;input.value=content;output.textContent='Read '+selected.name+'. Preview to check the import.';}catch(e){if(token===revision)output.textContent='Could not read file: '+e.message;}finally{file.value='';}};
 preview.onclick=async()=>{
  invalidate();const token=revision;preview.disabled=true;output.textContent='Checking connectivity, running the CWAS solver and arranging…';
  try{const result=await g.circuitEditor.previewImport(input.value,{format:format.value});if(token!==revision)return;candidate=result.ok?result:null;apply.disabled=!candidate;outcome(result.format,result.ok?'preview_success':'preview_failed');
   const s=result.summary;output.textContent=(result.ok?'Ready for review: '+s.parts+' electrical parts → '+s.components+' editable components, '+s.nets+' nets; ground '+s.ground+'.\n':'Import blocked. Your current circuit is unchanged.\n')+result.diagnostics.map(d=>d.severity.toUpperCase()+' '+d.code+(d.line?' · line '+d.line:'')+': '+d.message).join('\n');output.scrollIntoView({block:'nearest'});
  }catch(e){if(token===revision){outcome(format.value,'preview_failed');output.textContent='Import blocked: '+e.message;}}finally{preview.disabled=false;}
 };
 apply.onclick=()=>{if(!candidate)return;try{g.circuitEditor.importDocument(candidate.document);outcome(candidate.format,'applied');dialog.close();}catch(e){outcome(candidate.format,'apply_failed');candidate=null;apply.disabled=true;output.textContent='Import blocked. Current circuit unchanged: '+e.message;}};
}
g.CircuitImportUI={prepare,install};
})(globalThis);
