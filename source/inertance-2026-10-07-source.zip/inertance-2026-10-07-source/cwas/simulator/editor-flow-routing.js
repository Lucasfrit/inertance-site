/* One particle stream per physical pipe, not per overlapping netlist wire.
   Flow is driven by solver port currents/charges. Geometric loops use a
   minimum-energy display split; ideal wire loop currents are not measurable. */
(function(g){
const D=typeof module!=='undefined'?require('./editor-document'):g.CircuitDocument;
function create(doc,routes){
 const nets=D.nets(doc),segments=[],nodes=new Map(),edges=new Map();
 const key=(net,p)=>net+'|'+p.x.toFixed(5)+','+p.y.toFixed(5);
 const node=(net,p)=>{const id=key(net,p);if(!nodes.has(id))nodes.set(id,{id,net,x:p.x,y:p.y,ports:[],edges:[]});return nodes.get(id);};
 for(const r of routes){const net=nets[D.key(r.wire.from)];for(const p of r.points)node(net,p);for(let j=1;j<r.points.length;j++)segments.push({a:r.points[j-1],b:r.points[j],net});}
 for(const a of segments)for(const b of segments){if(a.net!==b.net||a.a.y!==a.b.y||b.a.x!==b.b.x)continue;const p={x:b.a.x,y:a.a.y};if(p.x>=Math.min(a.a.x,a.b.x)&&p.x<=Math.max(a.a.x,a.b.x)&&p.y>=Math.min(b.a.y,b.b.y)&&p.y<=Math.max(b.a.y,b.b.y))node(a.net,p);}
 for(const c of doc.components)if(c.type!=='junction')for(const port of Object.keys(D.types[c.type].ports)){const id=c.id+'.'+port,n=nodes.get(key(nets[id],D.port(c,port)));if(n)n.ports.push(id);}
 for(const s of segments){const h=s.a.y===s.b.y,axis=h?'x':'y',cross=h?'y':'x';const points=[...nodes.values()].filter(p=>p.net===s.net&&Math.abs(p[cross]-s.a[cross])<1e-5&&p[axis]>=Math.min(s.a[axis],s.b[axis])-1e-5&&p[axis]<=Math.max(s.a[axis],s.b[axis])+1e-5).sort((a,b)=>a[axis]-b[axis]);
  for(let j=1;j<points.length;j++){const a=points[j-1],b=points[j],id=a.id+'>'+b.id;if(edges.has(id))continue;const e={id,a,b,net:s.net,length:Math.hypot(b.x-a.x,b.y-a.y),weights:{}};if(e.length<1e-5)continue;edges.set(id,e);a.edges.push(e);b.edges.push(e);}
 }
 const groups=new Map();for(const n of nodes.values()){if(!groups.has(n.net))groups.set(n.net,[]);groups.get(n.net).push(n);}
 for(const ns of groups.values()){
  const es=[...edges.values()].filter(e=>e.net===ns[0].net);
  if(es.length===ns.length-1){
   for(const e of es){const seen=new Set([e.a]),queue=[e.a];while(queue.length){const n=queue.pop();for(const link of n.edges){if(link===e)continue;const other=link.a===n?link.b:link.a;if(!seen.has(other)){seen.add(other);queue.push(other);}}}for(const n of seen)for(const port of n.ports)e.weights[port]=1;}
  }else{
   // Unit injections at every terminal, balanced at the reference node.
   // Precompute the linear map once; animation performs only dot products.
   const size=ns.length-1,index=new Map(ns.map((n,j)=>[n,j])),matrix=Array.from({length:size},()=>Array(size).fill(0));
   for(const e of es){const a=index.get(e.a),b=index.get(e.b),k=1/e.length;if(a<size)matrix[a][a]+=k;if(b<size)matrix[b][b]+=k;if(a<size&&b<size){matrix[a][b]-=k;matrix[b][a]-=k;}}
   const inverse=matrix.map((row,j)=>[...row,...Array.from({length:size},(_,k)=>+(j===k))]);
   for(let j=0;j<size;j++){let pivot=j;for(let k=j+1;k<size;k++)if(Math.abs(inverse[k][j])>Math.abs(inverse[pivot][j]))pivot=k;[inverse[j],inverse[pivot]]=[inverse[pivot],inverse[j]];const value=inverse[j][j];if(Math.abs(value)<1e-12)continue;for(let k=0;k<size*2;k++)inverse[j][k]/=value;for(let k=0;k<size;k++)if(k!==j){const factor=inverse[k][j];for(let m=0;m<size*2;m++)inverse[k][m]-=factor*inverse[j][m];}}
   for(const n of ns)for(const port of n.ports){const j=index.get(n);for(const e of es){const a=index.get(e.a),b=index.get(e.b);e.weights[port]=j===size?0:((a<size?inverse[a][size+j]:0)-(b<size?inverse[b][size+j]:0))/e.length;}}
  }
 }
 // Preserve rounded elbows: join degree-two, injection-free nodes into chains.
 const used=new Set(),streams=[];
 const walk=(first,start)=>{let e=first,n=start;const points=[n],weights=Object.fromEntries(Object.entries(e.weights).map(([k,v])=>[k,v*(e.a===n?1:-1)]));while(!used.has(e)){used.add(e);n=e.a===n?e.b:e.a;points.push(n);if(n.ports.length||n.edges.length!==2)break;e=n.edges.find(link=>!used.has(link));if(!e)break;}streams.push({net:first.net,points:points.map(n=>({x:n.x,y:n.y})),weights});};
 for(const n of nodes.values())if(n.ports.length||n.edges.length!==2)for(const e of n.edges)if(!used.has(e))walk(e,n);
 for(const e of edges.values())if(!used.has(e))walk(e,e.a);
 return streams;
}
const api={create};if(typeof module!=='undefined')module.exports=api;else g.EditorFlowRouting=api;
})(globalThis);
