/* Curated example drawings. Geometry only; never an input to generic Auto-arrange.
 * Course sources and review evidence: docs/DEFAULT-LAYOUTS.md. */
(function(g){
const node=typeof module!=='undefined',D=node?require('./editor-document.js'):g.CircuitDocument;
const geometry=['x','y','rotation','windingSides','windingFlips','windingFlowSigns'];
const extras={buffer:'Capacitor buffer',freewheel:'Inductor + diode',meters:'Load + meters'};
function apply(input,key){
 const doc=D.clone(input),byId=Object.fromEntries(doc.components.map(c=>[c.id,c]));
 const place=(id,x,y,rotation=0,extra={})=>{if(!byId[id])throw Error('Missing example part '+id);Object.assign(byId[id],{x,y,rotation},extra);};
 const net=D.nets(doc),rails=new Map();
 // Junctions are found by terminal identity, independent of generated J numbering.
 const rail=(terminal,x,y)=>{const n=net[terminal],j=doc.components.find(c=>c.type==='junction'&&net[c.id+'.j']===n);if(!j)throw Error('Missing example junction '+terminal);place(j.id,x,y);rails.set(n,y);};
 const guide=(terminal,points)=>{const w=doc.wires.find(w=>D.key(w.from)===terminal||D.key(w.to)===terminal);if(!w)throw Error('Missing example pipe '+terminal);w.waypoints=(D.key(w.from)===terminal?points:[...points].reverse()).map(([x,y])=>({x,y}));};
 if(key==='buffer'){
  place('V1',100,260);place('R1',240,100);place('C1',390,260);place('Q1',620,210);place('R2',620,330,90);rail('C1.p',390,100);rail('C1.n',390,430);
 }else if(key==='freewheel'){
  place('V1',100,270);place('Q1',260,100,270);place('D1',390,280,180);place('L1',530,180);place('R1',720,280,90);rail('L1.a',390,100);rail('V1.n',390,460);
 }else if(key==='meters'){
  place('V1',100,300);place('In1',220,120);place('FM1',370,85);place('Load1',710,240);place('PM1',480,360);place('Out1',320,500,180);rail('Load1.a',540,120);rail('Load1.b',830,500);
  guide('Load1.a',[[620,120]]);guide('Load1.b',[[830,280],[830,500]]);guide('PM1.a',[[400,400],[400,180],[540,180]]);guide('PM1.b',[[570,400],[570,500]]);
 }else{
  const bridge=['half','fullbuck','fullboost'].includes(key),isolated=bridge||['flyback','forward','transformer'].includes(key);
  place('V1',100,300);place('Rin',190,120);place('Ci',300,300);
  if(!isolated){
   let out=820;
   if(key==='buck'){place('Q1',430,120,270);place('D1',550,300,180);place('L1',680,200);rail('Q1.b',550,120);}
   if(key==='boost'){place('L1',430,200);place('Q1',570,300);place('D1',690,120,270);rail('Q1.a',570,120);}
   if(key==='inverting'){place('Q1',430,120,270);place('L1',510,300,90);place('D1',690,120,90);rail('Q1.b',550,120);guide('L1.a',[[610,280],[610,120]]);guide('L1.b',[[610,320],[610,480]]);}
   if(key==='noninverting'){out=1050;place('Q1',430,120,270);place('D1',550,300,180);place('L1',680,200);place('Q2',810,300);place('D2',930,120,270);rail('Q1.b',550,120);rail('Q2.a',810,120);}
   place('Co',out,300,key==='inverting'?180:0);place('Rload',out+160,300,90);rail('Ci.p',300,120);rail('V1.n',300,480);rail('Rload.a',out,120);
  }else if(key==='flyback'||key==='transformer'){
   place('T1',580,270,0,{windingSides:[270,90],windingFlips:[true,key==='flyback']});
   if(key==='flyback'){place('Q1',464,420);place('Dout',790,120,270);place('Co',910,270);place('Rload',1070,270,90);rail('Co.p',910,120);rail('Co.n',720,420);rail('V1.n',300,520);rail('Ci.p',300,120);guide('T1.n1',[[464,330]]);guide('T1.n2',[[720,255],[720,120]]);guide('T1.p2',[[720,285],[720,420]]);}
   else{place('Rload',860,270,90);rail('Ci.p',300,120);rail('Ci.n',300,440);guide('T1.n1',[[464,285],[464,440]]);guide('T1.p2',[[720,255],[720,120],[860,120]]);guide('T1.n2',[[720,285],[720,440],[860,440]]);}
  }else if(key==='forward'){
   // A vertical gear stack gives each winding a clear external pipe corridor.
   // Winding 2 resets above winding 1; winding 3 feeds the isolated output.
   place('T1',650,330,0,{windingSides:[270,270,90],windingFlips:[true,false,false]});
   place('Q1',530,440);place('Dreset',450,130,90);place('Dout',850,360,270);place('Dfree',960,460,180);place('Lout',1080,440);place('Co',1210,460);place('Rload',1370,460,90);
   rail('Ci.p',300,120);rail('V1.n',300,580);rail('Co.n',960,580);rail('Dfree.b',960,360);rail('Co.p',1210,360);
   guide('T1.p1',[[400,315],[400,120]]);guide('T1.n1',[[530,345],[530,390]]);guide('T1.p2',[[470,217],[470,580]]);guide('T1.n2',[[540,187],[540,130]]);guide('Dreset.b',[[400,130],[400,120]]);guide('T1.p3',[[770,443],[770,360]]);guide('T1.n3',[[770,473],[770,580]]);
  }else if(bridge){
   const shift=key==='fullboost'?130:0,left=key==='half'?560:440+shift,right=580+shift,tx=800+shift;
   place('Q1',left,220);place('Q2',left,460);
   if(key==='half'){place('Ctop',420,220);place('Cbottom',420,460);rail('Ctop.n',420,370);}
   else{place('Q3',right,220);place('Q4',right,460);rail('Q3.b',right,370);}
   place('T1',tx,330,0,{windingSides:[270,90,90],windingFlips:[true,false,false]});
   const topPort=D.port(byId.T1,'p2'),bottomPort=D.port(byId.T1,'n3');place('Dr1',tx+200,topPort.y,270);place('Dr2',tx+200,bottomPort.y,270);
   const ox=tx+(key==='fullboost'?370:480);
   if(key!=='fullboost'){place('Lout',tx+350,200);rail('Lout.a',tx+260,120);}
   else{place('Lin',430,200);rail('Q1.a',left,120);}
   place('Co',ox,225);place('Rload',ox+150,225,90);
   rail('Ci.p',300,120);rail('V1.n',300,560);rail('Q1.b',left,315);rail('Co.n',tx+120,330);rail('Co.p',ox,120);
   guide('T1.p1',[[tx-68,315],[left,315]]);guide('T1.n1',[[tx-68,370],[right,370]]);
   guide('T1.n2',[[tx+120,topPort.y+30],[tx+120,330]]);guide('T1.p3',[[tx+120,bottomPort.y-30],[tx+120,330]]);
   guide('Dr2.b',[[tx+260,bottomPort.y],[tx+260,120]]);guide('Dr1.b',[[tx+260,topPort.y],[tx+260,120]]);
  }
 }
 // Straight rail guides keep the supply/return hierarchy readable. They are
 // normal editable wire waypoints, carried by JSON and history like user bends.
 for(const w of doc.wires){if(w.waypoints)continue;const n=net[D.key(w.from)],y=rails.get(n);if(y===undefined)continue;const points=[];for(const end of [w.from,w.to]){const c=byId[end.component],p=D.port(c,end.port);if(c.type!=='junction'&&p.y!==y)points.push({x:p.x+p.nx*40,y});}w.waypoints=points;}
 return D.validate(doc);
}
function sources(){const P=node?require('./editor-presets.js'):g.EditorPresets,H=node?require('./editor-hydraulics.js'):g.EditorHydraulics;return {P,H};}
function create(key){const {P,H}=sources();return extras[key]?apply(key==='buffer'?D.preset():key==='freewheel'?D.freewheel():H.review(),key):P.create(key);}
function wireKey(w){return [D.key(w.from),D.key(w.to)].sort().join('|');}
function signature(doc){return JSON.stringify([doc.components.map(c=>[c.id,c.type]).sort(),doc.wires.map(wireKey).sort()]);}
let templates,keysBySignature;
function defaults(){if(!templates){const {P}=sources();templates=Object.fromEntries([...Object.keys(P.names),...Object.keys(extras)].map(k=>[k,create(k)]));keysBySignature=new Map(Object.entries(templates).map(([k,d])=>[signature(d),k]));}return templates;}
function availability(doc){defaults();const key=keysBySignature.get(signature(doc));return key?{enabled:true,key,label:extras[key]||sources().P.names[key],reason:'Restore example positions, orientation and pipe bends; keep electrical values and simulation settings.'}:{enabled:false,reason:'Default example view is available only while the parts and connections match an example. Your circuit edits are preserved.'};}
function restore(doc){const state=availability(doc);if(!state.enabled)throw Error(state.reason);const template=defaults()[state.key],out=D.clone(doc),parts=Object.fromEntries(template.components.map(c=>[c.id,c])),wires=new Map(template.wires.map(w=>[wireKey(w),w]));
 for(const c of out.components)for(const key of geometry){if(parts[c.id][key]===undefined)delete c[key];else c[key]=D.clone(parts[c.id][key]);}
 for(const w of out.wires){const original=wires.get(wireKey(w));if(original.waypoints){w.waypoints=D.clone(original.waypoints);if(D.key(w.from)!==D.key(original.from))w.waypoints.reverse();}else delete w.waypoints;}
 return D.validate(out);
}
const api={apply,create,availability,restore,signature};if(node)module.exports=api;else g.EditorExampleLayouts=api;
})(globalThis);
