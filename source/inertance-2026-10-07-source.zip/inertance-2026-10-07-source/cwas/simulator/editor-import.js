/* Conversion into the existing version-1 document; no separate solver/model. */
(function(g){
const node=typeof module!=='undefined',D=node?require('./editor-document.js'):g.CircuitDocument,S=node?require('./editor-import-spice.js'):g.CircuitImportSpice,K=node?require('./editor-import-kicad.js'):g.CircuitImportKiCad;
const assumptions='Experimental educational RLC import. Ideal wires and linear components; capacitors start uncharged, inductors at zero current. CWAS uses backward Euler, not SPICE device physics or trace replay. Arbitrary circuits use network dynamics; automatic Leakage protection is unavailable.';
function convert(text,{format='auto'}={}){
 const diagnostics=[],report=(severity,code,message,line,ref)=>diagnostics.push({severity,code,message,...(line?{line}:{}),...(ref?{ref}:{})});let document=null,summary=null;
 try{
  if(typeof text!=='string'||!text.trim())throw Error('Paste a netlist or choose a UTF-8 text file.');if(text.length>1e6)throw Error('Choose a netlist smaller than 1 MB.');if(text.includes('\0'))throw Error('Binary/UTF-16 input is unsupported. Save as UTF-8 text.');text=text.replace(/^\uFEFF/,'');
  if(/^\s*\(kicad_sch\b/.test(text)||/^Version\s+\d+\s*\nSHEET/im.test(text))throw Error('Direct .kicad_sch and .asc schematics are unsupported. Export KiCad native netlist or LTspice View → SPICE Netlist first.');
  if(format==='auto')format=/^\s*\(export\b/.test(text)?'kicad':'spice';if(!['spice','kicad'].includes(format))throw Error('Choose LTspice/SPICE or KiCad native netlist.');
  const parsed=(format==='spice'?S:K).parse(text,report),{parts,couplings}=parsed;
  if(diagnostics.some(d=>d.severity==='error'))return {ok:false,document:null,format,diagnostics};
  if(!parts.length||parts.length>24)throw Error('Import supports 1–24 electrical parts (each winding counts as a part). Split larger circuits deliberately.');
  const refs=new Map(),used=new Set(),ids=new Map();
  for(const p of [...parts,...couplings]){if(!p.ref||p.ref.length>160||p.nodes?.some(n=>!n||n.length>160))throw Error('References and net names must be 1–160 characters.');const key=p.ref.toLowerCase();if(refs.has(key))throw Error('Duplicate reference '+p.ref+'.');refs.set(key,p);let id=p.ref.replace(/[^A-Za-z0-9_-]/g,'_').slice(0,30);if(!/^[A-Za-z]/.test(id))id='Part_'+id;const base=id;let j=1;while(used.has(id))id=base+'_'+j++;used.add(id);ids.set(key,id);if(id!==p.ref)report('info','REFERENCE','Reference '+p.ref+' uses editable ID '+id+'; the original label is retained.');}
  const components=[],terminals=new Map(),referenceMap=[],consumed=new Set(),netNames=new Map();
  const addTerminal=(net,end)=>{if(!net||/\s/.test(net))throw Error('Invalid/missing net on '+end.component+'.');if(!terminals.has(net))terminals.set(net,[]);terminals.get(net).push(end);};
  const base=(ref,type,value)=>({id:ids.get(ref.toLowerCase()),sourceRef:ref,label:ref,type,value,x:100+components.length%4*240,y:160+Math.floor(components.length/4)*260,rotation:0});
  for(const group of couplings){
   const windings=group.refs.map(ref=>refs.get(ref.toLowerCase()));if(new Set(group.refs.map(r=>r.toLowerCase())).size!==group.refs.length||windings.some(p=>!p||p.kind!=='L'||consumed.has(p.ref.toLowerCase())))throw Error(group.ref+': each winding must name a distinct existing inductor in only one group. Overlapping/pairwise coupling matrices are unsupported.');
   const c=base(group.ref,({2:'coupled',3:'coupled3',4:'coupled4'})[windings.length],windings[0].value*1e3);c.turns=windings.map(p=>Math.sqrt(p.value/windings[0].value));c.coupling=group.k;c.label=group.ref+' ['+windings.map(p=>p.ref).join(', ')+']';c.sourceWindings=windings.map(p=>p.ref);components.push(c);
   windings.forEach((p,j)=>{consumed.add(p.ref.toLowerCase());for(const [i,port]of [['0','p'+(j+1)],['1','n'+(j+1)]])addTerminal(p.nodes[i],{component:c.id,port});referenceMap.push({reference:p.ref,component:c.id,winding:j+1});});
   report('info','COUPLING',group.ref+': first node of each L is the dotted p terminal; turns ratios √(Lj/L1), uniform k='+group.k+'.');
  }
  for(const p of parts){
   for(const [net,name]of Object.entries(p.netNames||{}))if(!netNames.has(net))netNames.set(net,name);
   if(consumed.has(p.ref.toLowerCase()))continue;
   const type={R:'resistor',L:'inductor',C:'capacitor',V:'source'}[p.kind],factor={L:1e3,C:1e6}[p.kind]||1,c=base(p.ref,type,Math.abs(p.value)*factor),ports=Object.keys(D.types[type].ports);if(p.polarized)c.capMode='dc';components.push(c);referenceMap.push({reference:p.ref,component:c.id});
   if(p.kind==='V'&&p.value<0){ports.reverse();report('info','POLARITY',p.ref+': negative DC value represented by a positive supply with its terminals reversed.');}
   ports.forEach((port,i)=>addTerminal(p.nodes[i],{component:c.id,port}));
  }
  if(!components.some(c=>c.type==='source'))throw Error('This solver needs a constant voltage supply. KiCad: include Device:Battery/Battery_Cell with a literal voltage value.');
  if(!terminals.has(parsed.ground))throw Error('Missing explicit ground '+(format==='spice'?'0':'GND or 0')+'.');
  const wires=[];for(const [net,ends]of terminals){if(ends.length<2)throw Error('Net '+(netNames.get(net)||net)+' has only one terminal ('+D.key(ends[0])+'). Complete dangling connectivity before import.');for(const end of ends.slice(1))wires.push({id:'ImportWire'+(wires.length+1),from:ends[0],to:end,netLabel:netNames.get(net)||net});}
  const settings={loadOn:.01,tail:.015,travel:1.8,colorReference:'return',referencePort:terminals.get(parsed.ground)[0],model:{mode:'ripple',losses:'configured',view:'startup',steps:5000},...(parsed.duration?{duration:parsed.duration}:{}),import:{format,references:referenceMap,assumptions}};
  document=D.validate({schemaVersion:1,components,wires,settings});
  summary={format,parts:parts.length,components:components.length,nets:terminals.size,windings:couplings.reduce((n,c)=>n+c.refs.length,0),ground:netNames.get(parsed.ground)||parsed.ground,references:referenceMap};report('warning','PHYSICS',assumptions);
 }catch(e){report('error','IMPORT',e.message);document=null;}
 return {ok:!!document,document,format,diagnostics,summary};
}
const api={convert,assumptions};if(node)module.exports=api;else g.CircuitImport=api;
})(globalThis);
