/* Exact piecewise RC response. Source -> Rs -> (C || switched RL).
   Positive capacitor current charges C; switching preserves capacitor voltage. */
(function(g){
function create(options={}){
 const p={Vs:12,Rs:10,C:220e-6,Rload:10,loadOn:.01,pulse:.01,tail:.015,...options};
 if(!Object.values(p).every(v=>Number.isFinite(v)&&v>0))throw Error('All values must be positive.');
 const off=p.loadOn+p.pulse,duration=off+p.tail,phases=[];
 let v0=0,totalV=0,totalV2=0,Qs=0,Ql=0,heatSource=0,heatLoad=0;
 function local(ph,u){const e=Math.exp(-u/ph.tau),d=ph.v0-ph.eq,v=ph.eq+d*e,intV=ph.eq*u+d*ph.tau*(-Math.expm1(-u/ph.tau)),intV2=ph.eq**2*u+2*ph.eq*d*ph.tau*(-Math.expm1(-u/ph.tau))+d*d*ph.tau/2*(-Math.expm1(-2*u/ph.tau));return {v,intV,intV2};}
 for(const[start,end,on]of[[0,p.loadOn,false],[p.loadOn,off,true],[off,duration,false]]){
  const G=on?1/p.Rload:0,eq=p.Vs/(1+p.Rs*G),tau=p.C/(1/p.Rs+G),ph={start,end,on,G,eq,tau,v0,totalV,totalV2,Qs,Ql,heatSource,heatLoad};phases.push(ph);
  const s=local(ph,end-start),u=end-start;v0=s.v;totalV+=s.intV;totalV2+=s.intV2;Qs+=(p.Vs*u-s.intV)/p.Rs;Ql+=G*s.intV;heatSource+=(p.Vs*p.Vs*u-2*p.Vs*s.intV+s.intV2)/p.Rs;heatLoad+=G*s.intV2;
 }
 function at(t){t=Math.max(0,Math.min(duration,t));const ph=t<p.loadOn?phases[0]:t<off?phases[1]:phases[2],u=t-ph.start,s=local(ph,u),is=(p.Vs-s.v)/p.Rs,il=ph.G*s.v,ic=is-il,qs=ph.Qs+(p.Vs*u-s.intV)/p.Rs,ql=ph.Ql+ph.G*s.intV;
  return {t,v:s.v,is,il,ic,on:ph.on,phase:t<p.loadOn?'charge':t<off?'load':'recharge',noCap:ph.eq,Qs:qs,Ql:ql,Qc:p.C*s.v,EC:.5*p.C*s.v*s.v,source:p.Vs*qs,heatSource:ph.heatSource+(p.Vs*p.Vs*u-2*p.Vs*s.intV+s.intV2)/p.Rs,heatLoad:ph.heatLoad+ph.G*s.intV2,intV:ph.totalV+s.intV,tau:ph.tau,eq:ph.eq};
 }
 const times=Array.from({length:1601},(_,j)=>j*duration/1600);times.push(p.loadOn-1e-12,p.loadOn,off-1e-12,off);times.sort((a,b)=>a-b);const samples=times.map(at),statistics={},end=at(duration),integrals={v:end.intV,is:end.Qs,il:end.Ql,ic:end.Qc};
 for(const key of Object.keys(integrals)){const candidates=[at(0),at(p.loadOn-1e-12),at(p.loadOn),at(off-1e-12),at(off),end],min=candidates.reduce((a,b)=>a[key]<b[key]?a:b),max=candidates.reduce((a,b)=>a[key]>b[key]?a:b);statistics[key]={min:min[key],max:max[key],minTime:min.t,maxTime:max.t,integral:integrals[key],mean:integrals[key]/duration};}
 return {p,off,duration,phases,at,samples,statistics};
}
if(typeof module!=='undefined')module.exports={create};else g.CapacitorBufferModel={create};
})(globalThis);
