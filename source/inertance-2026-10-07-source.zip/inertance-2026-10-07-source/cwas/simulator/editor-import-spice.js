/* Bounded LTspice netlist grammar: R, L, C, constant V and K. */
(function(g){
const V=typeof module!=='undefined'?require('./editor-import-values.js'):g.CircuitImportValues;
function parse(text,report){
 const parts=[],couplings=[],records=[];let ended=false,duration;
 for(const [i,raw]of text.split(/\r?\n/).entries()){
  const s=raw.replace(/;.*$/,'').trim();if(!s||s.startsWith('*'))continue;
  if(s.startsWith('+')){if(!records.length||ended)report('error','SYNTAX','Continuation has no preceding statement.',i+1);else records.at(-1).text+=' '+s.slice(1).trim();}
  else records.push({text:s,line:i+1});
 }
 for(const r of records){
  const a=r.text.split(/\s+/),ref=a[0],kind=ref[0].toUpperCase(),number=s=>V.value(s,{spice:true});
  try{
   if(ended)throw Error('Content after .end is unsupported. Remove it or import one circuit at a time.');
   if(ref.startsWith('.')){
    switch(ref.toLowerCase()){
     case '.end':if(a.length!==1)throw Error('Invalid .end.');ended=true;break;
     case '.title':report('info','TITLE','Title: '+a.slice(1).join(' '),r.line);break;
     case '.backanno':if(a.length!==1)throw Error('Invalid .backanno.');break;
     case '.tran':{
      const times=a.at(-1).toLowerCase()==='uic'?a.slice(1,-1):a.slice(1);
      if(duration!==undefined||times.length<1||times.length>2)throw Error('Supported transient directive: .tran stop [UIC] or .tran step stop [UIC]. No start time or other options.');
      const nums=times.map(number);if(nums.some(v=>v<0)||nums.at(-1)<=0)throw Error('Transient times must be nonnegative with positive stop time.');
      duration=nums.at(-1);report('warning','TIMESTEP','Only .tran stop time is retained. CWAS uses its own backward-Euler timestep and zero-energy startup'+(a.at(-1).toLowerCase()==='uic'?' (UIC with default zero initial conditions)':' instead of SPICE operating-point initialization')+'; this is not SPICE trace replay.',r.line);break;
     }
     default:throw Error('Unsupported directive '+ref+'. Models, parameters, includes, analyses and initial conditions are not imported.');
    }continue;
   }
   if(kind==='K'){
    if(a.length<4||a.length>6)throw Error('Use Kref L1 L2 [L3 L4] k; one uniform coupling group of 2–4 windings.');
    const k=number(a.at(-1));if(k<=0||k>1)throw Error('Coupling must be greater than zero and at most 1.');couplings.push({ref,refs:a.slice(1,-1),k,line:r.line});continue;
   }
   if(!['R','L','C','V'].includes(kind))throw Error('Unsupported device '+ref+'. Export a circuit containing only R, L, C, constant V and supported K groups. No ideal substitutions are made.');
   const tokens=kind==='V'&&a[3]?.toUpperCase()==='DC'?[...a.slice(0,3),...a.slice(4)]:a;
   if(tokens.length!==4)throw Error('Expected '+ref+' node1 node2 literal'+(kind==='V'?' (or DC literal)':'')+'. Extra parameters, sources and model names are unsupported.');
   const val=number(tokens[3]);if(kind!=='V'&&val<=0)throw Error('R, L and C values must be positive; zero-ohm links are unsupported.');if(kind==='V'&&val===0)throw Error('Zero-volt sensing sources are unsupported.');
   parts.push({ref,kind,value:val,nodes:tokens.slice(1,3).map(n=>n.toLowerCase()),netNames:Object.fromEntries(tokens.slice(1,3).map(n=>[n.toLowerCase(),n])),line:r.line});
  }catch(e){report('error','SPICE',e.message,r.line,ref);}
 }
 return {parts,couplings,duration,ground:'0'};
}
const api={parse};if(typeof module!=='undefined')module.exports=api;else g.CircuitImportSpice=api;
})(globalThis);
