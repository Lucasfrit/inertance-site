/* SI-unit, topology-specific switched state model. No visual gains enter this solver. */
(function(g){
const names={buck:'Buck',boost:'Boost',inverting:'Buck–boost · inverting',noninverting:'Buck–boost · two switches',flyback:'Flyback',half:'Half bridge · buck type',fullbuck:'Full bridge · buck type',fullboost:'Full bridge · boost type'};
const defaults={vs:12,L:.0047,Ci:.0022,C1:.00022,C2:.00022,Co:.00022,R:12,f:2000,duty:.5,n:1,rs:0,losses:false,rq:.08,rL:.12,vd:.55,esr:.04};
function simulate(options={}){
 const p={...defaults,...options},type=p.type||'buck',bridge=['half','fullbuck','fullboost'].includes(type),sign=type==='inverting'?-1:1,N=options.steps||400,dt=1/p.f/N,edge=Math.round(p.duty*N),end=4/p.f;
 if(!names[type]||![p.vs,p.L,p.Ci,p.C1,p.C2,p.Co,p.R,p.f,p.n].every(x=>Number.isFinite(x)&&x>0)||p.duty<.1||p.duty>.85)throw Error('Values must be positive; duty must be 10–85%.');
 const stages=k=>({on:k%N<edge,pol:Math.floor(k/N)%2===0?1:-1});
 function coeff(st){const on=st.on;switch(type){case'buck':return[on?1:0,1];case'boost':return[1,on?0:1];case'inverting':case'noninverting':return[on?1:0,on?0:1];case'flyback':return[on?1:0,on?0:1/p.n];case'fullboost':return[1,on?0:1/p.n];default:return[on?p.n*(type==='half'?.5:1):0,1];}}
 function values(s,st){let [a,b]=coeff(st);const vi=p.rs?s[0]:p.vs,i=Math.max(0,s[1]),esr=p.losses?p.esr:0,rL=p.losses?p.rL:0,rq=p.losses?p.rq:0,vd=p.losses?p.vd:0;const out=(s[2]+esr*b*i)/(1+esr/p.R),lossR=rq*(type==='fullboost'?(st.on?1:2):type==='fullbuck'?(st.on?2*p.n*p.n:0):type==='half'?(st.on?p.n*p.n:0):type==='noninverting'?(st.on?2:0):(st.on?1:0)),lossV=vd*(type==='half'||type==='fullbuck'?1:type==='noninverting'?(!st.on?2:0):(!st.on?b:0));const vc2=type==='half'?s[3]:vi/2,vc1=vi-vc2;if(type==='half')a=st.on?p.n*(st.pol>0?vc1:vc2)/vi:0;let vl=a*vi-b*out-lossR*i-lossV;const idle=i<1e-9&&vl<=0;if(idle){a=0;b=0;vl=0;}
 const output=b*i,load=out/p.R,icoMag=output-load,vo=sign*out,ip=type==='flyback'?(st.on?i:0):bridge?(type==='fullboost'?(st.on?0:st.pol*i):(st.on?st.pol*p.n*i:0)):0;
 // Split-bus KCL: (C1+C2) dvm = C1 dvi + ip.
 // Eliminate midpoint derivative at the bus: Ceq=C1*C2/(C1+C2).
 const alpha=p.C1/(p.C1+p.C2),ceq=p.C1*p.C2/(p.C1+p.C2),qtop=st.on&&st.pol>0?p.n*i:0;
 const demand=type==='half'?qtop-alpha*ip:a*i,is=p.rs?(p.vs-vi)/p.rs:demand;
 const dvi=p.rs?(is-demand)/(p.Ci+(type==='half'?ceq:0)):0;
 const dvm=type==='half'?(p.C1*dvi+ip)/(p.C1+p.C2):dvi/2;
 const ic1=type==='half'?p.C1*(dvi-dvm):0,ic2=type==='half'?p.C2*dvm:0;
 const input=type==='half'?qtop+ic1:a*i;
 const id=type==='buck'?(!st.on?i:0):bridge?(type==='fullboost'?(st.on?0:i/p.n):(st.on?i:i/2)):(!st.on?b*i:0);
 let sw=type==='buck'?(st.on?vi-rq*i:idle?out:-vd):type==='boost'?(st.on?rq*i:idle?vi:out+vd):['inverting','noninverting'].includes(type)?(st.on?vi:idle?0:-out):0;
 let vp=bridge?(type==='fullboost'?(st.on?0:st.pol*(out+vd)/p.n):(st.on?st.pol*((type==='half'?(st.pol>0?vc1:vc2):vi)-rq*p.n*i*(type==='half'?1:2)):0)):type==='flyback'?vl:0;
 if(type==='fullboost')sw=st.on?rq*i:idle?vi:(out+vd)/p.n+2*rq*i;
 let vq=type==='buck'||type==='inverting'?vi-sw:type==='boost'?sw:type==='flyback'?(st.on?rq*i:vi+(out+vd)/p.n):type==='noninverting'?(st.on?rq*i:vi):type==='half'?(st.on?(st.pol>0?0:vi):vi/2):(st.on=== (type!=='fullboost')?(st.pol>0?0:vi):type==='fullboost'?0:vi/2);
 let vdi=type==='buck'?-sw:type==='boost'?sw-out:type==='inverting'?vo-sw:type==='flyback'?(st.on?-p.n*vi-out:idle?0:vd):type==='noninverting'?(st.on?-out:vd):0;
 let d1=bridge?(type==='fullboost'?(st.on?0:st.pol>0?i/p.n:0):(st.on?(st.pol>0?i:0):i/2)):id,d2=bridge?(type==='fullboost'?(st.on?0:st.pol<0?i/p.n:0):(st.on?(st.pol<0?i:0):i/2)):type==='noninverting'?(!st.on?i:0):0;
 if(type==='fullboost')vq=st.on?rq*i/2:st.pol>0?rq*i:sw-rq*i;if(type==='fullbuck'||type==='half')vq=st.on?(st.pol>0?rq*p.n*i:vi-rq*p.n*i):vi/2;if(type==='half'&&!st.on)vq=vc1;if(idle&&type==='fullboost')vp=st.pol*vi;
 if(bridge)vdi=p.n*vp-(type==='fullboost'?out:idle?out:Math.abs(p.n*vp)-vd);if(type==='flyback'){vdi=-p.n*vp-out;if(idle)vq=vi;}if(type==='noninverting'){vq=st.on?rq*i:idle?vi:vi+vd;vdi=(st.on?rq*i:idle?0:out+vd)-out;}
 const q1=bridge?(type==='fullboost'?(st.on?i/2:st.pol>0?i:0):(st.on&&st.pol>0?p.n*i:0)):(st.on?i:0),q2=bridge?(type==='fullboost'?(st.on?i/2:st.pol<0?i:0):(st.on&&st.pol<0?p.n*i:0)):type==='noninverting'?q1:0;
 return{vi,vc1,vc2,ic1,ic2,dvm,dvi,splitEnergy:type==='half'?.5*p.C1*vc1*vc1+.5*p.C2*vc2*vc2:0,i,vc:sign*s[2],out,vo,ir:sign*load,ico:sign*icoMag,ici:is-input,is,input,output,iq:q1,id:d1,q1,q2,q3:q2,q4:q1,d1,d2,ip,sec:bridge?d1-d2:type==='flyback'?output:0,vl,vq,vd:vdi,vp,sw,left:idle?0:st.on?vi-rq*i:-vd,right:idle?0:st.on?rq*i:out+vd,rect:bridge?(type==='fullboost'?out:idle?out:Math.abs(p.n*vp)-vd):sw,on:st.on,pol:st.pol,idle,di:(vl-rL*i)/p.L,dvc:icoMag/p.Co};
 }
 function step(s,st,h=dt){const f=x=>{const v=values(x,st);return type==='half'?[v.dvi,v.idle?0:v.di,v.dvc,v.dvm]:[v.dvi,v.idle?0:v.di,v.dvc];},a=f(s),b=f(s.map((v,j)=>v+a[j]*h/2)),c=f(s.map((v,j)=>v+b[j]*h/2)),d=f(s.map((v,j)=>v+c[j]*h));const z=s.map((v,j)=>v+h*(a[j]+2*b[j]+2*c[j]+d[j])/6);z[1]=Math.max(0,z[1]);return z;}
 const ratio=type==='buck'?p.duty:type==='boost'?1/(1-p.duty):['inverting','noninverting'].includes(type)?p.duty/(1-p.duty):type==='flyback'?p.n*p.duty/(1-p.duty):type==='fullboost'?p.n/(1-p.duty):p.n*p.duty*(type==='half'?.5:1);
 let s=[p.vs,Math.max(.01,p.vs*ratio/p.R/(type==='boost'||type==='fullboost'?1-p.duty:1)),p.vs*ratio],error=Infinity,cycles=0;if(type==='half')s.push(p.vs*(options.initialMidpointFraction??.5));
 // Solve the half-bridge periodic boundary directly: the ideal midpoint can
 // settle extremely slowly under repeated time marching. This is not a startup run.
 if(type==='half'){
  const indices=p.rs?[0,1,2,3]:[1,2,3];
  const residual=x=>{let y=[...x];for(let k=0;k<N*2;k++)y=step(y,stages(k));return indices.map(j=>y[j]-x[j]);};
  for(;cycles<20;cycles++){
   const r=residual(s);error=Math.max(...r.map(Math.abs));if(error<1e-9)break;
   const columns=indices.map(j=>{const x=[...s],eps=1e-5*Math.max(1,Math.abs(x[j]));x[j]+=eps;return residual(x).map((v,k)=>(v-r[k])/eps);});
   const A=r.map((v,k)=>[...columns.map(col=>col[k]),-v]),size=indices.length;
   for(let k=0;k<size;k++){let pivot=k;for(let j=k+1;j<size;j++)if(Math.abs(A[j][k])>Math.abs(A[pivot][k]))pivot=j;[A[k],A[pivot]]=[A[pivot],A[k]];if(Math.abs(A[k][k])<1e-12)throw Error('Half-bridge periodic midpoint is underdetermined.');const d=A[k][k];for(let j=k;j<=size;j++)A[k][j]/=d;for(let row=0;row<size;row++)if(row!==k){const f=A[row][k];for(let j=k;j<=size;j++)A[row][j]-=f*A[k][j];}}
   let accepted=false;for(let damping=1;damping>=1/128;damping/=2){const next=[...s];indices.forEach((j,k)=>next[j]+=damping*A[k][size]);next[1]=Math.max(0,next[1]);if(next[2]<0||next[3]<=0||next[3]>=next[0])continue;if(Math.max(...residual(next).map(Math.abs))<error){s=next;accepted=true;break;}}
   if(!accepted)throw Error('Half-bridge periodic solution did not converge for these values.');
  }
 }else
 for(;cycles<4000;cycles++){const prev=[...s];for(let k=0;k<N*2;k++)s=step(s,stages(k));error=Math.max(...s.map((v,j)=>Math.abs(v-prev[j])));if(!s.every(Number.isFinite)||Math.abs(s[2])>1e6)throw Error('This combination is outside the supported model range.');if(error<1e-8)break;}
 if(error>1e-5)throw Error('Steady state did not settle. Try a larger load or capacitance.');
 const keys=['i','is','input','output','ici','ico','ir','iq','id','q1','q2','q3','q4','d1','d2','ip','sec','ic1','ic2'],charge=Object.fromEntries(keys.map(k=>[k,0])),samples=[];
 for(let k=0;k<=N*4;k++){const st=stages(k),v=values(s,st);samples.push({...v,s:[...s],t:k*dt,charge:{...charge}});if(k===N*4)break;const next=step(s,st),w=values(next,st);keys.forEach(key=>charge[key]+=(v[key]+w[key])*dt/2);s=next;}
 const statistics={},numeric=Object.keys(samples[0]).filter(k=>typeof samples[0][k]==='number'&&k!=='t');numeric.forEach(key=>statistics[key]={min:Infinity,max:-Infinity,integral:0});
 for(let k=0;k<samples.length-1;k++){const a=samples[k],b={...values(samples[k+1].s,{on:a.on,pol:a.pol}),t:samples[k+1].t};for(const key of numeric){const st=statistics[key];for(const v of[a,b]){if(v[key]<st.min){st.min=v[key];st.minPoint=v;}if(v[key]>st.max){st.max=v[key];st.maxPoint=v;}}st.integral+=(a[key]+b[key])*dt/2;}}
 const means={};numeric.forEach(key=>{statistics[key].mean=statistics[key].integral/end;means[key]=statistics[key].mean;});
 function at(t){const u=Math.min(N*4,Math.max(0,t/dt)),k=Math.min(samples.length-2,Math.floor(u)),f=u-k,a=samples[k],b=samples[k+1];return {...values(a.s.map((v,j)=>v+(b.s[j]-v)*f),stages(Math.floor(u+1e-7))),charge:Object.fromEntries(keys.map(key=>[key,a.charge[key]+f*(b.charge[key]-a.charge[key])]))};}
 return{p:{...p,type},samples,values,at,mean:k=>means[k],means,statistics,duration:end,dt,error,cycles,ratio,bridge,sign,regime:samples.some(v=>v.idle)?'DCM':'CCM'};
}
if(typeof module!=='undefined')module.exports={simulate,names,defaults};else g.CircuitModel={simulate,names,defaults};
})(globalThis);
